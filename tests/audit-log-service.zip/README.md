# Audit Log Service

The **audit-log-service** is a backend microservice built using **NestJS**, designed to handle comprehensive audit logging for various application operations. It supports APIs for creating, retrieving, and managing audit logs and is optimized for performance and scalability. The service includes Swagger documentation, integrates with MongoDB, and features built-in request validation and logging.

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Available Scripts](#available-scripts)
- [Project Structure](#project-structure)
- [Dependencies](#dependencies)
- [Testing](#testing)
- [License](#license)

## Features

- **Audit Log Management**: APIs to log, query, and manage audit records.
- **Database Integration**: MongoDB integration using Mongoose.
- **Request Validation**: Uses class-validator for validating API requests.
- **Logging**: Integrated logging system with Winston for better traceability.
- **Swagger Documentation**: API documentation using Swagger.
- **Microservice Architecture**: Built to scale with NestJS's microservices module.
- **Health Checks**: Application health check endpoints using NestJS Terminus.

## Installation

### Prerequisites

Ensure you have the following installed:

- **Node.js** (v16 or later)
- **npm** or **yarn**
- **MongoDB** (running locally or via a cloud provider)

### Clone the repository

```bash
git clone git@bitbucket.org:impexdocs/audit-log-service.git
cd audit-log-service
```

```bash
npm install
npm run start
```

## Project Structure

```bash
src/
├── common/               # Shared functionality across modules (e.g., logging, validation, error handling)
│   ├── decorators/       # Custom decorators
│   ├── filters/          # Custom exception filters
│   ├── interceptors/     # Custom interceptors for response transformation
│   ├── pipes/            # Validation and transformation pipes
├── modules/              # Core functionality of the service
│   ├── audit-log/        # Audit log management (create, query, delete logs)
│   ├── health-check/     # Health check endpoints for service monitoring
├── config/               # Configuration files for environment variables and app settings
├── main.ts               # Application entry point for NestJS
├── app.module.ts         # Root module that imports and configures services
└── app.controller.ts     # Root-level controller (e.g., health check route)
```

## Environment Configuration

### MongoDB Configuration

MONGO_URI=mongodb://localhost:27017/dynamic-form-db

### Application Port (default is 3000)

PORT=3000

### API Key for external integrations or additional security

X_API_KEY=your_api_key_here

### Key Points:

- **Install Dependencies**: Added `npm install` and `yarn install` before running the app.
- **Test Commands**: Detailed instructions for running unit tests, e2e tests, and generating a coverage report.
- **Swagger Documentation**: Included instructions on accessing the Swagger UI once the app is running.
