import { FlatCompat } from '@eslint/eslintrc';
import js from '@eslint/js';
import path from 'path';

const compat = new FlatCompat({
  baseDirectory: path.resolve(process.cwd(), 'src'),
});

const config = compat.config({
  extends: [
    'plugin:@typescript-eslint/recommended',
    'plugin:prettier/recommended',
  ],
  parser: '@typescript-eslint/parser',
  parserOptions: {
    project: 'tsconfig.json',
    tsconfigRootDir: process.cwd(),
    sourceType: 'module',
    ecmaVersion: 2020,
  },
  plugins: ['@typescript-eslint/eslint-plugin'],
  env: {
    node: true,
    jest: true,
    es2021: true,
  },
  ignorePatterns: ['.eslintrc.mjs'],
  rules: {
    '@typescript-eslint/interface-name-prefix': 'off',
    '@typescript-eslint/explicit-function-return-type': 'warn',
    '@typescript-eslint/explicit-module-boundary-types': 'warn',
    'prettier/prettier': 'error',
    'no-console': 'off',
    'prefer-const': 'error',
  },
  settings: {
    'import/resolver': {
      typescript: {},
    },
  },
});

export default config;
