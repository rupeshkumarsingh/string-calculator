export const RESPONSE_CODES = {
  SUCCESS: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  VALIDATION_ERROR: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  INTERNAL_SERVER_ERROR: 500,
  SERVICE_UNAVAILABLE: 503,
};

export const RESPONSE_MESSAGES = {
  SUCCESS: 'Operation successful',
  RESOURCE_CREATED: 'Resource created successfully',
  NO_CONTENT: 'No content available',
  VALIDATION_ERROR: 'Validation failed for the request',
  UNAUTHORIZED: 'Unauthorized access',
  FORBIDDEN: 'You do not have permission to perform this action',
  NOT_FOUND: 'Resource not found',
  INTERNAL_SERVER_ERROR: 'An internal server error occurred',
  SERVICE_UNAVAILABLE: 'Service is temporarily unavailable',
  CONFLICT: 'Component type must be unique',
};

export const ERROR_CODES = {
  E_VALIDATION_001: 'E_VALIDATION_001',
  E_AUTH_001: 'E_AUTH_001',
  E_PERMISSION_001: 'E_PERMISSION_001',
  E_SERVER_001: 'E_SERVER_001',
  E_SERVICE_UNAVAILABLE_001: 'E_SERVICE_UNAVAILABLE_001',
  E_DUPLICATE_RECORD_001: 'E_DUPLICATE_RECORD_001',
};
