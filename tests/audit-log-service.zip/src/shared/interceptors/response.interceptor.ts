import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ResponseBuilder } from '../utils/response.builder';

@Injectable()
export class ResponseInterceptor<T> implements NestInterceptor<T, unknown> {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    return next.handle().pipe(
      map((data: T) => {
        const httpContext = context.switchToHttp();
        //const request = httpContext.getRequest();
        const response = httpContext.getResponse();

        return ResponseBuilder.buildSuccessResponse(data, {
          message: response?.message || '',
        });
      }),
    );
  }
}
