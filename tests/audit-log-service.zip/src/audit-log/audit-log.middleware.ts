import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class AuditLogMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction): void {
    req['tenantId'] = req.headers['tenantid'];
    req['platformId'] = req.headers['platformid'];
    next();
  }
}
