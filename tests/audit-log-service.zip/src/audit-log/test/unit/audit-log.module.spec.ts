import { Test, TestingModule } from '@nestjs/testing';
import { MongooseModule } from '@nestjs/mongoose';
import { AuditLogModule } from '../../audit-log.module';
import { AuditLogController } from '../../application/audit-log.controller';
import { AuditLogService } from '../../application/audit-log.service';
import { AuditLogRepository } from '../../infrastructure/audit-log.repository';
import { AuditLogMiddleware } from '../../audit-log.middleware';

describe('AuditLogModule', () => {
  let module: TestingModule;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [
        AuditLogModule,
        MongooseModule.forRoot('mongodb://localhost/test'),
      ],
    }).compile();
  });

  it('should be defined', () => {
    expect(module).toBeDefined();
  });

  it('should have AuditLogController defined', () => {
    const controller = module.get<AuditLogController>(AuditLogController);
    expect(controller).toBeDefined();
  });

  it('should have AuditLogService defined', () => {
    const service = module.get<AuditLogService>(AuditLogService);
    expect(service).toBeDefined();
  });

  it('should have AuditLogRepository defined', () => {
    const repository = module.get<AuditLogRepository>(AuditLogRepository);
    expect(repository).toBeDefined();
  });

  it('should apply AuditLogMiddleware', () => {
    const consumer = {
      apply: jest.fn().mockReturnThis(),
      forRoutes: jest.fn(),
    };

    const auditLogModule = new AuditLogModule();
    auditLogModule.configure(consumer);

    expect(consumer.apply).toHaveBeenCalledWith(AuditLogMiddleware);
    expect(consumer.forRoutes).toHaveBeenCalledWith(AuditLogController);
  });
});
