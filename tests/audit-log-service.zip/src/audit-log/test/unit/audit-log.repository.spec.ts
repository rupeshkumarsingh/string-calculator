import { Test, TestingModule } from '@nestjs/testing';
import { AuditLogRepository } from '../../infrastructure/audit-log.repository';
import { getModelToken } from '@nestjs/mongoose';
import { InternalServerErrorException } from '@nestjs/common';

describe('AuditLogRepository', () => {
  let repository: AuditLogRepository;

  const mockAuditLogModel = jest.fn().mockImplementation(() => ({
    save: jest.fn(),
  }));

  const mockAuditLogData = {
    tenantId: 'tenant123',
    userId: 'user123',
    platformId: 'platform123',
    serviceName: 'TestService',
    action: 'CREATE',
    entityName: 'TestEntity',
    effectedEntityId: 'entity123',
    oldValue: { name: 'Old' },
    newValue: { name: 'New' },
    relatedEntities: 'relatedEntity1',
    additionalInfo: 'Additional info',
    ipAddress: '192.168.1.1',
    version: '1.0',
    timestamp: new Date(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuditLogRepository,
        {
          provide: getModelToken('AuditLog'),
          useValue: mockAuditLogModel,
        },
      ],
    }).compile();

    repository = module.get<AuditLogRepository>(AuditLogRepository);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(repository).toBeDefined();
  });

  describe('createLog', () => {
    it('should successfully create and save an audit log', async () => {
      const auditLogInstance = new mockAuditLogModel();
      mockAuditLogModel.mockImplementation(() => auditLogInstance);
      auditLogInstance.save.mockResolvedValue(mockAuditLogData);

      const result = await repository.createLog(mockAuditLogData);

      expect(mockAuditLogModel).toHaveBeenCalledWith(mockAuditLogData);
      expect(auditLogInstance.save).toHaveBeenCalled();
      expect(result).toEqual(mockAuditLogData);
    });
    it('should throw an InternalServerErrorException when saving fails', async () => {
      const auditLogInstance = new mockAuditLogModel();
      mockAuditLogModel.mockImplementation(() => auditLogInstance);

      auditLogInstance.save.mockRejectedValue(new Error('Database error'));

      await expect(repository.createLog(mockAuditLogData)).rejects.toThrow(
        InternalServerErrorException,
      );
      await expect(repository.createLog(mockAuditLogData)).rejects.toThrow(
        'Failed to create audit log',
      );
    });
  });
});
