import { Test, TestingModule } from '@nestjs/testing';
import { AuditLogController } from '../../application/audit-log.controller';
import { AuditLogService } from '../../application/audit-log.service';
import { CreateAuditLogDto } from '../../application/dto/create-audit-log.dto';
import { IAuditLog } from '../../domain/audit-log';
import { PaginationDto } from '../../../pagination/dto/pagination.dto';
import { PaginatedResult } from '../../../pagination/interfaces/paginated-result.interface';

describe('AuditLogController', () => {
  let controller: AuditLogController;
  let service: AuditLogService;

  // Mocking the AuditLogService
  const mockAuditLogService = {
    logEvent: jest.fn(),
    findAllPaginated: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AuditLogController],
      providers: [
        {
          provide: AuditLogService,
          useValue: mockAuditLogService,
        },
      ],
    }).compile();

    controller = module.get<AuditLogController>(AuditLogController);
    service = module.get<AuditLogService>(AuditLogService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('logEvent', () => {
    const mockCreateAuditLogDto: CreateAuditLogDto & {
      tenantId: string;
      platformId: string;
    } = {
      userId: 'user456',
      serviceName: 'UserService',
      action: 'CREATE',
      entityName: 'User',
      effectedEntityId: 'entity123',
      oldValue: '{"name": "John Doe"}',
      newValue: '{"name": "Jane Doe"}',
      relatedEntities: '["relatedEntity123", "relatedEntity456"]',
      additionalInfo: 'User created via the admin panel',
      ipAddress: '192.168.0.1',
    } as CreateAuditLogDto;

    const mockRequest = {
      tenantId: 'test-tenant-id',
      platformId: 'test-platform-id',
    };
    it('should create an audit log successfully', async () => {
      const expectedResult: IAuditLog = {
        ...mockCreateAuditLogDto,
        timestamp: new Date(),
      } as IAuditLog;

      jest.spyOn(service, 'logEvent').mockResolvedValue(expectedResult);

      const result = await controller.logEvent(
        mockRequest as unknown as Request,
        mockCreateAuditLogDto,
      );

      expect(service.logEvent).toHaveBeenCalledTimes(1);
      expect(service.logEvent).toHaveBeenCalledWith({
        ...mockCreateAuditLogDto,
        tenantId: mockRequest.tenantId,
        platformId: mockRequest.platformId,
      });
      expect(result).toEqual(expectedResult);
      expect(result).toMatchObject(mockCreateAuditLogDto);
      expect(result.timestamp).toBeInstanceOf(Date);
    });

    it('should throw an error if service.logEvent fails', async () => {
      const errorMessage = 'Failed to log event';
      jest
        .spyOn(service, 'logEvent')
        .mockRejectedValue(new Error(errorMessage));

      await expect(
        controller.logEvent(
          mockRequest as unknown as Request,
          mockCreateAuditLogDto,
        ),
      ).rejects.toThrow(errorMessage);

      expect(service.logEvent).toHaveBeenCalledTimes(1);
    });
  });

  describe('getAllAuditLogs', () => {
    const mockTenantId = 'test-tenant-id';
    const mockPlatformId = 'test-platform-id';

    it('should retrieve paginated audit logs successfully', async () => {
      const mockQuery: PaginationDto = { limit: 10, page: 1 };
      const mockAuditLogs = [
        {
          userId: 'user456',
          serviceName: 'UserService',
          action: 'CREATE',
          entityName: 'User',
          effectedEntityId: 'entity123',
          oldValue: '{"name": "John Doe"}',
          newValue: '{"name": "Jane Doe"}',
          relatedEntities: '["relatedEntity123", "relatedEntity456"]',
          additionalInfo: 'User created via the admin panel',
          ipAddress: '192.168.0.1',
          version: 'v1.0',
          timestamp: new Date('2024-10-11T08:45:00Z'),
          tenantId: 'tenant123',
          platformId: 'platform123',
        },
      ];
      const mockPaginatedResult: PaginatedResult<IAuditLog> = {
        items: mockAuditLogs,
        total: 1,
        page: 1,
        limit: 10,
        totalPages: 1,
      } as PaginatedResult<IAuditLog>;

      jest
        .spyOn(service, 'findAllPaginated')
        .mockResolvedValue(mockPaginatedResult);

      const result = await controller.getAllAuditLogs(
        mockQuery,
        mockTenantId,
        mockPlatformId,
      );

      expect(result).toEqual(mockPaginatedResult);
    });
  });
});
