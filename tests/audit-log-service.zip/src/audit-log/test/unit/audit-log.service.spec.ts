import { Test, TestingModule } from '@nestjs/testing';
import { AuditLogService } from '../../application/audit-log.service';
import { AuditLogRepository } from '../../infrastructure/audit-log.repository';
import { CreateAuditLogDto } from '../../application/dto/create-audit-log.dto';
import { IAuditLog } from '../../domain/audit-log';

describe('AuditLogService', () => {
  let service: AuditLogService;
  //let repository: AuditLogRepository;

  // Mocking repository methods
  const mockRepository = {
    createLog: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuditLogService,
        {
          provide: AuditLogRepository,
          useValue: mockRepository,
        },
      ],
    }).compile();

    service = module.get<AuditLogService>(AuditLogService);
    //repository = module.get<AuditLogRepository>(AuditLogRepository);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('logEvent', () => {
    const createAuditLogDto: CreateAuditLogDto = {
      tenantId: 'tenant123',
      userId: 'user123',
      platformId: 'platform123',
      serviceName: 'TestService',
      action: 'CREATE',
      entityName: 'TestEntity',
      effectedEntityId: 'entity123',
      oldValue: { name: 'Old' },
      newValue: { name: 'New' },
      relatedEntities: ['relatedEntity1'],
      additionalInfo: 'Additional info',
      ipAddress: '192.168.1.1',
      version: '1.0',
    };

    const logEntry: Partial<IAuditLog> = {
      ...createAuditLogDto,
      timestamp: new Date(),
    } as IAuditLog;

    const savedLogEntry: Partial<IAuditLog> = {
      ...logEntry,
      _id: 'log123',
    };

    it('should successfully log an event', async () => {
      mockRepository.createLog.mockResolvedValue(savedLogEntry);

      const result = await service.logEvent(createAuditLogDto);

      // Ensure the log entry was created and saved correctly
      expect(mockRepository.createLog).toHaveBeenCalledWith(
        expect.objectContaining({
          ...logEntry,
          timestamp: expect.any(Date),
        }),
      );
      expect(result).toEqual(savedLogEntry);
    });
  });
});
