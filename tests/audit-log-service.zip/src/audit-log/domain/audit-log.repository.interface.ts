import { IAuditLog } from './audit-log';

export interface IAuditLogRepository {
  createLog(auditLog: IAuditLog): Promise<IAuditLog | null>;
}
