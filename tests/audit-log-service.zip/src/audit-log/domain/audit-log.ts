import { Document } from 'mongoose';

// Create the interface for CreateAuditLog
export interface IAuditLogData {
  tenantId: string;
  userId: string;
  platformId: string;
  serviceName: string;
  action?: string;
  entityName?: string;
  effectedEntityId?: string;
  oldValue?: unknown;
  newValue?: unknown;
  relatedEntities?: string;
  additionalInfo?: string;
  ipAddress?: string;
  version?: string;
  timestamp?: Date;
}

export interface IAuditLog extends IAuditLogData, Document {}
