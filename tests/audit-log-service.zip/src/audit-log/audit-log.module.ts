import { MiddlewareConsumer, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';

import { AuditLogService } from './application/audit-log.service';
import { AuditLogRepository } from './infrastructure/audit-log.repository';
import { AuditLogSchema } from './infrastructure/schema/audit-log.schema';
import { AuditLogController } from './application/audit-log.controller';
import { AuditLogMiddleware } from './audit-log.middleware';

const AUDIT_LOG_MODEL_NAME = 'AuditLog';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: AUDIT_LOG_MODEL_NAME, schema: AuditLogSchema },
    ]),
  ],
  controllers: [AuditLogController],
  providers: [AuditLogService, AuditLogRepository],
  exports: [AuditLogService, AuditLogRepository],
})
export class AuditLogModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(AuditLogMiddleware).forRoutes(AuditLogController);
  }
}
