import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { IAuditLog, IAuditLogData } from '../domain/audit-log';
import { IAuditLogRepository } from '../domain/audit-log.repository.interface';
import { BaseRepository } from '../../pagination/repositories/base.repository';

@Injectable()
export class AuditLogRepository
  extends BaseRepository<IAuditLog>
  implements IAuditLogRepository
{
  constructor(
    @InjectModel('AuditLog') private readonly auditLogModel: Model<IAuditLog>,
  ) {
    super(auditLogModel);
  }

  /**
   * Creates a new audit log entry in the database.
   *
   * @param logDetails - The audit log details to be saved.
   * @returns The saved audit log entry.
   * @throws InternalServerErrorException - If the log entry creation fails.
   */
  async createLog(logDetails: IAuditLogData): Promise<IAuditLog> {
    try {
      const auditLog = new this.auditLogModel(logDetails);
      return await auditLog.save();
    } catch (error) {
      throw new InternalServerErrorException(
        'Failed to create audit log',
        error,
      );
    }
  }
}
