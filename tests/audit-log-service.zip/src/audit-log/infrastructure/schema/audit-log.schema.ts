import mongoose, { Schema } from 'mongoose';
import { IAuditLog } from '../../domain/audit-log';

// Define the Audit Log Schema
export const AuditLogSchema: Schema = new Schema(
  {
    tenantId: {
      type: String,
      required: true,
      index: true,
    },
    userId: {
      type: String,
      required: true,
      index: true,
    },
    platformId: {
      type: String,
      required: true,
      index: true,
    },
    serviceName: { type: String, required: true },
    action: { type: String, required: true },
    entityName: { type: String, required: true },
    effectedEntityId: {
      type: String,
      required: true,
    },
    oldValue: {
      type: Schema.Types.Mixed,
      required: true,
    },
    newValue: {
      type: Schema.Types.Mixed,
      required: true,
    },
    relatedEntities: [
      {
        type: Schema.Types.Mixed,
      },
    ],
    additionalInfo: { type: String },
    ipAddress: { type: String },
    version: { type: String },
    timestamp: { type: Date, default: Date.now },
  },
  {
    timestamps: true,
  },
);

// Export the model
const AuditLog = mongoose.model<IAuditLog>('AuditLog', AuditLogSchema);
export default AuditLog;
