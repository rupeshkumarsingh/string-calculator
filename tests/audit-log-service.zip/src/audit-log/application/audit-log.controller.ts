import {
  Controller,
  Post,
  Body,
  HttpCode,
  HttpStatus,
  Headers,
  Get,
  Query,
  Req,
} from '@nestjs/common';
import { AuditLogService } from './audit-log.service';
import { CreateAuditLogDto } from './dto/create-audit-log.dto';
import { PaginationDto } from '../../pagination/dto/pagination.dto';
import { IAuditLog } from '../domain/audit-log';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiQuery,
  ApiHeader,
  ApiBody,
} from '@nestjs/swagger';

@ApiTags('Audit Logs')
@Controller('audit-logs')
export class AuditLogController {
  constructor(private readonly auditLogService: AuditLogService) {}

  /**
   * @description
   * Creates a new audit log entry.
   *
   * @summary
   * Logs an event by taking input from the request body
   * values from the request object.
   *
   * @param req - The request object containing tenantId and platformId.
   * @param createAuditLogDto - (DTO) containing audit log details.
   *
   * @returns The newly created audit log entry.
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Log an event' })
  @ApiResponse({
    status: 201,
    description: 'The audit log has been created successfully.',
  })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  @ApiBody({ type: CreateAuditLogDto })
  @ApiHeader({
    name: 'tenantId',
    description: 'ID of the tenant to which the audit log is related',
    required: true,
  })
  @ApiHeader({
    name: 'platformId',
    description: 'ID of the platform from which the action was performed',
    required: true,
  })
  async logEvent(
    @Req() req: Request,
    @Body()
    createAuditLogDto: CreateAuditLogDto & {
      tenantId: string;
      platformId: string;
    },
  ): Promise<IAuditLog> {
    const auditData = {
      ...createAuditLogDto,
      tenantId: req['tenantId'],
      platformId: req['platformId'],
    };

    return await this.auditLogService.logEvent(auditData);
  }

  /**
   * @description
   * Retrieves a paginated list of audit logs.
   *
   * @summary
   * Fetches audit logs filtered by tenantId and platformId from the request headers.
   * Supports pagination via query parameters.
   *
   * @param query - Pagination options like limit and offset.
   * @param tenantId - The tenant ID from the request headers.
   * @param platformId - The platform ID from the request headers.
   *
   * @returns A paginated list of audit logs.
   */
  @Get()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Retrieve paginated audit logs' })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved audit logs.',
  })
  @ApiResponse({ status: 400, description: 'Bad Request.' })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Number of records to return.',
  })
  @ApiQuery({
    name: 'offset',
    required: false,
    description: 'Starting point of records to return.',
  })
  @ApiHeader({ name: 'tenantId', required: true, description: 'Tenant ID' })
  @ApiHeader({ name: 'platformId', required: true, description: 'Platform ID' })
  async getAllAuditLogs(
    @Query() query: PaginationDto = {},
    @Headers('tenantId') tenantId: string,
    @Headers('platformId') platformId: string,
  ): Promise<unknown> {
    const queryData = { ...query, tenantId, platformId };

    // Fetch the paginated list of audit logs
    return await this.auditLogService.findAllPaginated(queryData);
  }
}
