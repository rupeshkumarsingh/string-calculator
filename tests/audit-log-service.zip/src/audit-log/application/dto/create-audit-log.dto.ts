import { IsNotEmpty, IsOptional } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateAuditLogDto {
  @IsNotEmpty()
  tenantId: string;

  @ApiProperty({
    description: 'ID of the user who performed the action',
    example: 'user456',
  })
  @IsNotEmpty()
  userId: string;

  @IsNotEmpty()
  platformId: string;

  @ApiProperty({
    description: 'Name of the service where the action took place',
    example: 'UserService',
  })
  @IsNotEmpty()
  serviceName: string;

  @ApiProperty({
    description: 'Action performed by the user (e.g., "CREATE", "UPDATE")',
    example: 'CREATE',
  })
  @IsNotEmpty()
  action: string;

  @ApiProperty({
    description: 'Name of the entity affected by the action',
    example: 'User',
  })
  @IsNotEmpty()
  entityName: string;

  @ApiProperty({
    description: 'ID of the affected entity',
    example: 'entity123',
  })
  @IsNotEmpty()
  effectedEntityId: string;

  @ApiProperty({
    description: 'Previous value of the entity before the action',
    example: '{"name": "John Doe"}',
  })
  @IsNotEmpty()
  oldValue: unknown;

  @ApiProperty({
    description: 'New value of the entity after the action',
    example: '{"name": "Jane Doe"}',
  })
  @IsNotEmpty()
  newValue: unknown;

  @ApiPropertyOptional({
    description: 'IDs of any related entities (if applicable)',
    example: '["relatedEntity123", "relatedEntity456"]',
  })
  @IsOptional()
  relatedEntities?: unknown;

  @ApiPropertyOptional({
    description: 'Any additional information related to the action',
    example: 'User created via the admin panel',
  })
  @IsOptional()
  additionalInfo?: string;

  @ApiPropertyOptional({
    description: 'IP address from which the action was performed',
    example: '192.168.0.1',
  })
  @IsOptional()
  ipAddress?: string;

  @ApiPropertyOptional({
    description: 'Version of the entity affected (if applicable)',
    example: 'v1.0',
  })
  @IsOptional()
  version?: string;

  @ApiPropertyOptional({
    description: 'Timestamp of when the action occurred',
    example: '2024-10-11T08:45:00Z',
  })
  @IsOptional()
  timestamp?: Date;
}
