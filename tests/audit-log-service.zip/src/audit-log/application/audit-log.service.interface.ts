import { CreateAuditLogDto } from './dto/create-audit-log.dto';

export interface IAuditLogService {
  logEvent(createAuditLogDto: CreateAuditLogDto): Promise<void>;
}
