import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { AuditLogRepository } from '../infrastructure/audit-log.repository';
import { CreateAuditLogDto } from './dto/create-audit-log.dto';
import { IAuditLog } from '../domain/audit-log';
import { BaseService } from '../../pagination/services/base.service';

@Injectable()
export class AuditLogService extends BaseService<IAuditLog> {
  constructor(private readonly auditLogRepository: AuditLogRepository) {
    super(auditLogRepository);
  }

  /**
   * Logs an event by creating and saving an audit log entry.
   *
   * @param createAuditLogDto - Data transfer object containing details to log.
   * @returns The saved audit log entry.
   */
  async logEvent(createAuditLogDto: CreateAuditLogDto): Promise<IAuditLog> {
    const logEntry: IAuditLog = this.createLogEntry(createAuditLogDto);
    const saveData = await this.saveLogEntry(logEntry);
    return saveData;
  }

  /**
   * Creates an audit log entry object from the provided DTO.
   *
   * @param createAuditLogDto - DTO containing the details of the log entry.
   * @returns The created audit log entry object.
   */
  private createLogEntry(createAuditLogDto: CreateAuditLogDto): IAuditLog {
    const auditData: IAuditLog = {
      ...createAuditLogDto,
      timestamp: new Date(),
    } as IAuditLog;
    return auditData;
  }

  /**
   * Saves the log entry to the repository.
   *
   * @param logEntry - The log entry object to be saved.
   * @returns The saved log entry.
   * @throws InternalServerErrorException - If there is an issue saving the log entry.
   */
  private async saveLogEntry(logEntry: IAuditLog): Promise<IAuditLog> {
    try {
      const data = await this.auditLogRepository.createLog(logEntry);
      return data;
    } catch (error) {
      console.log(error);
      throw new InternalServerErrorException('Failed to log event', error);
    }
  }
}
