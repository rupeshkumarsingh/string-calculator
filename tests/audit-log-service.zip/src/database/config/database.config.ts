import { registerAs } from '@nestjs/config';

export default registerAs('database', () => ({
  url:
    process.env.NODE_ENV === 'test'
      ? process.env.TEST_DATABASE_URL || 'mongodb://localhost:27017/test-db'
      : process.env.MONGODB_URI || 'mongodb://localhost:27017/form-builder-db',
  name:
    process.env.NODE_ENV === 'test'
      ? process.env.TEST_DATABASE_NAME || 'test-db'
      : process.env.DATABASE_NAME || 'form-builder-db',
}));
