import { Module, Global } from '@nestjs/common';
import { HttpExceptionFilter } from './error-log/filters/http-exception.filter';
import LoggerService from './error-log/logger.service';

@Global()
@Module({
  providers: [
    {
      provide: 'APP_FILTER',
      useClass: HttpExceptionFilter,
    },
    LoggerService,
  ],
  exports: [LoggerService],
})
export class LoggerModule {}
