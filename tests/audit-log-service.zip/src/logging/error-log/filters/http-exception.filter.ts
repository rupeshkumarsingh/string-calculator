import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { Request, Response } from 'express';
import LoggerService from '../logger.service';
import { ResponseBuilder } from '../../../shared/utils/response.builder';

@Catch(HttpException)
export class HttpExceptionFilter implements ExceptionFilter {
  constructor(private readonly logger: LoggerService) {}

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    // Default response details
    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let errorResponse;
    const clientIp =
      request.headers['x-forwarded-for'] || request.connection.remoteAddress;

    // Check if the exception is an instance of HttpException
    if (exception instanceof HttpException) {
      status = exception.getStatus();
      errorResponse = ResponseBuilder.buildErrorResponse(exception, request);
    } else {
      // Handle other exceptions
      errorResponse = {
        statusCode: status,
        message: 'Internal server error',
        timestamp: new Date().toISOString(),
        path: request.url,
      };
    }
    // Log the error using the logger service
    this.logger.error(
      `Error: ${errorResponse.message}`,
      `Status: ${errorResponse.statusCode}, URL: ${request.url}, Method: ${request.method}, IP: ${clientIp}, Timestamp: ${errorResponse.timestamp}, Environment: ${process.env.NODE_ENV}`,
    );

    // Send the error response to the client
    response.status(status).json(errorResponse);
  }
}
