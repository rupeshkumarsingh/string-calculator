import { Document } from 'mongoose';
import { PaginationDto } from '../dto/pagination.dto';
import { PaginatedResult } from '../interfaces/paginated-result.interface';
import { BaseRepository } from '../repositories/base.repository';

export abstract class BaseService<T extends Document> {
  constructor(protected readonly repository: BaseRepository<T>) {}

  async findAllPaginated(
    query: PaginationDto = {},
  ): Promise<PaginatedResult<T>> {
    const {
      page = 1,
      limit = 100,
      sortBy = 'createdAt',
      sortOrder = 'asc',
      filters = {},
    } = query;

    return this.repository.findAllPaginated(
      filters,
      page,
      limit,
      sortBy,
      sortOrder,
    );
  }
}
