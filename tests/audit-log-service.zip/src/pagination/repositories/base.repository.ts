import { Model, Document, FilterQuery } from 'mongoose';
import { PaginatedResult } from '../interfaces/paginated-result.interface';
export abstract class BaseRepository<T extends Document> {
  constructor(protected readonly model: Model<T>) {}
  async findAllPaginated(
    filter: FilterQuery<T>,
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
  ): Promise<PaginatedResult<T>> {
    const skip = (page - 1) * limit;
    const sortOptions: Record<string, 'asc' | 'desc'> = { [sortBy]: sortOrder };

    const [items, total] = await Promise.all([
      this.model.find(filter).sort(sortOptions).skip(skip).limit(limit).exec(),
      this.model.countDocuments(filter).exec(),
    ]);

    return {
      items,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }
}
