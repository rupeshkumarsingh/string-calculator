import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import morgan from 'morgan';
import { ConfigService } from '@nestjs/config';
import { AppModule } from './app.module';
import { AllConfigType } from './config/config.type';
import { ResponseInterceptor } from './shared/interceptors/response.interceptor';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);

  const configService = app.get(ConfigService<AllConfigType>);

  app.enableShutdownHooks();

  app.setGlobalPrefix(
    configService.getOrThrow('app.apiPrefix', { infer: true }),
    { exclude: ['/health'] },
  );

  app.useGlobalPipes(new ValidationPipe());
  app.useGlobalInterceptors(new ResponseInterceptor());

  const tenantId = configService.getOrThrow<string>('app.tenantId', {
    infer: true,
  });
  const platformId = configService.getOrThrow<string>('app.platformId', {
    infer: true,
  });
  // Swagger configuration
  const config = new DocumentBuilder()
    .setTitle('Audit Log Documentation')
    .setDescription(
      `
      Complete API documentation with data examples.
      
      **Required Headers:**
      - **tenantid**: Tenant ID (default: ${tenantId})
      - **platformid**: Platform ID (default: ${platformId})
    `,
    )
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api-docs', app, document);

  app.use(morgan('combined'));

  app.enableCors({
    origin: '*',
  });

  await app.listen(configService.getOrThrow('app.port', { infer: true }));
}

bootstrap();
