import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../../src/app.module';

describe('Components (e2e)', () => {
  let app: INestApplication;
  let createdFormId: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  const tenantId = 'T203';
  const platformId = 'P203';
  const module = 'module1';

  const createFormDto = {
    tenantId: tenantId,
    platformId: platformId,
    formId: '507f1f77bcf86cd799439011',
    templateId: '507f1f77bcf86cd799439012',
    status: 'active',
    data: {
      field1: 'value1',
      field2: 'value2',
      field3: 'value3',
    },
    module: module,
  };
  const invalidId = '507f1f77bcf86cd799439012';

  describe('POST /forms/:module', () => {
    it('should create a new form', async () => {
      const response = await request(app.getHttpServer())
        .post(`/forms/${module}`)
        .set('tenantid', tenantId)
        .set('platformid', platformId)
        .send(createFormDto)
        .expect(201);

      expect(response.body).toHaveProperty('_id');
      expect(response.body.formId).toBe(createFormDto.formId);
      createdFormId = response.body._id;
    });

    it('should return a bad request for invalid form data', async () => {
      const invalidFormDto = { formId: '' };

      const response = await request(app.getHttpServer())
        .post(`/forms/${module}`)
        .set('tenantid', tenantId)
        .set('platformid', platformId)
        .send(invalidFormDto)
        .expect(400);

      expect(response.body.message).toContain('Failed to create form record.');
    });
  });

  describe('GET /forms/:module/:id', () => {
    it('should retrieve a form by ID', async () => {
      const response = await request(app.getHttpServer())
        .get(`/forms/${module}/${createdFormId}`)
        .set('tenantid', tenantId)
        .set('platformid', platformId)
        .expect(200);

      expect(response.body).toHaveProperty('_id', createdFormId);
    });

    it('should return not found for invalid ID', async () => {
      const response = await request(app.getHttpServer())
        .get(`/forms/${module}/${invalidId}`)
        .set('tenantid', tenantId)
        .set('platformid', platformId)
        .expect(404);
      expect(response.body.message).toBe(
        `Form with ID ${invalidId} not found in module ${module}`,
      );
    });
  });

  describe('PUT /forms/:module/:id', () => {
    it('should update a form by ID', async () => {
      const updateFormDto = { status: 'inactive' };

      const response = await request(app.getHttpServer())
        .put(`/forms/${module}/${createdFormId}`)
        .set('tenantid', tenantId)
        .set('platformid', platformId)
        .send(updateFormDto)
        .expect(200);

      expect(response.body.status).toBe('inactive');
    });

    it('should return not found for invalid ID during update', async () => {
      const updateFormDto = { status: 'inactive' };

      const response = await request(app.getHttpServer())
        .put(`/forms/${module}/${invalidId}`)
        .set('tenantid', tenantId)
        .set('platformid', platformId)
        .send(updateFormDto)
        .expect(400);

      expect(response.body.message).toBe(
        `Form with ID ${invalidId} not found for update in module ${module}`,
      );
    });
  });

  describe('DELETE /forms/:module/:id', () => {
    it('should soft delete a form by ID', async () => {
      const response = await request(app.getHttpServer())
        .delete(`/forms/${module}/${createdFormId}`)
        .set('tenantid', tenantId)
        .set('platformid', platformId)
        .expect(200);

      expect(response.body).toHaveProperty('_id', createdFormId);
      expect(response.body.isDeleted).toBe(true);
    });

    it('should return not found for invalid ID during delete', async () => {
      const response = await request(app.getHttpServer())
        .delete(`/forms/${module}/${invalidId}`)
        .set('tenantid', tenantId)
        .set('platformid', platformId)
        .expect(400);

      expect(response.body.message).toBe(
        `Form with ID ${invalidId} not found for delete in module ${module}`,
      );
    });
  });
});
