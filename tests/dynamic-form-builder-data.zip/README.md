# Dynamic Form Builder Data API

This is a **Dynamic Form Builder Data API** built with **NestJS**. It allows you to create, read, update, and delete dynamic forms for various modules. The forms are stored in a MongoDB database, and each form can have custom fields and data.

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Available Scripts](#available-scripts)
- [Project Structure](#project-structure)
- [Dependencies](#dependencies)
- [Testing](#testing)
- [License](#license)

## Features

- **Dynamic Form Data**: APIs for storing and getting form data.
- **Request Sanitization**: DOMPurify and sanitize-html for request sanitization.
- **Validation**: Uses class-validator for input validation.
- **Database Integration**: MongoDB integration using Mongoose.
- **Microservices Support**: Built-in support for microservices using NestJS's microservices module.
- **Swagger Documentation**: API documentation using Swagger.
- **Logging**: Integrated logging with Winston.
- **Health Checks**: Application health check endpoints using NestJS Terminus.

## Installation

### Prerequisites

Ensure you have the following installed:

- **Node.js** (v16 or later)
- **npm** or **yarn**
- **MongoDB** (running locally or via a cloud provider)

### Clone the repository

```bash
git clone git@bitbucket.org:impexdocs/dynamic-form-builder-data.git
cd dynamic-form-builder-data
```

## Project Structure

```bash
src/
├── shared/               # Shared functionality across modules (e.g., logging, validation, error handling)
│   ├── exceptions/       # Custom decorators
│   ├── middleware/          # Custom exception filters
│   ├── interceptors/     # Custom interceptors for response transformation
│   ├── pipes/            # Validation and transformation pipes
├── modules/              # Core functionality of the service
│   ├── form-data/        # Form data management (create, query, delete form data)
│   ├── common/           # Health check endpoints for service monitoring
├── config/               # Configuration files for environment variables and app settings
├── health/               # Health check endpoints for service monitoring
├── main.ts               # Application entry point for NestJS
├── app.module.ts         # Root module that imports and configures services
└── app.controller.ts     # Root-level controller (e.g., health check route)
```

## Environment Configuration

### MongoDB Configuration

MONGO_URI=mongodb://localhost:27017/dynamic-form-db-data

### Application Port (default is 3000)

PORT=3000

### API Key for external integrations or additional security

X_API_KEY=your_api_key_here

### Key Points:

- **Install Dependencies**: Added `npm install` and `yarn install` before running the app.
- **Test Commands**: Detailed instructions for running unit tests, e2e tests, and generating a coverage report.
- **Swagger Documentation**: Included instructions on accessing the Swagger UI once the app is running.
