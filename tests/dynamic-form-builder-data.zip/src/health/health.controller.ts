import { Controller, Get, Logger } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import {
  HealthCheck,
  HealthCheckService,
  HealthCheckResult,
  HealthIndicatorResult,
} from '@nestjs/terminus';
import { DatabaseHealthIndicator } from './indicators/database.health';
// import { RedisHealthIndicator } from './indicators/redis.health';
import { ExternalApiHealthIndicator } from './indicators/external-api.health';
import { DiskHealthIndicator } from './indicators/disk-storage.health';
import { MemoryHealthIndicator } from './indicators/memory.health';

@ApiTags('Health')
@Controller('health')
export class HealthController {
  private readonly logger = new Logger(HealthController.name);

  constructor(
    private health: HealthCheckService,
    private db: DatabaseHealthIndicator,
    // private redis: RedisHealthIndicator,
    private externalApi: ExternalApiHealthIndicator,
    private diskStorage: DiskHealthIndicator,
    private memory: MemoryHealthIndicator,
  ) {}

  @Get()
  @HealthCheck()
  async check(): Promise<HealthCheckResult> {
    try {
      return await this.health.check([
        this.getDatabaseHealth.bind(this),
        // this.getRedisHealth.bind(this),
        this.checkExternalApiHealth.bind(this),
        this.getDiskHealth.bind(this),
        this.getMemoryHealth.bind(this),
      ]);
    } catch (error) {
      this.logger.error('Health check failed:', error.message);
      throw error;
    }
  }

  private async getDatabaseHealth(): Promise<HealthIndicatorResult> {
    return this.db.isHealthy('database');
  }

  private async checkExternalApiHealth(): Promise<HealthIndicatorResult> {
    try {
      return await this.externalApi.isHealthy('externalApi', {
        url: 'https://www.google.com/',
        timeout: 3000,
        validateStatus: (status) => status < 400,
      });
    } catch (error) {
      const statusCode = error?.response?.status || null;
      return {
        externalApi: {
          status: 'down',
          message: 'Failed to check external API health',
          statusCode,
        },
      };
    }
  }

  private async getDiskHealth(): Promise<HealthIndicatorResult> {
    return this.diskStorage.isHealthy('disk');
  }

  private async getMemoryHealth(): Promise<HealthIndicatorResult> {
    return this.memory.isHealthy('memory');
  }
}
