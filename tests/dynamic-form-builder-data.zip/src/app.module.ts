import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { LoggerModule } from './logging/error-log/logger.module';
import { ConfigModule } from '@nestjs/config';
import appConfig from './config/app.config';
import databaseConfig from './database/config/database.config';
import { DatabaseModule } from './database/database.module';
import { HealthModule } from './health/health.module';
import { AuditLogModule } from './logging/audit-log/audit-log.module';
import { RequestSanitizationMiddleware } from './shared/middleware/request-sanitization.middleware';
import { ValidateMiddleware } from './shared/middleware/validate.middleware';
import { TenantsModule } from './config/tenants/tenants.module';
import { DynamicFormModule } from './modules/dynamic-form/dynamic-form.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: `.env`,
      load: [appConfig, databaseConfig],
    }),
    DatabaseModule,
    LoggerModule,
    HealthModule,
    AuditLogModule,
    TenantsModule,
    DynamicFormModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer
      .apply(RequestSanitizationMiddleware, ValidateMiddleware)
      .exclude('health')
      .forRoutes('*');
  }
}
