export interface AppConfig {
  nodeEnv: string;
  name: string;
  workingDirectory: string;
  frontendDomain?: string;
  backendDomain: string;
  port: number;
  apiPrefix: string;
  allowedOrigins: string[];
  platformId: string;
  tenantId: string;
  userId: string;
  xApiKey: string;
  auditLogBaseUrl: string;
}
