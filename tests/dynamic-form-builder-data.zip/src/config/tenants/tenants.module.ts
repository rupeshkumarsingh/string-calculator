import { Module } from '@nestjs/common';
import { TenantPlatformService } from './tenant-platform.service';

@Module({
  providers: [TenantPlatformService],
  exports: [TenantPlatformService],
})
export class TenantsModule {}
