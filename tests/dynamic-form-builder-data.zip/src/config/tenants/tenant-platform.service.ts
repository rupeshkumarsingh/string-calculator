import { NotFoundException } from '@nestjs/common';

export interface Tenant {
  tenantId: string;
  name: string;
  platformId: string;
  appId: string;
  apiKeys: {
    publicKey: string;
    privateKey: string;
  };
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TenantConfig {
  tenants: Tenant[];
}

export class TenantPlatformService {
  private config: TenantConfig;

  constructor() {
    this.config = {
      tenants: [
        {
          tenantId: 'T203',
          name: 'Tenant 1',
          platformId: 'P203',
          appId: 'com.example.app',
          apiKeys: {
            publicKey: 'Tenant1',
            privateKey: 'Tenant1',
          },
          isActive: true,
          createdAt: '2023-01-01T12:00:00Z',
          updatedAt: '2024-12-01T12:00:00Z',
        },
        {
          tenantId: 'T501',
          name: 'Tenant 2',
          platformId: 'P501',
          appId: 'com.example.app2',
          apiKeys: {
            publicKey: 'Tenant1',
            privateKey: 'Tenant2',
          },
          isActive: false,
          createdAt: '2023-06-15T09:30:00Z',
          updatedAt: '2024-10-01T15:00:00Z',
        },
      ],
    };
  }

  getTenants(): Tenant[] {
    return this.config.tenants;
  }

  validateTenantAndPlatform(tenantId: string, platformId: string): boolean {
    const isValid = this.config.tenants.some(
      (entry) => entry.tenantId === tenantId && entry.platformId === platformId,
    );

    if (!isValid) {
      throw new NotFoundException(
        `Tenant ID: ${tenantId} or Platform ID: ${platformId} is invalid.`,
      );
    }

    return true;
  }
}
