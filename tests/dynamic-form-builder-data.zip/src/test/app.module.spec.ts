import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../app.module';
import { AppController } from '../app.controller';
import { AppService } from '../app.service';
import { MiddlewareConsumer } from '@nestjs/common';

import { HealthModule } from '../health/health.module';
import { DatabaseModule } from '../database/database.module';
import { TenantsModule } from '../config/tenants/tenants.module';
import { RequestSanitizationMiddleware } from '../shared/middleware/request-sanitization.middleware';
import { ValidateMiddleware } from '../shared/middleware/validate.middleware';

describe('AppModule', () => {
  let appModule: TestingModule;
  let appController: AppController;
  let appService: AppService;

  beforeEach(async () => {
    appModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    appController = appModule.get<AppController>(AppController);
    appService = appModule.get<AppService>(AppService);
  });

  it('should be defined', () => {
    expect(appModule).toBeDefined();
    expect(appController).toBeDefined();
    expect(appService).toBeDefined();
  });

  it('should configure modules correctly', () => {
    const healthModule = appModule.get(HealthModule);
    const databaseModule = appModule.get(DatabaseModule);
    const tenantsModule = appModule.get(TenantsModule);

    expect(healthModule).toBeDefined();
    expect(databaseModule).toBeDefined();
    expect(tenantsModule).toBeDefined();
  });

  it('should configure middlewares correctly', () => {
    // Mock the MiddlewareConsumer
    const middlewareConsumer = {
      apply: jest.fn().mockReturnThis(),
      exclude: jest.fn().mockReturnThis(),
      forRoutes: jest.fn().mockReturnThis(),
    } as unknown as MiddlewareConsumer;

    const appInstance = appModule.get(AppModule);
    appInstance.configure(middlewareConsumer);

    expect(middlewareConsumer.apply).toHaveBeenCalledWith(
      RequestSanitizationMiddleware,
      ValidateMiddleware,
    );
    expect(middlewareConsumer.apply).toHaveBeenCalledTimes(1);
  });
});
