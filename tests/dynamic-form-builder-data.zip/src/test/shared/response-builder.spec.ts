import { HttpException } from '@nestjs/common';
import { ResponseBuilder } from '../../shared/utils/response.builder';
import { Request } from 'express';
import {
  RESPONSE_CODES,
  RESPONSE_MESSAGES,
  ERROR_CODES,
} from '../../shared/utils/constants';

describe('ResponseBuilder', () => {
  describe('buildErrorResponse', () => {
    it('should return default error details for exceptions without message array', () => {
      const mockRequest = {
        url: '/api/test',
      } as Request;

      const mockException = new HttpException('Something went wrong', 500);

      const errorResponse = ResponseBuilder.buildErrorResponse(
        mockException,
        mockRequest,
      );

      expect(errorResponse).toEqual({
        status: 'fail',
        statusCode: 500,
        errorCode: ERROR_CODES.E_SERVER_001,
        errorType: 'ServerError',
        message: 'Something went wrong',
        details: [],
        timestamp: expect.any(String),
        path: '/api/test',
      });
    });
  });

  describe('buildSuccessResponse', () => {
    it('should build a valid success response with default values', () => {
      const data = { id: 1, name: 'Test' };

      const successResponse = ResponseBuilder.buildSuccessResponse(data);

      expect(successResponse).toEqual({
        status: 'success',
        data,
        message: RESPONSE_MESSAGES.SUCCESS,
      });
    });

    it('should build a valid success response with custom status and message', () => {
      const data = { id: 1, name: 'Test' };
      const options = {
        status: 'custom-success',
        message: 'Custom success message',
      };

      const successResponse = ResponseBuilder.buildSuccessResponse(
        data,
        options,
      );

      expect(successResponse).toEqual({
        status: 'custom-success',
        data,
        message: 'Custom success message',
      });
    });
  });

  describe('Helper methods', () => {
    it('should map status codes to error codes', () => {
      const errorCode = ResponseBuilder['getErrorCode'](
        RESPONSE_CODES.VALIDATION_ERROR,
      );
      expect(errorCode).toBe(ERROR_CODES.E_VALIDATION_001);
    });

    it('should map status codes to error types', () => {
      const errorType = ResponseBuilder['getErrorType'](
        RESPONSE_CODES.UNAUTHORIZED,
      );
      expect(errorType).toBe('AuthenticationError');
    });

    it('should return empty array for exceptions with no details', () => {
      const mockException = new HttpException('Error occurred', 500);
      const details = ResponseBuilder['getErrorDetails'](mockException);

      expect(details).toEqual([]);
    });

    it('should extract detailed messages from exception response', () => {
      const mockException = new HttpException(
        { message: ['Error 1', 'Error 2'], statusCode: 400 },
        400,
      );

      const details = ResponseBuilder['getErrorDetails'](mockException);

      expect(details).toEqual([{ message: 'Error 1' }, { message: 'Error 2' }]);
    });
  });
});
