import { Test, TestingModule } from '@nestjs/testing';
import { ResponseInterceptor } from '../../shared/interceptors/response.interceptor';
import { ExecutionContext, CallHandler } from '@nestjs/common';
import { of } from 'rxjs';
import { ResponseBuilder } from '../../shared/utils/response.builder';

jest.mock('../../shared/utils/response.builder');

describe('ResponseInterceptor', () => {
  let interceptor: ResponseInterceptor<unknown>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ResponseInterceptor],
    }).compile();

    interceptor = module.get<ResponseInterceptor<unknown>>(ResponseInterceptor);
  });

  it('should be defined', () => {
    expect(interceptor).toBeDefined();
  });

  it('should modify the response data using formatResponse', async () => {
    const mockData = { key: 'value' };
    const mockMessage = 'Operation successful';
    const mockResponse = { message: mockMessage };

    ResponseBuilder.buildSuccessResponse = jest.fn().mockReturnValue({
      status: 'success',
      data: mockData,
      message: mockMessage,
    });

    const mockExecutionContext = {
      switchToHttp: jest.fn().mockReturnValue({
        getResponse: jest.fn().mockReturnValue(mockResponse),
      }),
    } as unknown as ExecutionContext;

    const mockCallHandler = {
      handle: jest.fn().mockReturnValue(of(mockData)),
    } as unknown as CallHandler;

    const result = await interceptor
      .intercept(mockExecutionContext, mockCallHandler)
      .toPromise();

    expect(result).toEqual({
      status: 'success',
      data: mockData,
      message: mockMessage,
    });

    expect(ResponseBuilder.buildSuccessResponse).toHaveBeenCalledWith(
      mockData,
      {
        message: mockMessage,
      },
    );
  });

  it('should handle empty response message and use default', async () => {
    const mockData = { key: 'value' };
    const mockResponse = {}; // No message provided

    ResponseBuilder.buildSuccessResponse = jest.fn().mockReturnValue({
      status: 'success',
      data: mockData,
      message: 'Operation successful',
    });

    const mockExecutionContext = {
      switchToHttp: jest.fn().mockReturnValue({
        getResponse: jest.fn().mockReturnValue(mockResponse),
      }),
    } as unknown as ExecutionContext;

    const mockCallHandler = {
      handle: jest.fn().mockReturnValue(of(mockData)),
    } as unknown as CallHandler;

    const result = await interceptor
      .intercept(mockExecutionContext, mockCallHandler)
      .toPromise();

    expect(result).toEqual({
      status: 'success',
      data: mockData,
      message: 'Operation successful',
    });

    expect(ResponseBuilder.buildSuccessResponse).toHaveBeenCalledWith(
      mockData,
      {
        message: 'Operation successful',
      },
    );
  });
});
