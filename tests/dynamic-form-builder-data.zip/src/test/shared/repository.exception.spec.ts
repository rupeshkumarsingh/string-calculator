import { RepositoryException } from '../../shared/exceptions/repository.exception';
import { HttpStatus } from '@nestjs/common';

describe('RepositoryException', () => {
  it('should be defined', () => {
    const exception = new RepositoryException('Test message');
    expect(exception).toBeDefined();
  });

  it('should correctly instantiate with custom message, error, and status', () => {
    const message = 'Custom message';
    const error = 'Custom error';
    const status = HttpStatus.BAD_REQUEST;

    const exception = new RepositoryException(message, error, status);

    expect(exception.message).toBe(error);
    expect(exception.getStatus()).toBe(status);
  });
});
