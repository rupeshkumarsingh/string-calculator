import { Test, TestingModule } from '@nestjs/testing';
import { DynamicFormController } from '../../modules/dynamic-form/application/dynamic-form.controller';
import { DynamicFormService } from '../../modules/dynamic-form/application/dynamic-form.service';
import { LoggerService } from '../../logging/error-log/logger.service';
import {
  BadRequestException,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { CreateFormDto } from '../../modules/dynamic-form/application/dto/create-form.dto';
import { UpdateFormDto } from '../../modules/dynamic-form/application/dto/update-form.dto';
import { PaginationDto } from '../../modules/common/pagination/dto/pagination.dto';
import { Types } from 'mongoose';
import { DynamicForm } from '../../modules/dynamic-form/infrastructure/schemas/dynamic-form.schema';
import { PaginatedResult } from '../../modules/common/pagination/interfaces/paginated-result.interface';

describe('DynamicFormController', () => {
  let controller: DynamicFormController;
  let service: DynamicFormService;
  let logger: LoggerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DynamicFormController],
      providers: [
        {
          provide: DynamicFormService,
          useValue: {
            create: jest.fn(),
            getById: jest.fn(),
            updateById: jest.fn(),
            softDeleteById: jest.fn(),
            findAll: jest.fn(),
          },
        },
        {
          provide: LoggerService,
          useValue: {
            log: jest.fn(),
            error: jest.fn(),
          },
        },
      ],
    }).compile();

    controller = module.get<DynamicFormController>(DynamicFormController);
    service = module.get<DynamicFormService>(DynamicFormService);
    logger = module.get<LoggerService>(LoggerService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('create', () => {
    it('should create a form successfully', async () => {
      const createFormDto: CreateFormDto = {
        tenantId: 'tenant1',
        platformId: 'platform1',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: {},
        module: 'module1',
      };

      const result: DynamicForm = {
        id: '1',
        isDeleted: false,
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: 'user1',
        updatedBy: 'user2',
        ...createFormDto,
      } as DynamicForm;

      jest.spyOn(service, 'create').mockResolvedValue(result);

      const response = await controller.create('module1', createFormDto);

      expect(response).toEqual(result);
      expect(service.create).toHaveBeenCalledWith(createFormDto);
    });

    it('should throw BadRequestException if create fails', async () => {
      const createFormDto: CreateFormDto = {
        tenantId: 'tenant1',
        platformId: 'platform1',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: {},
        module: 'module1',
      };

      jest.spyOn(service, 'create').mockRejectedValue(new Error('Some error'));

      await expect(controller.create('module1', createFormDto)).rejects.toThrow(
        BadRequestException,
      );
      expect(logger.error).toHaveBeenCalledWith(
        "Error occurred while creating a record in module 'module1'.",
        expect.any(String),
      );
    });
  });

  describe('getById', () => {
    it('should return a form by ID', async () => {
      const form: DynamicForm = {
        id: '1',
        module: 'module1',
        tenantId: 'tenant1',
        platformId: 'platform1',
        formId: new Types.ObjectId(),
        templateId: new Types.ObjectId(),
        status: 'active',
        data: {},
      } as DynamicForm;
      jest.spyOn(service, 'getById').mockResolvedValue(form);

      const result = await controller.getById('module1', '1');
      expect(result).toEqual(form);
      expect(service.getById).toHaveBeenCalledWith('module1', '1');
    });
    it('should throw NotFoundException if form is not found', async () => {
      jest.spyOn(service, 'getById').mockResolvedValue(null);

      await expect(controller.getById('module1', '1')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should throw InternalServerErrorException if an unexpected error occurs', async () => {
      const error = new Error('Unexpected error');
      jest.spyOn(service, 'getById').mockRejectedValue(error);

      await expect(controller.getById('module1', '1')).rejects.toThrow(
        InternalServerErrorException,
      );

      expect(logger.error).toHaveBeenCalledWith(
        "Error occurred while retrieving form with ID '1' in module 'module1': Unexpected error",
        expect.any(String),
      );
    });
  });

  describe('updateById', () => {
    it('should update the form successfully', async () => {
      const updateFormDto: UpdateFormDto = { data: {} };
      const updatedForm: DynamicForm = {
        id: '1',
        ...updateFormDto,
      } as DynamicForm;

      jest.spyOn(service, 'updateById').mockResolvedValue(updatedForm);

      const result = await controller.updateById('module1', '1', updateFormDto);

      expect(result).toEqual(updatedForm);
      expect(service.updateById).toHaveBeenCalledWith('module1', '1', {
        ...updateFormDto,
        data: {},
      });
    });

    it('should throw BadRequestException if update fails', async () => {
      const updateFormDto: UpdateFormDto = { data: {} };

      jest
        .spyOn(service, 'updateById')
        .mockRejectedValue(new Error('Update failed'));

      await expect(
        controller.updateById('module1', '1', updateFormDto),
      ).rejects.toThrow(BadRequestException);
      expect(logger.error).toHaveBeenCalledWith(
        "Error occurred while updating form with ID '1' in module 'module1'.",
        expect.any(String),
      );
    });

    it('should throw BadRequestException if updateFormDto is invalid', async () => {
      const updateFormDto: UpdateFormDto = {} as UpdateFormDto;

      jest
        .spyOn(service, 'updateById')
        .mockRejectedValue(new Error('Invalid input'));

      await expect(
        controller.updateById('module1', '1', updateFormDto),
      ).rejects.toThrow(BadRequestException);

      expect(logger.error).toHaveBeenCalledWith(
        "Error occurred while updating form with ID '1' in module 'module1'.",
        expect.any(String),
      );
    });
  });

  describe('softDeleteById', () => {
    it('should soft delete a form successfully', async () => {
      const form: DynamicForm = { id: '1', module: 'module1' } as DynamicForm;
      jest.spyOn(service, 'softDeleteById').mockResolvedValue(form);

      const result = await controller.softDeleteById('module1', '1');
      expect(result).toEqual(form);
      expect(service.softDeleteById).toHaveBeenCalledWith('module1', '1');
    });

    it('should throw NotFoundException if form not found during deletion', async () => {
      jest.spyOn(service, 'softDeleteById').mockResolvedValue(null);

      await expect(controller.softDeleteById('module1', '1')).rejects.toThrow(
        BadRequestException,
      );
    });

    it('should throw BadRequestException if deletion fails', async () => {
      jest
        .spyOn(service, 'softDeleteById')
        .mockRejectedValue(new Error('Deletion failed'));

      await expect(controller.softDeleteById('module1', '1')).rejects.toThrow(
        BadRequestException,
      );
      expect(logger.error).toHaveBeenCalledWith(
        "Error occurred while soft-deleting form with ID '1' in module 'module1'.",
        expect.any(String),
      );
    });
  });

  describe('findAll', () => {
    it('should return paginated forms successfully', async () => {
      const paginationDto: PaginationDto = { page: 1, limit: 10 };
      const body = { tenantId: 'tenant1', platformId: 'platform1' };

      const mockResult: PaginatedResult<DynamicForm> = {
        items: [],
        total: 0,
        page: 1,
        limit: 10,
        totalPages: 1,
      };

      jest.spyOn(service, 'findAll').mockResolvedValue(mockResult);

      const result = await controller.findAll('module1', paginationDto, body);
      expect(result).toEqual(mockResult);
      expect(service.findAll).toHaveBeenCalledWith(
        'module1',
        paginationDto,
        false,
        'tenant1',
        'platform1',
      );
    });

    it('should throw BadRequestException if findAll fails', async () => {
      const paginationDto: PaginationDto = { page: 1, limit: 10 };
      const body = { tenantId: 'tenant1', platformId: 'platform1' };

      jest
        .spyOn(service, 'findAll')
        .mockRejectedValue(new Error('Fetch failed'));

      await expect(
        controller.findAll('module1', paginationDto, body),
      ).rejects.toThrow(BadRequestException);
      expect(logger.error).toHaveBeenCalledWith(
        "Error occurred while retrieving paginated forms in module 'module1'.",
        expect.any(String),
      );
    });
  });

  it('should return empty results if pagination parameters are out of bounds', async () => {
    const paginationDto: PaginationDto = { page: 999, limit: 10 };
    const body = { tenantId: 'tenant1', platformId: 'platform1' };

    const mockResult: PaginatedResult<DynamicForm> = {
      items: [],
      total: 0,
      page: 999,
      limit: 10,
      totalPages: 0,
    };

    jest.spyOn(service, 'findAll').mockResolvedValue(mockResult);

    const result = await controller.findAll('module1', paginationDto, body);
    expect(result).toEqual(mockResult);
  });
});
