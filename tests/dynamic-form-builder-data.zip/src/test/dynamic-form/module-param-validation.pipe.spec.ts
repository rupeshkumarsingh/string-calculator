import { ModuleParamValidationPipe } from '../../modules/dynamic-form/application/pipes/module-param-validation.pipe';
import { BadRequestException } from '@nestjs/common';

describe('ModuleParamValidationPipe', () => {
  let pipe: ModuleParamValidationPipe;

  beforeEach(() => {
    pipe = new ModuleParamValidationPipe();
  });

  it('should throw BadRequestException when the module name is empty', () => {
    const emptyModuleName = '';
    expect(() => pipe.transform(emptyModuleName)).toThrow(BadRequestException);
  });

  it('should throw BadRequestException when the module name is undefined', () => {
    const undefinedModuleName: string = undefined!;
    expect(() => pipe.transform(undefinedModuleName)).toThrow(
      BadRequestException,
    );
  });

  it('should throw BadRequestException when the module name is null', () => {
    const nullModuleName: string = null!;
    expect(() => pipe.transform(nullModuleName)).toThrow(BadRequestException);
  });
});
