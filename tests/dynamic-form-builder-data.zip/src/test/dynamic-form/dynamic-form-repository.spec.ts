import { Test, TestingModule } from '@nestjs/testing';
import { DynamicFormRepository } from '../../modules/dynamic-form/infrastructure/repositories/dynamic-form-repository';
import { LoggerService } from '../../logging/error-log/logger.service';
import { Connection, FilterQuery, Model, Types } from 'mongoose';
import { DynamicForm } from '../../modules/dynamic-form/infrastructure/schemas/dynamic-form.schema';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { getConnectionToken } from '@nestjs/mongoose';
import { PaginatedResult } from '../../modules/common/pagination/interfaces/paginated-result.interface';

describe('DynamicFormRepository', () => {
  let repository: DynamicFormRepository;
  let connectionMock: Partial<Connection>;
  let modelMock: Partial<Model<DynamicForm>>;
  let loggerMock: Partial<LoggerService>;

  beforeEach(async () => {
    modelMock = {
      create: jest.fn(),
      findById: jest.fn(),
      findByIdAndUpdate: jest.fn(),
      find: jest.fn(),
      countDocuments: jest.fn(),
    };

    connectionMock = {
      model: jest.fn().mockReturnValue(modelMock),
    };

    loggerMock = {
      error: jest.fn(),
      log: jest.fn(),
      warn: jest.fn(),
    };

    (modelMock.find as jest.Mock).mockReturnValueOnce({
      sort: jest.fn().mockReturnThis(),
      skip: jest.fn().mockReturnThis(),
      limit: jest.fn().mockReturnThis(),
      exec: jest.fn(),
    });

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DynamicFormRepository,
        { provide: getConnectionToken(), useValue: connectionMock },
        { provide: LoggerService, useValue: loggerMock },
      ],
    }).compile();

    repository = module.get<DynamicFormRepository>(DynamicFormRepository);
  });

  describe('getModel', () => {
    it('should return a cached model if it exists', () => {
      const moduleName = 'testModule';
      const collectionName = 'data_testmodule';
      repository['modelCache'].set(
        collectionName,
        modelMock as Model<DynamicForm>,
      );

      const getModel = (
        repository as unknown as {
          getModel: (moduleName: string) => Model<DynamicForm>;
        }
      ).getModel;
      const result = getModel.call(repository, moduleName);

      expect(result).toBe(modelMock);
      expect(connectionMock.model).not.toHaveBeenCalled();
    });

    it('should create and cache a new model if it does not exist', () => {
      const moduleName = 'newModule';
      const collectionName = 'data_newmodule';

      const getModel = (
        repository as unknown as {
          getModel: (moduleName: string) => Model<DynamicForm>;
        }
      ).getModel;
      const result = getModel.call(repository, moduleName);

      expect(connectionMock.model).toHaveBeenCalledWith(
        collectionName,
        expect.anything(),
        collectionName,
      );
      expect(result).toBe(modelMock);
    });

    it('should throw NotFoundException if model creation fails', () => {
      const moduleName = 'invalidModule';
      (connectionMock.model as jest.Mock).mockReturnValueOnce(null);

      const getModel = (
        repository as unknown as {
          getModel: (moduleName: string) => Model<DynamicForm>;
        }
      ).getModel;

      expect(() => getModel.call(repository, moduleName)).toThrow(
        NotFoundException,
      );
      expect(loggerMock.error).toHaveBeenCalled();
    });
  });

  describe('generateCollectionName', () => {
    it('should generate a valid collection name from a module name', () => {
      const moduleName = 'Test Module';
      const result = repository['generateCollectionName'](moduleName);

      expect(result).toBe('data_test_module');
    });

    it('should sanitize collection names correctly (remove special characters)', () => {
      const moduleName = 'Test$%@!Module';
      const result = repository['generateCollectionName'](moduleName);

      expect(result).toBe('data_testmodule');
    });

    it('should return a lowercased collection name', () => {
      const moduleName = 'TestModule';
      const result = repository['generateCollectionName'](moduleName);

      expect(result).toBe('data_testmodule');
    });
  });

  describe('create', () => {
    it('should throw BadRequestException if creation fails', async () => {
      const moduleName = 'testModule';
      const formData: Partial<DynamicForm> = {
        name: 'testForm',
      } as Partial<DynamicForm>;
      modelMock.create = jest.fn().mockImplementation(() => {
        throw new Error('Creation failed');
      });

      await expect(repository.create(moduleName, formData)).rejects.toThrow(
        BadRequestException,
      );
      expect(loggerMock.error).toHaveBeenCalled();
    });
  });

  describe('getById', () => {
    it('should return a form by ID', async () => {
      const moduleName = 'testModule';
      const formId = '123';
      const form = { _id: formId, name: 'testForm' };

      // Mocking findById to return the form
      modelMock.findById = jest.fn().mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(form),
      });

      const result = await repository.getById(moduleName, formId);
      expect(result).toEqual(form);
      expect(modelMock.findById).toHaveBeenCalledWith(formId);
    });

    it('should throw NotFoundException if form is not found', async () => {
      const moduleName = 'testModule';
      const formId = '123';

      // Mocking findById to return null, simulating a form not found
      modelMock.findById = jest.fn().mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(null),
      });

      await expect(repository.getById(moduleName, formId)).rejects.toThrow(
        NotFoundException,
      );

      expect(loggerMock.warn).toHaveBeenCalledWith(
        `Form with ID ${formId} not found in module ${moduleName}`,
      );
    });

    it('should throw NotFoundException and log error if an exception occurs', async () => {
      const moduleName = 'testModule';
      const formId = '123';
      const error = new Error('Database error');

      // Mocking findById to throw an error
      modelMock.findById = jest.fn().mockReturnValueOnce({
        exec: jest.fn().mockRejectedValueOnce(error),
      });

      // Ensure logger.error is called with the error message and stack
      const loggerSpy = jest
        .spyOn(loggerMock, 'error')
        .mockImplementation(() => {});

      await expect(repository.getById(moduleName, formId)).rejects.toThrow(
        NotFoundException,
      );

      expect(loggerSpy).toHaveBeenCalledWith(
        `Form with ID ${formId} not found in module ${moduleName}`,
        error.stack,
      );
    });
  });

  describe('updateById', () => {
    it('should update a form by ID and return the updated form', async () => {
      const moduleName = 'testModule';
      const formId = '123';
      const updateData: Partial<DynamicForm> = {
        name: 'updatedName',
      } as Partial<DynamicForm>;
      const updatedForm: Partial<DynamicForm> = {
        _id: formId,
        name: 'updatedName',
      } as Partial<DynamicForm>;

      modelMock.findByIdAndUpdate = jest.fn().mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(updatedForm),
      });

      const result = await repository.updateById(
        moduleName,
        formId,
        updateData,
      );

      expect(result).toEqual(updatedForm);
      expect(modelMock.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        updateData,
        { new: true },
      );
    });

    it('should throw NotFoundException if the form to update is not found', async () => {
      const moduleName = 'testModule';
      const formId = '123';
      const updateData: Partial<DynamicForm> = {
        name: 'updatedName',
      } as Partial<DynamicForm>;

      modelMock.findByIdAndUpdate = jest.fn().mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(null),
      });

      const warnSpy = jest
        .spyOn(loggerMock, 'warn')
        .mockImplementation(() => {});

      await expect(
        repository.updateById(moduleName, formId, updateData),
      ).rejects.toThrow(NotFoundException);

      expect(warnSpy).toHaveBeenCalledWith(
        `Form with ID ${formId} not found for update in module ${moduleName}`,
      );
    });

    it('should throw BadRequestException and log error if an error occurs during the update', async () => {
      const moduleName = 'testModule';
      const formId = '123';
      const updateData: Partial<DynamicForm> = {
        name: 'updatedName',
      } as Partial<DynamicForm>;
      const error = new Error('Database error');

      // Mocking findByIdAndUpdate to throw an error during update
      modelMock.findByIdAndUpdate = jest.fn().mockReturnValueOnce({
        exec: jest.fn().mockRejectedValueOnce(error),
      });

      // Ensure logger.error is mocked before calling the method
      const errorSpy = jest
        .spyOn(loggerMock, 'error')
        .mockImplementation(() => {});

      await expect(
        repository.updateById(moduleName, formId, updateData),
      ).rejects.toThrow(BadRequestException);

      // Verify that logger.error was called with the correct message and stack trace
      expect(errorSpy).toHaveBeenCalledWith(
        `Error updating form with ID ${formId} in module ${moduleName}: ${error.message}`,
        error.stack,
      );
    });
  });

  describe('deleteById', () => {
    it('should delete a form by ID and return the result', async () => {
      const moduleName = 'testModule';
      const formId = '123';
      const deletedForm = { _id: formId, isDeleted: true };

      // Mocking findByIdAndUpdate to return the soft-deleted form
      modelMock.findByIdAndUpdate = jest.fn().mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(deletedForm),
      });

      // Ensure logger.log is mocked before calling the method
      const logSpy = jest.spyOn(loggerMock, 'log').mockImplementation(() => {});

      const result = await repository.deleteById(moduleName, formId);

      expect(result).toEqual(deletedForm);
      expect(logSpy).toHaveBeenCalledWith(
        `Successfully soft-deleted form with ID ${formId} in module ${moduleName}.`,
      );
    });

    it('should throw NotFoundException if the form to delete is not found', async () => {
      const moduleName = 'testModule';
      const formId = '123';

      // Mocking findByIdAndUpdate to return null, simulating a form not found for deletion
      modelMock.findByIdAndUpdate = jest.fn().mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(null),
      });

      // Ensure logger.warn is mocked before calling the method
      const warnSpy = jest
        .spyOn(loggerMock, 'warn')
        .mockImplementation(() => {});

      await expect(repository.deleteById(moduleName, formId)).rejects.toThrow(
        NotFoundException,
      );

      // Verify that logger.warn was called with the correct message
      expect(warnSpy).toHaveBeenCalledWith(
        `Form with ID ${formId} not found for delete in module ${moduleName}`,
      );
    });

    it('should throw BadRequestException and log error if an error occurs during deletion', async () => {
      const moduleName = 'testModule';
      const formId = '123';
      const error = new Error('Database error');

      // Mocking findByIdAndUpdate to throw an error during deletion
      modelMock.findByIdAndUpdate = jest.fn().mockReturnValueOnce({
        exec: jest.fn().mockRejectedValueOnce(error),
      });

      // Ensure logger.error is mocked before calling the method
      const errorSpy = jest
        .spyOn(loggerMock, 'error')
        .mockImplementation(() => {});

      await expect(repository.deleteById(moduleName, formId)).rejects.toThrow(
        BadRequestException,
      );

      // Verify that logger.error was called with the correct message and stack trace
      expect(errorSpy).toHaveBeenCalledWith(
        `Error soft-deleting form with ID ${formId} in module ${moduleName}: ${error.message}`,
        error.stack,
      );
    });
  });

  describe('findAllPaginated', () => {
    it('should call executePaginatedQuery with the correct parameters', async () => {
      const moduleName = 'testModule';
      const filters = { field: 'value' };
      const page = 1;
      const limit = 10;
      const sortBy = 'name';
      const sortOrder: 'asc' | 'desc' = 'asc';
      const includeDeleted = false;
      const tenantId = 'tenant123';
      const platformId = 'platform456';

      // Mock result with items of type DynamicForm
      const mockPaginatedResult: PaginatedResult<DynamicForm> = {
        items: [
          {
            _id: '1',
            name: 'form1',
            tenantId,
            platformId,
            formId: new Types.ObjectId(),
            templateId: new Types.ObjectId(),
            createdAt: new Date(),
            updatedAt: new Date(),
            isDeleted: false,
          } as Partial<DynamicForm> as DynamicForm,
        ],
        total: 1,
        page,
        limit,
        totalPages: 1,
      };

      const executePaginatedQuery = jest
        .spyOn(
          repository as unknown as {
            executePaginatedQuery: (
              model: Model<DynamicForm>,
              filters: FilterQuery<DynamicForm>,
              page: number,
              limit: number,
              sortBy: string,
              sortOrder: 'asc' | 'desc',
              includeDeleted: boolean,
              tenantId: string,
              platformId: string,
            ) => Promise<PaginatedResult<DynamicForm>>;
          },
          'executePaginatedQuery',
        )
        .mockResolvedValue(mockPaginatedResult);

      const result = await repository.findAllPaginated(
        moduleName,
        filters,
        page,
        limit,
        sortBy,
        sortOrder,
        includeDeleted,
        tenantId,
        platformId,
      );

      expect(executePaginatedQuery).toHaveBeenCalledWith(
        expect.anything(),
        filters,
        page,
        limit,
        sortBy,
        sortOrder,
        includeDeleted,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });
  });
});
