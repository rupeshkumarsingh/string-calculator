import { Test, TestingModule } from '@nestjs/testing';
import { DynamicFormService } from '../../modules/dynamic-form/application/dynamic-form.service';
import { DynamicFormRepository } from '../../modules/dynamic-form/infrastructure/repositories/dynamic-form-repository';
import { LoggerService } from '../../logging/error-log/logger.service';
import { AuditLogService } from '../../logging/audit-log/audit-log.service';
import { DynamicForm } from '../../modules/dynamic-form/infrastructure/schemas/dynamic-form.schema';
import { CreateFormDto } from '../../modules/dynamic-form/application/dto/create-form.dto';
import {
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import {
  AuditAction,
  AuditEntity,
} from '../../logging/audit-log/audit-log.enums';

import { Types } from 'mongoose'; // Import for ObjectId

describe('DynamicFormService', () => {
  let service: DynamicFormService;
  //let dynamicFormRepository: DynamicFormRepository;
  let loggerService: LoggerService;
  //let auditLogService: AuditLogService;

  const mockDynamicFormRepository = {
    create: jest.fn(),
    getById: jest.fn(),
    updateById: jest.fn(),
    deleteById: jest.fn(),
    findAllPaginated: jest.fn(),
  };

  const mockLoggerService = {
    log: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
  };

  const mockAuditLogService = {
    logAudit: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DynamicFormService,
        { provide: DynamicFormRepository, useValue: mockDynamicFormRepository },
        { provide: LoggerService, useValue: mockLoggerService },
        { provide: AuditLogService, useValue: mockAuditLogService },
      ],
    }).compile();

    service = module.get<DynamicFormService>(DynamicFormService);
    // dynamicFormRepository = module.get<DynamicFormRepository>(
    //   DynamicFormRepository,
    // );
    loggerService = module.get<LoggerService>(LoggerService);
    //auditLogService = module.get<AuditLogService>(AuditLogService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('create', () => {
    it('should successfully create a new form', async () => {
      const createFormDto: CreateFormDto = {
        module: 'test-module',
        tenantId: 'tenant-id',
        platformId: 'platform-id',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: { key: 'value' },
      };
      const mockForm: DynamicForm = {
        id: '1',
        ...createFormDto,
      } as DynamicForm;

      mockDynamicFormRepository.create.mockResolvedValue(mockForm);

      const result = await service.create(createFormDto);

      expect(mockDynamicFormRepository.create).toHaveBeenCalledWith(
        createFormDto.module,
        expect.objectContaining({
          tenantId: createFormDto.tenantId,
          platformId: createFormDto.platformId,
          formId: createFormDto.formId,
          templateId: createFormDto.templateId,
          status: createFormDto.status,
          data: expect.anything(), // validate data sanitization
        }),
      );
      expect(mockAuditLogService.logAudit).toHaveBeenCalledWith(
        expect.objectContaining({
          action: AuditAction.CREATE,
          entityName: AuditEntity.FORM_DATA,
          effectedEntityId: mockForm.id,
          newValue: mockForm,
        }),
      );
      expect(result).toEqual(mockForm);
    });

    it('should throw InternalServerErrorException if creation fails', async () => {
      const createFormDto: CreateFormDto = {
        module: 'test',
        tenantId: 'tenant-id',
        platformId: 'platform-id',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: { key: 'value' },
      };
      mockDynamicFormRepository.create.mockRejectedValue(
        new Error('Database Error'),
      );

      await expect(service.create(createFormDto)).rejects.toThrow(
        InternalServerErrorException,
      );
    });

    it('should throw BadRequestException if required fields are missing', async () => {
      const createFormDto: CreateFormDto = {
        module: 'test',
        tenantId: 'tenant-id',
        platformId: 'platform-id',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: undefined,
      };

      await expect(service.create(createFormDto)).rejects.toThrow(
        InternalServerErrorException,
      );
    });

    it('should handle invalid data format gracefully', async () => {
      const createFormDto: CreateFormDto = {
        module: 'test',
        tenantId: 'tenant-id',
        platformId: 'platform-id',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: { invalidKey: 'value' },
      };

      // Simulate validation failure
      mockDynamicFormRepository.create.mockRejectedValue(
        new Error('Invalid data format'),
      );

      await expect(service.create(createFormDto)).rejects.toThrow(
        InternalServerErrorException,
      );
    });
  });

  describe('getById', () => {
    it('should successfully return a form by ID', async () => {
      const mockForm = {
        _id: new Types.ObjectId('676ea07168597965ddba902e'),
        module: 'test-module',
        tenantId: 'tenant-id',
        platformId: 'platform-id',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: { key: 'value' },
      };

      mockDynamicFormRepository.getById.mockResolvedValue(mockForm);

      const result = await service.getById(
        'test-module',
        mockForm._id.toString(),
      );

      expect(result).toEqual(mockForm);
    });

    it('should throw NotFoundException if form is not found', async () => {
      mockDynamicFormRepository.getById.mockResolvedValue(null);

      await expect(service.getById('test-module', '1')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should throw InternalServerErrorException on error', async () => {
      mockDynamicFormRepository.getById.mockRejectedValue(new Error('Error'));

      await expect(service.getById('test-module', '1')).rejects.toThrow(
        InternalServerErrorException,
      );
    });
  });

  describe('updateById', () => {
    it('should successfully update a form', async () => {
      const mockForm: Partial<DynamicForm> = {
        _id: '1',
        module: 'test-module',
        tenantId: 'tenant-id',
        platformId: 'platform-id',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: { key: 'value' },
        isDeleted: false,
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: 'user-id',
      };
      const updateData = { status: 'inactive' };

      mockDynamicFormRepository.updateById.mockResolvedValue({
        ...mockForm,
        ...updateData,
      });

      const result = await service.updateById('test-module', '1', updateData);

      expect(result.status).toEqual('inactive');
    });

    it('should throw NotFoundException if form is not found', async () => {
      mockDynamicFormRepository.updateById.mockResolvedValue(null);

      await expect(
        service.updateById('test-module', '1', { status: 'inactive' }),
      ).rejects.toThrow(NotFoundException);
    });

    it('should throw InternalServerErrorException on error', async () => {
      mockDynamicFormRepository.updateById.mockRejectedValue(
        new Error('Error'),
      );

      await expect(
        service.updateById('test-module', '1', { status: 'inactive' }),
      ).rejects.toThrow(InternalServerErrorException);
    });
  });

  describe('softDeleteById', () => {
    it('should successfully soft-delete a form', async () => {
      const mockForm: Partial<DynamicForm> = {
        id: '1',
        module: 'test-module',
        tenantId: 'tenant-id',
        platformId: 'platform-id',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: { key: 'value' },
      };

      mockDynamicFormRepository.deleteById.mockResolvedValue(mockForm);

      const result = await service.softDeleteById('test-module', '1');

      expect(result).toEqual(mockForm);
    });

    it('should throw NotFoundException if form is not found for deletion', async () => {
      mockDynamicFormRepository.deleteById.mockResolvedValue(null);

      await expect(service.softDeleteById('test-module', '1')).rejects.toThrow(
        NotFoundException,
      );
    });

    it('should throw InternalServerErrorException on error', async () => {
      mockDynamicFormRepository.deleteById.mockRejectedValue(
        new Error('Error'),
      );

      await expect(service.softDeleteById('test-module', '1')).rejects.toThrow(
        InternalServerErrorException,
      );
    });

    it('should throw InternalServerErrorException if deletion fails due to an error', async () => {
      mockDynamicFormRepository.deleteById.mockRejectedValue(
        new Error('Error'),
      );

      await expect(service.softDeleteById('test-module', '1')).rejects.toThrow(
        InternalServerErrorException,
      );
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        'Error soft-deleting form record',
        expect.any(String),
      );
    });
  });

  describe('findAll', () => {
    it('should return paginated forms successfully', async () => {
      const mockPaginatedResult = {
        items: [
          {
            id: '1',
            module: 'test-module',
            tenantId: 'tenant-id',
            platformId: 'platform-id',
            formId: new Types.ObjectId('676ea07168597965ddba902e'),
            templateId: new Types.ObjectId('676ea07168597965ddba902e'),
            status: 'active',
            data: { key: 'value' },
          },
        ],
        total: 1,
      };

      mockDynamicFormRepository.findAllPaginated.mockResolvedValue(
        mockPaginatedResult,
      );

      const result = await service.findAll(
        'test-module',
        { page: 1, limit: 10 },
        false,
        'tenant-id',
        'platform-id',
      );

      expect(result.items).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should handle missing pagination parameters and apply defaults', async () => {
      const mockPaginatedResult = {
        items: [
          {
            id: '1',
            module: 'test-module',
            tenantId: 'tenant-id',
            platformId: 'platform-id',
            formId: new Types.ObjectId('676ea07168597965ddba902e'),
            templateId: new Types.ObjectId('676ea07168597965ddba902e'),
            status: 'active',
            data: { key: 'value' },
          },
        ],
        total: 1,
      };

      mockDynamicFormRepository.findAllPaginated.mockResolvedValue(
        mockPaginatedResult,
      );

      const result = await service.findAll(
        'test-module',
        {}, // No pagination params
        false,
        'tenant-id',
        'platform-id',
      );

      expect(result.items).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it('should handle missing query parameter and use defaults', async () => {
      const mockPaginatedResult = {
        items: [],
        total: 0,
      };

      mockDynamicFormRepository.findAllPaginated.mockResolvedValue(
        mockPaginatedResult,
      );

      const result = await service.findAll(
        'test-module',
        undefined,
        false,
        'tenant-id',
        'platform-id',
      );

      expect(result.items).toHaveLength(0);
      expect(result.total).toBe(0);
    });

    it('should throw InternalServerErrorException on error', async () => {
      mockDynamicFormRepository.findAllPaginated.mockRejectedValue(
        new Error('Error'),
      );

      await expect(
        service.findAll(
          'test-module',
          { page: 1, limit: 10 },
          false,
          'tenant-id',
          'platform-id',
        ),
      ).rejects.toThrow(InternalServerErrorException);
    });

    it('should include deleted forms when includeDeleted is true', async () => {
      const mockPaginatedResult = {
        items: [
          {
            id: '1',
            module: 'test-module',
            tenantId: 'tenant-id',
            platformId: 'platform-id',
            formId: new Types.ObjectId('676ea07168597965ddba902e'),
            templateId: new Types.ObjectId('676ea07168597965ddba902e'),
            status: 'active',
            data: { key: 'value' },
            isDeleted: true,
          },
        ],
        total: 1,
      };

      mockDynamicFormRepository.findAllPaginated.mockResolvedValue(
        mockPaginatedResult,
      );

      const result = await service.findAll(
        'test-module',
        { page: 1, limit: 10 },
        true,
        'tenant-id',
        'platform-id',
      );

      expect(result.items).toHaveLength(1);
      expect(result.items[0].isDeleted).toBe(true);
    });

    it('should log an error and throw InternalServerErrorException if something goes wrong internally', async () => {
      const error = new Error('Unexpected error');
      mockDynamicFormRepository.findAllPaginated.mockRejectedValue(error);

      await expect(
        service.findAll(
          'test-module',
          { page: 1, limit: 10 },
          false,
          'tenant-id',
          'platform-id',
        ),
      ).rejects.toThrow(InternalServerErrorException);

      expect(loggerService.error).toHaveBeenCalledWith(
        'Error fetching paginated forms',
        error.stack,
      );
    });

    it('should throw an error if tenantId or platformId is missing', async () => {
      await expect(
        service.findAll('test-module', {}, false, '', 'platform-id'),
      ).rejects.toThrow(InternalServerErrorException);

      await expect(
        service.findAll('test-module', {}, false, 'tenant-id', ''),
      ).rejects.toThrow(InternalServerErrorException);
    });
  });

  describe('logAuditAction', () => {
    it('should successfully log an audit action', async () => {
      // Create a full mock form object (remove Partial<DynamicForm>)
      const mockForm: DynamicForm = {
        _id: '1',
        module: 'test-module',
        tenantId: 'tenant-id',
        platformId: 'platform-id',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: { key: 'value' } as unknown,
      } as DynamicForm;

      // Simulate successful audit logging
      mockAuditLogService.logAudit.mockResolvedValue(undefined);

      // Call the method
      await service['logAuditAction'](
        AuditAction.CREATE,
        AuditEntity.FORM_DATA,
        mockForm,
      );

      // Verify the audit logging was called with correct parameters
      expect(mockAuditLogService.logAudit).toHaveBeenCalledWith({
        action: AuditAction.CREATE,
        entityName: AuditEntity.FORM_DATA,
        effectedEntityId: mockForm.id,
        newValue: mockForm,
      });
    });

    it('should log an error if audit logging fails', async () => {
      // Create a full mock form object (remove Partial<DynamicForm>)
      const mockForm: DynamicForm = {
        id: '1',
        module: 'test-module',
        tenantId: 'tenant-id',
        platformId: 'platform-id',
        formId: new Types.ObjectId('676ea07168597965ddba902e'),
        templateId: new Types.ObjectId('676ea07168597965ddba902e'),
        status: 'active',
        data: { key: 'value' } as unknown,
      } as DynamicForm;

      // Simulate failure in audit logging
      mockAuditLogService.logAudit.mockRejectedValue(
        new Error('Audit log error'),
      );

      // Call the method
      await service['logAuditAction'](
        AuditAction.CREATE,
        AuditEntity.FORM_DATA,
        mockForm,
      );

      // Verify that the logger.error method was called
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        'Error logging audit action',
        expect.any(Error),
      );
    });
  });
});
