import { Test, TestingModule } from '@nestjs/testing';
import { LoggerModule } from '../../../logging/error-log/logger.module';
import LoggerService from '../../../logging/error-log/logger.service';

describe('LoggerModule', () => {
  let module: TestingModule;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [LoggerModule],
    }).compile();
  });

  it('should be defined', () => {
    expect(module).toBeDefined();
  });

  it('should provide LoggerService as a global provider', async () => {
    const loggerService = module.get<LoggerService>(LoggerService);
    expect(loggerService).toBeInstanceOf(LoggerService);
  });

  it('should export LoggerService', async () => {
    const exportedProviders = module.get<LoggerService>(LoggerService);
    expect(exportedProviders).toBeInstanceOf(LoggerService);
  });
});
