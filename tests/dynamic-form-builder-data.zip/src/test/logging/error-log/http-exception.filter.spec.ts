import { HttpException, HttpStatus } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { HttpExceptionFilter } from '../../../logging/error-log/filters/http-exception.filter';
import LoggerService from '../../../logging/error-log/logger.service';
import { ResponseBuilder } from '../../../shared/utils/response.builder';
import { ArgumentsHost } from '@nestjs/common';

describe('HttpExceptionFilter', () => {
  let httpExceptionFilter: HttpExceptionFilter;
  let loggerService: LoggerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        HttpExceptionFilter,
        {
          provide: LoggerService,
          useValue: {
            error: jest.fn(),
          },
        },
      ],
    }).compile();

    httpExceptionFilter = module.get<HttpExceptionFilter>(HttpExceptionFilter);
    loggerService = module.get<LoggerService>(LoggerService);
  });

  it('should be defined', () => {
    expect(httpExceptionFilter).toBeDefined();
  });

  it('should handle HttpException and log the error', () => {
    const mockHttpException = new HttpException(
      'Forbidden',
      HttpStatus.FORBIDDEN,
    );
    const mockArgumentsHost: ArgumentsHost = {
      switchToHttp: jest.fn().mockReturnValue({
        getResponse: jest.fn().mockReturnValue({
          status: jest.fn().mockReturnThis(),
          json: jest.fn(),
        }),
        getRequest: jest.fn().mockReturnValue({
          url: '/test',
          method: 'GET',
          headers: {},
          connection: { remoteAddress: '127.0.0.1' },
        }),
      }),
    } as unknown as ArgumentsHost;

    const mockErrorResponse = {
      statusCode: HttpStatus.FORBIDDEN,
      message: 'Forbidden',
      timestamp: '2024-12-05T10:00:00.000Z',
      path: '/test',
    };

    jest
      .spyOn(ResponseBuilder, 'buildErrorResponse')
      .mockReturnValue(mockErrorResponse);

    httpExceptionFilter.catch(mockHttpException, mockArgumentsHost);

    // Verify the logger was called with the error details
    expect(loggerService.error).toHaveBeenCalledWith(
      `Error: ${mockErrorResponse.message}`,
      expect.any(String),
    );

    // Verify the response was sent with correct status and JSON
    const response = mockArgumentsHost.switchToHttp().getResponse<Response>();
    expect(response.status).toHaveBeenCalledWith(HttpStatus.FORBIDDEN);
    expect(response.json).toHaveBeenCalledWith(mockErrorResponse);
  });

  it('should handle non-HttpException errors and log them', () => {
    const mockError = new Error('Some unexpected error');
    const mockArgumentsHost: ArgumentsHost = {
      switchToHttp: jest.fn().mockReturnValue({
        getResponse: jest.fn().mockReturnValue({
          status: jest.fn().mockReturnThis(),
          json: jest.fn(),
        }),
        getRequest: jest.fn().mockReturnValue({
          url: '/test',
          method: 'GET',
          headers: {},
          connection: { remoteAddress: '127.0.0.1' },
        }),
      }),
    } as unknown as ArgumentsHost;

    httpExceptionFilter.catch(mockError, mockArgumentsHost);

    // Verify the logger was called with the error details
    expect(loggerService.error).toHaveBeenCalledWith(
      `Error: Internal server error`,
      expect.stringContaining('URL: /test'),
    );

    // Verify the response was sent with default status and JSON
    const response = mockArgumentsHost.switchToHttp().getResponse<Response>();
    expect(response.status).toHaveBeenCalledWith(
      HttpStatus.INTERNAL_SERVER_ERROR,
    );
    expect(response.json).toHaveBeenCalledWith({
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      message: 'Internal server error',
      timestamp: expect.any(String),
      path: '/test',
    });
  });
});
