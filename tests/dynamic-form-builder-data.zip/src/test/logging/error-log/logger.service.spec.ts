import { LoggerService } from '../../../logging/error-log/logger.service';
import * as winston from 'winston';

jest.mock('winston', () => ({
  createLogger: jest.fn().mockReturnValue({
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    debug: jest.fn(),
  }),
  format: {
    combine: jest.fn(),
    timestamp: jest.fn(),
    printf: jest.fn(),
    json: jest.fn(),
    colorize: jest.fn(),
  },
  transports: {
    Console: jest.fn(),
    File: jest.fn(),
  },
}));

describe('LoggerService', () => {
  let loggerService: LoggerService;
  let mockLogger: winston.Logger;

  beforeEach(() => {
    loggerService = new LoggerService();
    mockLogger = (winston.createLogger as jest.Mock).mock.results[0].value;
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should call the info method with the correct arguments in log()', () => {
    const message = 'Info message';
    const metadata = { key: 'value' };

    loggerService.log(message, metadata);

    expect(mockLogger.info).toHaveBeenCalledWith(message, metadata);
  });

  it('should call the info method with an empty object if metadata is not provided', () => {
    const message = 'Info message';

    loggerService.log(message);

    expect(mockLogger.info).toHaveBeenCalledWith(message, {});
  });

  it('should call the error method with the correct arguments in error()', () => {
    const message = 'Error message';
    const trace = 'Trace details';

    loggerService.error(message, trace);

    expect(mockLogger.error).toHaveBeenCalledWith(`${message} - ${trace}`);
  });

  it('should call the error method without trace if trace is not provided', () => {
    const message = 'Error message';

    loggerService.error(message);

    expect(mockLogger.error).toHaveBeenCalledWith(message);
  });

  it('should call the warn method with the correct arguments in warn()', () => {
    const message = 'Warning message';
    const additionalInfo = { additional: 'info' };
    const context = { context: 'info' };

    loggerService.warn(message, additionalInfo, context);

    expect(mockLogger.warn).toHaveBeenCalledWith(
      `${message} - ${JSON.stringify(additionalInfo)} - ${JSON.stringify(context)}`,
    );
  });

  it('should call the debug method with the correct arguments in debug()', () => {
    const message = 'Debug message';

    loggerService.debug(message);

    expect(mockLogger.debug).toHaveBeenCalledWith(message);
  });
});
