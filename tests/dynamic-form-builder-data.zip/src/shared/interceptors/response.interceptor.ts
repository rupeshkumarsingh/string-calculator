import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ResponseBuilder } from '../utils/response.builder';

@Injectable()
export class ResponseInterceptor<T> implements NestInterceptor<T, unknown> {
  /**
   * Intercepts outgoing responses to standardize response format
   * @param context - The execution context of the request
   * @param next - The next handler in the pipeline
   * @returns Observable<unknown> - Transformed response
   */
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    return next
      .handle()
      .pipe(map((data: T) => this.formatResponse(context, data)));
  }

  /**
   * Formats the response using the standardized ResponseBuilder
   * @param context - The execution context containing request and response objects
   * @param data - The response data
   * @returns unknown - Standardized success response
   */
  private formatResponse(context: ExecutionContext, data: T): unknown {
    const httpContext = context.switchToHttp();
    const response = httpContext.getResponse();

    const message = response?.message || 'Operation successful';
    return ResponseBuilder.buildSuccessResponse(data, { message });
  }
}
