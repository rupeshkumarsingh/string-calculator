import {
  Injectable,
  NestMiddleware,
  BadRequestException,
  Inject,
} from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { LoggerService } from '../../logging/error-log/logger.service';
import { TenantPlatformService } from '../../config/tenants/tenant-platform.service';

@Injectable()
export class ValidateMiddleware implements NestMiddleware {
  constructor(
    @Inject(LoggerService) private readonly logger: LoggerService,
    private readonly tenantPlatformService: TenantPlatformService,
  ) {}

  /**
   * Middleware to validate Tenant ID and Platform ID in the request headers.
   * @param req - Incoming request
   * @param res - Outgoing response
   * @param next - Next middleware or handler
   */
  use(req: Request, res: Response, next: NextFunction): void {
    try {
      const tenantId = this.extractHeader(req, 'tenantid');
      const platformId = this.extractHeader(req, 'platformid');

      this.validateHeader(tenantId, 'Tenant ID');
      this.validateHeader(platformId, 'Platform ID');

      if (!tenantId) {
        throw new BadRequestException(
          'Tenant ID is required and must be a valid string.',
        );
      }
      if (!platformId) {
        throw new BadRequestException(
          'Platform ID is required and must be a valid string.',
        );
      }
      this.tenantPlatformService.validateTenantAndPlatform(
        tenantId,
        platformId,
      );

      req.body.tenantId = tenantId;
      req.body.platformId = platformId;

      this.logger.log(
        `Validation successful for Tenant ID: ${tenantId}, Platform ID: ${platformId}`,
      );
      next();
    } catch (error) {
      this.logger.error(`Validation error: ${error.message}`);
      throw error;
    }
  }

  /**
   * Extracts a specific header value from the request.
   * @param req - The incoming request
   * @param headerName - The name of the header to extract
   * @returns The header value or undefined
   */
  private extractHeader(req: Request, headerName: string): string | undefined {
    const headerValue = req.headers[headerName.toLowerCase()] as
      | string
      | undefined;
    return headerValue ? headerValue.trim() : undefined;
  }

  /**
   * Validates that a header is present and not empty.
   * @param headerValue - The header value to validate
   * @param headerName - The name of the header for logging and error messages
   */
  private validateHeader(headerValue?: string, headerName?: string): void {
    if (!headerValue) {
      this.logger.warn(`Invalid or missing ${headerName}: ${headerValue}`);
      throw new BadRequestException(
        `${headerName} is required and must be a valid string.`,
      );
    }
  }
}
