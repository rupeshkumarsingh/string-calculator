import { plainToClass } from 'class-transformer';
import { validateSync, ValidationError } from 'class-validator';

/**
 * Validates the given configuration object against the provided schema.
 * @param config - The configuration object to validate.
 * @param schema - The class schema that defines the validation rules.
 * @throws Will throw an error if validation fails, detailing the validation issues.
 */
function validateConfig<T extends object>(
  config: Record<string, unknown>,
  schema: new () => T,
): void {
  // Transform the plain object to an instance of the schema class
  const validatedConfig = plainToClass(schema, config, {
    enableImplicitConversion: true, // Enable implicit conversion for types
  });

  // Validate the transformed instance
  const errors: ValidationError[] = validateSync(validatedConfig, {
    skipMissingProperties: false, // Don't skip properties that are missing
  });

  // If there are validation errors, throw an error with the details
  if (errors.length > 0) {
    throw new Error(
      `Configuration validation error: ${errors
        .map((error) => Object.values(error.constraints || {}).join(', '))
        .join(', ')}`,
    );
  }
}

export default validateConfig;
