import { HttpException } from '@nestjs/common';
import { Request } from 'express';
import { RESPONSE_CODES, RESPONSE_MESSAGES, ERROR_CODES } from './constants';

export class ResponseBuilder {
  private static readonly RESPONSE_STATUS_SUCCESS = 'success';
  private static readonly RESPONSE_STATUS_FAIL = 'fail';

  /**
   * Builds an error response object based on the provided exception.
   *
   * @param exception - The thrown HttpException.
   * @param request - The incoming request object.
   * @returns An error response with a standardized structure.
   */
  static buildErrorResponse(
    exception: HttpException,
    request: Request,
  ): Record<string, unknown> {
    const status = this.getStatusCode(exception);
    const message = this.getErrorMessage(exception);
    return {
      status: this.RESPONSE_STATUS_FAIL,
      statusCode: status,
      errorCode: this.getErrorCode(status),
      errorType: this.getErrorType(status),
      message: message,
      details: this.getErrorDetails(exception),
      timestamp: new Date().toISOString(),
      path: request.url,
    };
  }

  /**
   * Builds a success response object with optional custom status and message.
   *
   * @param data - The data to return in the response.
   * @param options - Optional parameters to customize the response.
   * @returns A success response with the provided data.
   */
  static buildSuccessResponse<T>(
    data: T,
    options: {
      status?: string;
      message?: string;
    } = {},
  ): Record<string, unknown> {
    return {
      status: options.status || this.RESPONSE_STATUS_SUCCESS,
      data,
      message: options.message || RESPONSE_MESSAGES.SUCCESS,
    };
  }

  /**
   * Helper method to extract the status code from the exception.
   *
   * @param exception - The thrown HttpException.
   * @returns The HTTP status code or the internal server error code if none is found.
   */
  private static getStatusCode(exception: HttpException): number {
    return exception.getStatus
      ? exception.getStatus()
      : RESPONSE_CODES.INTERNAL_SERVER_ERROR;
  }

  /**
   * Helper method to extract the error message from the exception.
   *
   * @param exception - The thrown HttpException.
   * @returns The error message or a generic internal server error message.
   */
  private static getErrorMessage(exception: HttpException): string {
    const response = exception.getResponse();
    if (typeof response === 'object' && response['message']) {
      return Array.isArray(response['message'])
        ? response['message'].join(', ')
        : response['message'];
    }
    return exception.message || RESPONSE_MESSAGES.INTERNAL_SERVER_ERROR;
  }

  /**
   * Helper method to map HTTP status codes to custom error codes.
   *
   * @param status - The HTTP status code.
   * @returns The corresponding error code based on the status.
   */
  private static getErrorCode(status: number): string {
    const errorCodesMap: Record<number, string> = {
      [RESPONSE_CODES.VALIDATION_ERROR]: ERROR_CODES.E_VALIDATION_001,
      [RESPONSE_CODES.UNAUTHORIZED]: ERROR_CODES.E_AUTH_001,
      [RESPONSE_CODES.FORBIDDEN]: ERROR_CODES.E_PERMISSION_001,
      [RESPONSE_CODES.NOT_FOUND]: ERROR_CODES.E_VALIDATION_001,
      [RESPONSE_CODES.INTERNAL_SERVER_ERROR]: ERROR_CODES.E_SERVER_001,
      [RESPONSE_CODES.SERVICE_UNAVAILABLE]:
        ERROR_CODES.E_SERVICE_UNAVAILABLE_001,
      [RESPONSE_CODES.CONFLICT]: ERROR_CODES.E_DUPLICATE_RECORD_001,
      //[RESPONSE_CODES.SANITIZATION_ERROR]: ERROR_CODES.E_SANITIZATION_001,
    };
    return errorCodesMap[status] || ERROR_CODES.E_SERVER_001;
  }

  /**
   * Helper method to map HTTP status codes to error types.
   *
   * @param status - The HTTP status code.
   * @returns The corresponding error type based on the status.
   */
  private static getErrorType(status: number): string {
    const errorTypesMap: Record<number, string> = {
      [RESPONSE_CODES.VALIDATION_ERROR]: 'ValidationError',
      [RESPONSE_CODES.UNAUTHORIZED]: 'AuthenticationError',
      [RESPONSE_CODES.FORBIDDEN]: 'PermissionError',
      [RESPONSE_CODES.NOT_FOUND]: 'NotFoundError',
      [RESPONSE_CODES.INTERNAL_SERVER_ERROR]: 'ServerError',
      [RESPONSE_CODES.SERVICE_UNAVAILABLE]: 'ServiceUnavailableError',
      [RESPONSE_CODES.CONFLICT]: 'DuplicateRecordError',
      //[RESPONSE_CODES.SANITIZATION_ERROR]: 'SanitizationError',
    };
    return errorTypesMap[status] || 'UnknownError';
  }

  /**
   * Helper method to extract detailed error information, such as validation issues.
   *
   * @param exception - The thrown HttpException.
   * @returns An array of error details (if available) or an empty array.
   */
  private static getErrorDetails(exception: HttpException): unknown[] {
    const response = exception.getResponse();
    if (
      typeof response === 'object' &&
      response['message'] &&
      Array.isArray(response['message'])
    ) {
      return response['message'].map((detail: string) => ({
        message: detail,
      }));
    }
    return [];
  }
}
