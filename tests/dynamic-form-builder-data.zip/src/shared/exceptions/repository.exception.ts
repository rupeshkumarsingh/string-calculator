import { HttpException, HttpStatus } from '@nestjs/common';

export class RepositoryException extends HttpException {
  constructor(
    message: string,
    error: string = '',
    status: HttpStatus = HttpStatus.INTERNAL_SERVER_ERROR,
  ) {
    super(error, status);
  }
}
