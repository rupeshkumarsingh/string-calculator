import { Model, Document, FilterQuery, Types } from 'mongoose';
import { PaginatedResult } from '../interfaces/paginated-result.interface';

export abstract class BaseRepository<T extends Document> {
  constructor(protected readonly model: Model<T>) {}

  /**
   * Retrieves a paginated list of documents from the database based on the provided filters and pagination settings.
   *
   * This method fetches documents based on provided filters and populates
   * the related documents from the specified path.
   *
   * @param {FilterQuery<T>} filters - The filters to apply to the query.
   * @param {number} page - The page number for pagination.
   * @param {number} limit - The number of items per page.
   * @param {string} sortBy - The field to sort by.
   * @param {'asc' | 'desc'} sortOrder - The sort order.
   * @param {boolean} includeDeleted - Whether to include deleted records.
   * @param {string} tenantId - The tenant ID for multi-tenancy.
   * @param {string} platformId - The platform ID.
   * @returns {Promise<PaginatedResult<T>>} - The paginated result including populated data.
   */
  async findAllPaginated(
    filters: FilterQuery<T>,
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
    includeDeleted = false,
    tenantId: string,
    platformId: string,
  ): Promise<PaginatedResult<T>> {
    const skip = (page - 1) * limit;
    const sortOptions: Record<string, 'asc' | 'desc'> = { [sortBy]: sortOrder };

    const regexFilters = Object.keys(filters).reduce(
      (acc, key) => {
        const value = filters[key];
        if (Types.ObjectId.isValid(value)) {
          acc[key] = value;
        } else if (typeof value === 'string') {
          acc[key] = { $regex: value, $options: 'i' };
        } else {
          acc[key] = value;
        }
        return acc;
      },
      {} as Record<string, unknown>,
    );

    const query: Record<string, unknown> = {
      ...(includeDeleted ? {} : { isDeleted: false }),
      ...regexFilters,
      tenantId,
      platformId,
    };
    const [items, total] = await Promise.all([
      this.model.find(query).sort(sortOptions).skip(skip).limit(limit).exec(),
      this.model.countDocuments(query).exec(),
    ]);

    return {
      items,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  /**
   * Retrieves items with related data populated from a specified path.
   *
   * This method fetches documents based on provided filters and populates
   * the related documents from the specified path.
   *
   * @param {FilterQuery<T>} filters - The filters to apply to the query.
   * @param {string} populatePath - The path to populate related data.
   * @param {number} page - The page number for pagination.
   * @param {number} limit - The number of items per page.
   * @param {string} sortBy - The field to sort by.
   * @param {'asc' | 'desc'} sortOrder - The sort order.
   * @param {boolean} includeDeleted - Whether to include deleted records.
   * @param {string} tenantId - The tenant ID for multi-tenancy.
   * @param {string} platformId - The platform ID.
   * @returns {Promise<PaginatedResult<T>>} - The paginated result including populated data.
   */
  async findAllWithPopulatedData(
    filters: FilterQuery<T>,
    populateOptions:
      | { path: string; select: string }
      | { path: string; select: string }[],
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
    includeDeleted = false,
    tenantId: string,
    platformId: string,
  ): Promise<PaginatedResult<T>> {
    const skip = (page - 1) * limit;
    const sortOptions: Record<string, 'asc' | 'desc'> = { [sortBy]: sortOrder };

    const regexFilters = Object.keys(filters).reduce(
      (acc, key) => {
        const value = filters[key];
        if (Types.ObjectId.isValid(value)) {
          acc[key] = value;
        } else if (typeof value === 'string') {
          acc[key] = { $regex: value, $options: 'i' };
        } else {
          acc[key] = value;
        }
        return acc;
      },
      {} as Record<string, unknown>,
    );

    const query: Record<string, unknown> = {
      ...(includeDeleted ? {} : { isDeleted: false }),
      ...regexFilters,
      tenantId,
      platformId,
    };

    const [items, total] = await Promise.all([
      this.model
        .find(query)
        .sort(sortOptions)
        .skip(skip)
        .limit(limit)
        .populate(populateOptions)
        .exec(),
      this.model.countDocuments(query).exec(),
    ]);

    return {
      items,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }
}
