import { FilterQuery } from 'mongoose';
import { PaginatedResult } from './paginated-result.interface';

export interface BaseRepository<T> {
  findAllPaginated(
    filter: FilterQuery<T>,
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
  ): Promise<PaginatedResult<T>>;
}
