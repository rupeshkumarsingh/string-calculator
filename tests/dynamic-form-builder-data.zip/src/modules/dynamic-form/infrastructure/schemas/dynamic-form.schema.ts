import { Schema, Prop, SchemaFactory } from '@nestjs/mongoose';
import { Status } from '../../../../shared/utils/status.enum';
import { Document, Types } from 'mongoose';

@Schema({ strict: false, timestamps: false })
export class DynamicForm extends Document {
  @Prop({ required: true })
  tenantId: string;

  @Prop({ required: true })
  platformId: string;

  @Prop({ required: true })
  formId: Types.ObjectId;

  @Prop({ required: true })
  templateId: Types.ObjectId;

  @Prop({
    type: String,
    enum: Object.values(Status),
    default: Status.ACTIVE,
    required: true,
  })
  status: string;

  @Prop({ required: true })
  module: string;

  // Dynamic data will be stored here
  @Prop({ type: Object, default: {} })
  data: Record<string, unknown>;

  @Prop({ type: Boolean, default: false })
  isDeleted: boolean;

  @Prop({ type: Date, default: Date.now })
  createdAt: Date;

  @Prop({ type: Date, default: Date.now })
  updatedAt: Date;

  @Prop({ type: String, required: false })
  createdBy: string;

  @Prop({ type: String, required: false })
  updatedBy: string;
}

// Create the schema using SchemaFactory for the DynamicForm class
export const DynamicFormSchema = SchemaFactory.createForClass(DynamicForm);

// Index to optimize queries based on `tenantId`, `platformId`, and `formId`
DynamicFormSchema.index({ tenantId: 1, platformId: 1, formId: 1 });
