import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { Connection, Model, FilterQuery } from 'mongoose';
import { DynamicForm, DynamicFormSchema } from '../schemas/dynamic-form.schema';
import { LoggerService } from '../../../../logging/error-log/logger.service';
import { PaginatedResult } from '../../../common/pagination/interfaces/paginated-result.interface';

@Injectable()
export class DynamicFormRepository {
  private readonly modelCache = new Map<string, Model<DynamicForm>>();

  constructor(
    @InjectConnection() private readonly connection: Connection,
    private readonly logger: LoggerService,
  ) {}

  /**
   * Retrieves or creates a Mongoose model for a given module.
   * @param moduleName - Name of the module
   * @returns A Mongoose model for the module
   */
  protected getModel(moduleName: string): Model<DynamicForm> {
    const trimmedModuleName = moduleName.trim();

    const collectionName = this.generateCollectionName(trimmedModuleName);

    if (!this.modelCache.has(collectionName)) {
      const model = this.connection.model<DynamicForm>(
        collectionName,
        DynamicFormSchema,
        collectionName,
      );
      this.modelCache.set(collectionName, model);
    }

    const model = this.modelCache.get(collectionName);
    if (!model) {
      const errorMessage = `Model for collection '${collectionName}' not found.`;
      this.logger.error(errorMessage);
      throw new NotFoundException(errorMessage);
    }

    return model;
  }

  /**
   * Generates a sanitized and standardized collection name for a module.
   * @param moduleName - Original module name
   * @returns A sanitized collection name
   */
  private generateCollectionName(moduleName: string): string {
    return `data_${moduleName
      .toLowerCase()
      .replace(/\s+/g, '_')
      .replace(/[^a-zA-Z0-9_]/g, '')}`;
  }

  /**
   * Creates a new form record in the specified module's collection.
   * @param module - Module name
   * @param data - Data for the new form record
   * @returns The created form document
   */
  async create(
    module: string,
    data: Partial<DynamicForm>,
  ): Promise<DynamicForm> {
    try {
      const model = this.getModel(module);
      const newForm = new model(data);
      return await newForm.save();
    } catch (error) {
      const errorMessage = `Error creating form in module ${module}: ${error.message}`;
      this.logger.error(errorMessage, error.stack);
      throw new BadRequestException('Error creating form.');
    }
  }

  /**
   * Retrieves a form by ID from the specified module's collection.
   * @param module - Module name
   * @param id - ID of the form to retrieve
   * @returns The form document or null if not found
   */
  async getById(module: string, id: string): Promise<DynamicForm | null> {
    try {
      const model = this.getModel(module);
      const form = await model.findById(id).exec();
      if (!form) {
        const errorMessage = `Form with ID ${id} not found in module ${module}`;
        this.logger.warn(errorMessage);
        throw new NotFoundException(errorMessage);
      }
      return form;
    } catch (error) {
      const errorMessage = `Form with ID ${id} not found in module ${module}`;
      this.logger.error(errorMessage, error.stack);
      throw new NotFoundException(errorMessage);
    }
  }

  /**
   * Updates a form record by ID.
   * @param module - Module name
   * @param id - ID of the form to update
   * @param updateData - Data to update the form
   * @returns The updated form document
   */
  async updateById(
    module: string,
    id: string,
    updateData: Partial<DynamicForm>,
  ): Promise<DynamicForm | null> {
    try {
      const model = this.getModel(module);

      const updatedForm = await model
        .findByIdAndUpdate(id, updateData, { new: true })
        .exec();

      if (!updatedForm) {
        const errorMessage = `Form with ID ${id} not found for update in module ${module}`;
        this.logger.warn(errorMessage);
        throw new NotFoundException(errorMessage);
      }

      return updatedForm;
    } catch (error) {
      if (error instanceof NotFoundException) {
        this.logger.warn(`NotFoundException occurred: ${error.message}`);
        throw error;
      }

      const errorMessage = `Error updating form with ID ${id} in module ${module}: ${error.message}`;
      this.logger.error(errorMessage, error.stack);
      throw new BadRequestException(errorMessage);
    }
  }

  /**
   * Soft deletes a form record by ID.
   * @param module - Module name
   * @param id - ID of the form to delete
   * @returns The updated form document with deletedAt timestamp
   */
  async deleteById(module: string, id: string): Promise<DynamicForm | null> {
    const model = this.getModel(module);
    try {
      const result = await model
        .findByIdAndUpdate(id, { isDeleted: true }, { new: true })
        .exec();
      if (!result) {
        const errorMessage = `Form with ID ${id} not found for delete in module ${module}`;
        this.logger.warn(errorMessage);
        throw new NotFoundException(errorMessage);
      }
      const successMessage = `Successfully soft-deleted form with ID ${id} in module ${module}.`;
      this.logger.log(successMessage);
      return result;
    } catch (error) {
      if (error instanceof NotFoundException) {
        this.logger.warn(`NotFoundException occurred: ${error.message}`);
        throw error;
      }
      const errorMessage = `Error soft-deleting form with ID ${id} in module ${module}: ${error.message}`;
      this.logger.error(errorMessage, error.stack);
      throw new BadRequestException(errorMessage);
    }
  }

  /**
   * Retrieves paginated results.
   * @param module - Module name
   * @param filters - Query filters
   * @param page - Page number
   * @param limit - Items per page
   * @param sortBy - Sorting field
   * @param sortOrder - Sorting order
   * @param includeDeleted - Include deleted records
   * @param tenantId - Tenant ID
   * @param platformId - Platform ID
   * @returns Paginated results
   */
  async findAllPaginated(
    module: string,
    filters: FilterQuery<DynamicForm>,
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
    includeDeleted = false,
    tenantId: string,
    platformId: string,
  ): Promise<PaginatedResult<DynamicForm>> {
    try {
      return this.executePaginatedQuery(
        this.getModel(module),
        filters,
        page,
        limit,
        sortBy,
        sortOrder,
        includeDeleted,
        tenantId,
        platformId,
      );
    } catch (error) {
      const errorMessage = `Error retrieving paginated results for module ${module}: ${error.message}`;
      this.logger.error(errorMessage, error.stack);
      throw new BadRequestException(errorMessage);
    }
  }

  /**
   * Executes the paginated query logic.
   * @param model - Mongoose model
   * @param filters - Filters to apply
   * @param page - Page number
   * @param limit - Items per page
   * @param sortBy - Sorting field
   * @param sortOrder - Sorting order
   * @param includeDeleted - Include deleted records
   * @param tenantId - Tenant ID
   * @param platformId - Platform ID
   * @returns Paginated results
   */
  private async executePaginatedQuery(
    model: Model<DynamicForm>,
    filters: FilterQuery<DynamicForm>,
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
    includeDeleted: boolean,
    tenantId: string,
    platformId: string,
  ): Promise<PaginatedResult<DynamicForm>> {
    const skip = (page - 1) * limit;
    const sortOptions = { [sortBy]: sortOrder } as Record<
      string,
      'asc' | 'desc'
    >;

    const query = {
      ...(includeDeleted ? {} : { isDeleted: false }),
      ...filters,
      tenantId,
      platformId,
    };

    //this.logger.log(`Query: ${JSON.stringify(query, null, 2)}`);

    const [items, total] = await Promise.all([
      model.find(query).sort(sortOptions).skip(skip).limit(limit).exec(),
      model.countDocuments(query).exec(),
    ]);

    return {
      items,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }
}
