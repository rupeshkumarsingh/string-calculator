import { Document, Types } from 'mongoose';

export interface IDynamicForm extends Document {
  templateId: Types.ObjectId;
  formId: Types.ObjectId;
  tenantId: string;
  platformId: string;
  data?: Record<string, unknown>;
  status: string;
  module?: string;
  isDeleted?: boolean;
  createdAt?: Date;
  updatedAt?: Date;
  createdBy?: string;
  updatedBy?: string;
}
