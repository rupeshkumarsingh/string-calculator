import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DynamicFormController } from './application/dynamic-form.controller';
import { DynamicFormService } from './application/dynamic-form.service';
import { AuditLogModule } from '../../logging/audit-log/audit-log.module';
import { DynamicFormRepository } from './infrastructure/repositories/dynamic-form-repository';

@Module({
  imports: [MongooseModule.forFeature([]), AuditLogModule],
  controllers: [DynamicFormController],
  providers: [DynamicFormService, DynamicFormRepository],
})
export class DynamicFormModule {}
