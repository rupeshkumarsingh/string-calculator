import { PipeTransform, Injectable, BadRequestException } from '@nestjs/common';
import { ModuleParamDto } from '../dto/param-module.dto';
import { validateSync } from 'class-validator';

@Injectable()
export class ModuleParamValidationPipe implements PipeTransform {
  transform(value: string): string {
    const moduleParamDto = new ModuleParamDto();
    moduleParamDto.module = value;

    const errors = validateSync(moduleParamDto);
    if (errors.length > 0) {
      throw new BadRequestException('Invalid module name');
    }

    return value;
  }
}
