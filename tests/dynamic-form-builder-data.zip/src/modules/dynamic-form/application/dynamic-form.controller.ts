import {
  Controller,
  Post,
  Body,
  HttpCode,
  HttpStatus,
  BadRequestException,
  Param,
  Get,
  Put,
  Delete,
  NotFoundException,
  Query,
  InternalServerErrorException,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiHeader,
  ApiBody,
  ApiParam,
  ApiQuery,
} from '@nestjs/swagger';
import { DynamicFormService } from './dynamic-form.service';
import { CreateFormDto } from './dto/create-form.dto';
import { IDynamicForm } from '../domain/dynamic-form';
import { LoggerService } from '../../../logging/error-log/logger.service';
import { UpdateFormDto } from './dto/update-form.dto';
import { PaginationDto } from '../../common/pagination/dto/pagination.dto';
import { ModuleParamValidationPipe } from './pipes/module-param-validation.pipe';

@ApiTags('Forms Data')
@ApiHeader({ name: 'tenantid', required: true, description: 'Tenant ID' })
@ApiHeader({ name: 'platformid', required: true, description: 'Platform ID' })
@Controller('forms/:module')
export class DynamicFormController {
  constructor(
    private readonly dynamicFormService: DynamicFormService,
    private readonly logger: LoggerService,
  ) {}

  /**
   * Create a new record in a specific module's collection.
   * @param module - The module name (from route parameter)
   * @param createFormDto - The form data DTO
   * @returns The created record
   */
  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create a new record for a specific module' })
  @ApiParam({
    name: 'module',
    description: 'The name of the module for which the record is being created',
    required: true,
  })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Record created successfully.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid form data or module.',
  })
  @ApiBody({
    type: CreateFormDto,
    description: 'Form data to create a new record',
  })
  async create(
    @Param('module', ModuleParamValidationPipe) module: string,
    @Body() createFormDto: CreateFormDto,
  ): Promise<IDynamicForm> {
    this.logger.log('Received request body:', JSON.stringify(createFormDto));

    const { tenantId, platformId, formId, templateId, status } = createFormDto;

    if (!templateId) {
      throw new BadRequestException('Failed to create form record.');
    }

    this.logger.log(
      `Received request to create a new record. ${JSON.stringify({
        module,
        tenantId,
        platformId,
        formId,
        templateId,
        status,
      })}`,
    );

    try {
      createFormDto.module = module;
      const result = await this.dynamicFormService.create(createFormDto);

      this.logger.log('Record created successfully.', {
        formId: result.id,
        module,
        tenantId,
        platformId,
      });

      return result;
    } catch (error) {
      this.logger.error(
        `Error occurred while creating a record in module '${module}'.`,
        error.stack,
      );
      throw new BadRequestException(error.message);
    }
  }

  /**
   * Get a form record by its ID.
   * @param module - The module name
   * @param id - The form ID
   * @returns The form record
   */
  @Get(':id')
  @ApiOperation({ summary: 'Retrieve a form record by its ID' })
  @ApiParam({
    name: 'module',
    description: 'The module name to which the form belongs',
    required: true,
  })
  @ApiParam({
    name: 'id',
    description: 'The ID of the form record',
    required: true,
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Form retrieved successfully.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Form with the specified ID not found.',
  })
  async getById(
    @Param('module', ModuleParamValidationPipe) module: string,
    @Param('id') id: string,
  ): Promise<IDynamicForm | null> {
    try {
      const result = await this.dynamicFormService.getById(module, id);
      if (!result) {
        throw new NotFoundException(`Form with ID ${id} not found.`);
      }
      return result;
    } catch (error) {
      this.logger.error(
        `Error occurred while retrieving form with ID '${id}' in module '${module}': ${error.message}`,
        error.stack,
      );

      if (error instanceof NotFoundException) {
        throw new NotFoundException(error.message);
      }

      throw new InternalServerErrorException('Failed to retrieve form');
    }
  }

  /**
   * Update a form record by its ID.
   * @param module - The module name
   * @param id - The form ID
   * @param updateFormDto - The updated form data
   * @returns The updated form record
   */
  @Put(':id')
  @ApiOperation({ summary: 'Update a form record by its ID' })
  @ApiParam({
    name: 'module',
    description: 'The module name to which the form belongs',
    required: true,
  })
  @ApiParam({
    name: 'id',
    description: 'The ID of the form record to be updated',
    required: true,
  })
  @ApiBody({
    type: UpdateFormDto,
    description: 'Form data to update the record',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Form updated successfully.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Form with the specified ID not found.',
  })
  async updateById(
    @Param('module', ModuleParamValidationPipe) module: string,
    @Param('id') id: string,
    @Body() updateFormDto: UpdateFormDto,
  ): Promise<IDynamicForm> {
    try {
      const { data, ...restOfUpdateData } = updateFormDto;
      const sanitizedData: Record<string, unknown> | undefined =
        data && typeof data === 'object' && data !== null
          ? (data as Record<string, unknown>)
          : undefined;

      const updatedForm = await this.dynamicFormService.updateById(module, id, {
        ...restOfUpdateData,
        data: sanitizedData,
      });
      return updatedForm;
    } catch (error) {
      this.logger.error(
        `Error occurred while updating form with ID '${id}' in module '${module}'.`,
        error.stack,
      );
      throw new BadRequestException(error.message);
    }
  }

  /**
   * Soft delete a form record by its ID.
   * @param module - The module name
   * @param id - The form ID
   * @returns The soft-deleted form record
   */
  @Delete(':id')
  @ApiOperation({ summary: 'Soft delete a form record by its ID' })
  @ApiParam({
    name: 'module',
    description: 'The module name to which the form belongs',
    required: true,
  })
  @ApiParam({
    name: 'id',
    description: 'The ID of the form record to be soft deleted',
    required: true,
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Form soft-deleted successfully.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Form with the specified ID not found.',
  })
  async softDeleteById(
    @Param('module', ModuleParamValidationPipe) module: string,
    @Param('id') id: string,
  ): Promise<IDynamicForm> {
    try {
      const result = await this.dynamicFormService.softDeleteById(module, id);
      if (!result) {
        throw new NotFoundException(`Form with ID '${id}' not found.`);
      }
      return result;
    } catch (error) {
      this.logger.error(
        `Error occurred while soft-deleting form with ID '${id}' in module '${module}'.`,
        error.stack,
      );
      throw new BadRequestException(error.message);
    }
  }

  @Get()
  @ApiOperation({ summary: 'Retrieve paginated form records' })
  @ApiParam({
    name: 'module',
    description: 'The module name to which the forms belong',
    required: true,
  })
  @ApiQuery({
    name: 'page',
    required: false,
    description: 'Page number for pagination.',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Number of items per page.',
    example: 10,
  })
  @ApiQuery({
    name: 'sortBy',
    required: false,
    description: 'Field to sort by.',
    example: 'createdAt',
  })
  @ApiQuery({
    name: 'sortOrder',
    required: false,
    description: 'Sort order: "asc" or "desc".',
    example: 'asc',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Data retrieved successfully.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid query parameters or request.',
  })
  async findAll(
    @Param('module', ModuleParamValidationPipe) module: string,
    @Query() query: PaginationDto = {},
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<{ items: IDynamicForm[]; total: number }> {
    try {
      this.logger.log(`Fetching module ${module} data`);
      const includeDeleted = query.includeDeleted ?? false;
      const result = await this.dynamicFormService.findAll(
        module,
        query,
        includeDeleted,
        body.tenantId,
        body.platformId,
      );

      this.logger.log(
        `Fetched ${result.items.length} forms out of ${result.total} for module '${module}'.`,
      );

      return result;
    } catch (error) {
      this.logger.error(
        `Error occurred while retrieving paginated forms in module '${module}'.`,
        error.stack,
      );
      throw new BadRequestException(error.message);
    }
  }
}
