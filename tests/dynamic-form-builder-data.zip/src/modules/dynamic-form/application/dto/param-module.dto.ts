import { IsString, Matches, Length } from 'class-validator';

export class ModuleParamDto {
  @IsString({ message: 'Module must be a string.' })
  @Length(3, 30, { message: 'Module must be between 3 and 30 characters.' })
  @Matches(/^[a-zA-Z0-9_]+$/, {
    message:
      'Module name can only contain alphanumeric characters and underscores.',
  })
  module: string;
}
