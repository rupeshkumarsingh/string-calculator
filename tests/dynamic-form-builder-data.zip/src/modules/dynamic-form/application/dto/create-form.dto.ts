import {
  IsString,
  IsNotEmpty,
  IsObject,
  IsMongoId,
  Length,
  IsEnum,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Types } from 'mongoose';
import { Optional } from '@nestjs/common';
import { Status } from '../../../../shared/utils/status.enum';

export class CreateFormDto {
  @ApiProperty({
    description: 'The unique identifier for the tenant.',
    type: String,
    example: 'tenant123',
  })
  @IsString()
  @IsNotEmpty({ message: 'Tenant ID is required.' })
  @Length(3, 30, { message: 'Tenant ID must be between 3 and 30 characters.' })
  tenantId: string;

  @ApiProperty({
    description: 'The unique identifier for the platform.',
    type: String,
    example: 'platformABC',
  })
  @IsNotEmpty({ message: 'Platform ID is required.' })
  @Length(3, 30, { message: 'Tenant ID must be between 3 and 30 characters.' })
  platformId: string;

  @ApiProperty({
    description: 'The unique identifier for the form.',
    type: String,
    example: '676e8444f0dc2222c6597358',
  })
  @IsNotEmpty({ message: 'Form ID is required.' })
  @IsMongoId({ message: 'Form ID must be a valid format' })
  formId: Types.ObjectId;

  @ApiProperty({
    description: 'The unique identifier for the template.',
    type: String,
    example: '676e8451f0dc2222c659735b',
  })
  @IsNotEmpty({ message: 'Template ID is required.' })
  @IsMongoId({ message: 'Template ID must be a valid format.' })
  templateId: Types.ObjectId;

  @ApiProperty({
    description: 'Data associated with the form (flexible structure).',
    type: Object,
    example: { field1: 'value1', field2: 'value2' },
  })
  @IsObject({ message: 'Data must be an object.' })
  data: unknown;

  @ApiProperty({
    description: 'Status of the form (e.g., active, inactive).',
    type: String,
    example: 'active',
  })
  @IsEnum(Status, { message: 'Status must be "active" or "inactive".' })
  @IsString()
  @IsNotEmpty({ message: 'Status is required.' })
  status: string;

  @Optional()
  module: string;
}
