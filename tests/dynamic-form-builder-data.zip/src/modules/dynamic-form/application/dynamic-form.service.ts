import {
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { DynamicForm } from '../infrastructure/schemas/dynamic-form.schema';
import { CreateFormDto } from './dto/create-form.dto';
import { AuditLogService } from '../../../logging/audit-log/audit-log.service';
import { LoggerService } from '../../../logging/error-log/logger.service';
import {
  AuditAction,
  AuditEntity,
} from '../../../logging/audit-log/audit-log.enums';
import { DynamicFormRepository } from '../infrastructure/repositories/dynamic-form-repository';
import { PaginatedResult } from '../../common/pagination/interfaces/paginated-result.interface';
import { PaginationDto } from '../../common/pagination/dto/pagination.dto';

@Injectable()
export class DynamicFormService {
  constructor(
    private readonly dynamicFormRepository: DynamicFormRepository,
    private readonly logger: LoggerService,
    private readonly auditLog: AuditLogService,
  ) {}

  /**
   * Creates a new form record in the specified module's collection.
   * @param createFormDto - DTO containing the form data
   * @returns The newly created form document
   */
  async create(createFormDto: CreateFormDto): Promise<DynamicForm> {
    const { module, tenantId, platformId, formId, templateId, status, data } =
      createFormDto;

    this.logger.log(`Creating new form record in module '${module}'`, {
      tenantId,
      platformId,
      formId,
      templateId,
    });
    const sanitizedData: Record<string, unknown> | undefined =
      this.validateData(data);
    try {
      const formData = await this.dynamicFormRepository.create(module, {
        tenantId,
        platformId,
        formId,
        templateId,
        status,
        module,
        data: sanitizedData,
      });

      await this.logAuditAction(
        AuditAction.CREATE,
        AuditEntity.FORM_DATA,
        formData,
      );

      this.logger.log(`Form created successfully: ${formData.id}`, {
        tenantId,
        platformId,
        formId,
      });

      return formData;
    } catch (error) {
      this.logger.error('Error creating form record', error.stack);
      throw new InternalServerErrorException('Failed to create form record');
    }
  }

  /**
   * Retrieves a form by its ID.
   * @param module - The module name
   * @param id - The form ID
   * @returns The form data or throws NotFoundException
   */
  async getById(module: string, id: string): Promise<DynamicForm | null> {
    try {
      const form = await this.dynamicFormRepository.getById(module, id);
      if (!form) {
        this.logger.warn(`Form with ID ${id} not found in module ${module}`);
        throw new NotFoundException(`Form with ID ${id} not found`);
      }
      return form;
    } catch (error) {
      if (error instanceof NotFoundException) {
        this.logger.warn(`Form with ID ${id} not found in module ${module}`);
        throw error;
      }
      this.logger.error('Error retrieving form by ID', error.stack);
      throw new InternalServerErrorException('Failed to retrieve form');
    }
  }

  /**
   * Updates a form record by ID.
   * @param module - The module name
   * @param id - The form ID
   * @param updateData - The data to update
   * @returns The updated form document
   */
  async updateById(
    module: string,
    id: string,
    updateData: Partial<DynamicForm>,
  ): Promise<DynamicForm> {
    try {
      const updatedForm = await this.dynamicFormRepository.updateById(
        module,
        id,
        updateData,
      );
      if (!updatedForm) {
        this.logger.warn(`Form with ID ${id} not found in module ${module}`);
        throw new NotFoundException(`Form with ID ${id} not found`);
      }

      await this.logAuditAction(
        AuditAction.UPDATE,
        AuditEntity.FORM_DATA,
        updatedForm,
      );

      this.logger.log(
        `Form with ID ${id} updated successfully in module ${module}`,
      );
      return updatedForm;
    } catch (error) {
      if (error instanceof NotFoundException) {
        this.logger.warn(
          `Form with ID ${id} not found for update in module ${module}`,
        );
        throw error;
      }
      this.logger.error('Error updating form record', error.stack);
      throw new InternalServerErrorException(
        `Error updating form with ID ${id} in module ${module}`,
      );
    }
  }

  /**
   * Soft deletes a form record by ID.
   * @param module - The module name
   * @param id - The form ID
   * @returns The soft-deleted form document with deleted timestamp or throws NotFoundException
   */
  async softDeleteById(
    module: string,
    id: string,
  ): Promise<DynamicForm | null> {
    try {
      const deletedForm = await this.dynamicFormRepository.deleteById(
        module,
        id,
      );
      if (!deletedForm) {
        this.logger.warn(`Form with ID ${id} not found in module ${module}`);
        throw new NotFoundException(`Form with ID ${id} not found`);
      }

      await this.logAuditAction(
        AuditAction.DELETE,
        AuditEntity.FORM_DATA,
        deletedForm,
      );

      this.logger.log(
        `Form with ID ${id} soft-deleted successfully in module ${module}`,
      );
      return deletedForm;
    } catch (error) {
      if (error instanceof NotFoundException) {
        this.logger.warn(
          `Form with ID ${id} not found for delete in module ${module}`,
        );
        throw error;
      }
      this.logger.error('Error soft-deleting form record', error.stack);
      throw new InternalServerErrorException(
        'Failed to soft-delete form record',
      );
    }
  }

  /**
   * Retrieves paginated forms based on the provided filters and parameters.
   * @param module - The module name
   * @param filters - Query filters to apply
   * @param page - Current page number
   * @param limit - Number of items per page
   * @param sortBy - Field to sort by
   * @param sortOrder - Sort order ('asc' or 'desc')
   * @param includeDeleted - Whether to include deleted records
   * @param tenantId - Tenant ID for scoping
   * @param platformId - Platform ID for scoping
   * @returns Paginated result containing forms
   */
  async findAll(
    module: string,
    query: PaginationDto = {},
    includeDeleted = false,
    tenantId: string,
    platformId: string,
  ): Promise<PaginatedResult<DynamicForm>> {
    try {
      const {
        page = 1,
        limit = 100,
        sortBy = 'createdAt',
        sortOrder = 'asc',
        filters = {},
      } = query;

      this.logger.log(`Fetching paginated forms for module '${module}'`, {
        filters,
        page,
        limit,
        sortBy,
        sortOrder,
        includeDeleted,
        tenantId,
        platformId,
      });

      const result = await this.dynamicFormRepository.findAllPaginated(
        module,
        filters,
        page,
        limit,
        sortBy,
        sortOrder,
        includeDeleted,
        tenantId,
        platformId,
      );

      this.logger.log(
        `Fetched ${result.items.length} forms out of ${result.total} total for module '${module}'`,
      );
      return result;
    } catch (error) {
      this.logger.error('Error fetching paginated forms', error.stack);
      throw new InternalServerErrorException('Failed to fetch paginated forms');
    }
  }

  /**
   * Validates and ensures `data` is a Record<string, unknown> or undefined.
   * @param data - The data to validate
   * @returns A valid data object or undefined
   */
  private validateData(data: unknown): Record<string, unknown> | undefined {
    if (typeof data === 'object' && data !== null) {
      return data as Record<string, unknown>;
    }
    return undefined;
  }

  /**
   * Logs an audit action for a specific entity.
   * @param action - The audit action (e.g., CREATE, UPDATE)
   * @param entity - The entity type being audited
   * @param data - The data associated with the action
   */
  private async logAuditAction(
    action: AuditAction,
    entity: AuditEntity,
    data: DynamicForm,
  ): Promise<void> {
    try {
      await this.auditLog.logAudit({
        action,
        entityName: entity,
        effectedEntityId: data.id,
        newValue: data,
      });
    } catch (auditError) {
      this.logger.error('Error logging audit action', auditError);
    }
  }
}
