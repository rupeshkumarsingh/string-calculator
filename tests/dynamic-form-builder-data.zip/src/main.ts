import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { ValidationPipe } from '@nestjs/common';
import morgan from 'morgan';
import { ConfigService } from '@nestjs/config';
import { AppModule } from './app.module';
import { ResponseInterceptor } from './shared/interceptors/response.interceptor';
import { AllConfigType } from './config/config.type';
import { VersioningType } from '@nestjs/common';
//import { SanitizePipe } from './shared/pipes/sanitize.pipe';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);

  const configService = app.get(ConfigService<AllConfigType>);

  app.enableShutdownHooks();

  app.setGlobalPrefix(
    configService.getOrThrow('app.apiPrefix', { infer: true }),
    { exclude: ['/health'] },
  );

  // Enable versioning using URI
  app.enableVersioning({
    type: VersioningType.URI,
  });

  app.useGlobalPipes(
    new ValidationPipe({
      transform: true,
      whitelist: true,
      forbidNonWhitelisted: true,
    }),
    //new SanitizePipe(),
  );
  app.useGlobalInterceptors(new ResponseInterceptor());

  // Swagger configuration

  const tenantId = configService.getOrThrow<string>('app.tenantId', {
    infer: true,
  });
  const platformId = configService.getOrThrow<string>('app.platformId', {
    infer: true,
  });
  const config = new DocumentBuilder()
    .setTitle('Form Builder Data Service')
    .setDescription(
      `
      Complete API documentation with data examples.
      
      **Required Headers:**
      - **tenantid**: Tenant ID (default: ${tenantId})
      - **platformid**: Platform ID (default: ${platformId})
    `,
    )
    .setVersion('1.0')
    .addApiKey({ type: 'apiKey', name: 'x-api-key', in: 'header' }, 'x-api-key')
    .addSecurityRequirements('x-api-key')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api-docs', app, document);

  app.use(morgan('combined'));

  // Fetch allowed origins from configuration
  // const allowedOrigins = configService.getOrThrow<string[]>(
  //   'app.allowedOrigins',
  //   { infer: true },
  // );

  // CORS configuration for enterprise-level apps
  app.enableCors({
    origin: '*',
  });

  await app.listen(configService.getOrThrow('app.port', { infer: true }));
}
bootstrap();
