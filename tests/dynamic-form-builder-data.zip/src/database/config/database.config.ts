import { registerAs } from '@nestjs/config';
import { DatabaseConfig } from './database.types';
import { DEFAULT_DATABASE_VALUES } from './database.constants';

export default registerAs<DatabaseConfig>('database', (): DatabaseConfig => {
  const {
    NODE_ENV,
    TEST_DATABASE_URL,
    TEST_DATABASE_NAME,
    MONGODB_URI,
    DATABASE_NAME,
  } = process.env;

  const isTestEnv = NODE_ENV === 'test';

  return {
    url: isTestEnv
      ? TEST_DATABASE_URL || DEFAULT_DATABASE_VALUES.TEST_DATABASE_URL
      : MONGODB_URI || DEFAULT_DATABASE_VALUES.DATABASE_URL,
    name: isTestEnv
      ? TEST_DATABASE_NAME || DEFAULT_DATABASE_VALUES.TEST_DATABASE_NAME
      : DATABASE_NAME || DEFAULT_DATABASE_VALUES.DATABASE_NAME,
  };
});
