export interface DatabaseConfig {
  url: string;
  name: string;
}
