import {
  Injectable,
  NestMiddleware,
  BadRequestException,
} from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import sanitizeHtml from 'sanitize-html';

@Injectable()
export class RequestSanitizationMiddleware implements NestMiddleware {
  /**
   * Middleware to sanitize incoming request bodies.
   * @param req - Incoming Express request object
   * @param res - Outgoing Express response object
   * @param next - Function to pass control to the next middleware
   */
  use(req: Request, res: Response, next: NextFunction): void {
    try {
      if (req.body && typeof req.body === 'object') {
        this.sanitizeRequestBody(req.body);
      }
      next();
    } catch (error) {
      throw new BadRequestException('Invalid request body format.', error);
    }
  }

  /**
   * Recursively sanitizes the request body to prevent XSS attacks.
   * @param body - The request body to sanitize
   */
  private sanitizeRequestBody(body: Record<string, unknown>): void {
    Object.entries(body).forEach(([key, value]) => {
      if (typeof value === 'string') {
        body[key] = this.sanitizeValue(value);
      } else if (Array.isArray(value)) {
        body[key] = value.map((item) =>
          typeof item === 'string' ? this.sanitizeValue(item) : item,
        );
      } else if (typeof value === 'object' && value !== null) {
        this.sanitizeRequestBody(value as Record<string, unknown>);
      }
    });
  }

  /**
   * Sanitizes a string value by removing disallowed HTML tags and attributes.
   * @param value - The string value to sanitize
   * @returns Sanitized string
   */
  private sanitizeValue(value: string): string {
    return sanitizeHtml(value, {
      allowedTags: [],
      allowedAttributes: {},
    });
  }
}
