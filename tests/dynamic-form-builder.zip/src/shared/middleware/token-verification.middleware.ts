import {
  Injectable,
  NestMiddleware,
  UnauthorizedException,
} from '@nestjs/common';
import * as jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class TokenVerificationMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction): void {
    const authHeader = req.headers['authorization'];
    if (!authHeader) {
      throw new UnauthorizedException('Authorization header is missing.');
    }

    const token = authHeader.split(' ')[1];
    if (!token) {
      throw new UnauthorizedException('Token is missing.');
    }

    try {
      const decoded = jwt.verify(token, 'Tenant1');
      req.body.tenantId = decoded.tenantId;
      req.body.platformId = decoded.platformId;
      req.body.createdBy = String(decoded.userId);
      //req.body.email = decoded.email;
      next();
    } catch (error) {
      throw new UnauthorizedException('Invalid or expired token.', error);
    }
  }
}
