export enum Status {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  ARCHIVED = 'archived',
}

export enum DataSourceType {
  STATIC = 'static',
  API = 'api',
  TEMPLATE = 'template',
}

export enum DataStoreType {
  INTERNAL = 'internal',
  EXTERNAL = 'external',
}

export enum LayoutType {
  Horizontal = 'horizontal',
  Vertical = 'vertical',
}

export enum DefaultValue {
  NA = 'na',
}

export enum HttpMethod {
  GET = 'GET',
  POST = 'POST',
}
