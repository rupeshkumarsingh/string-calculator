import { Schema, SchemaDefinitionProperty, IndexDefinition } from 'mongoose';

export class SchemaFieldUtils {
  /**
   * Creates a string field definition with optional enum and default value.
   *
   * @param {boolean} required - Whether the field is required.
   * @param {string} [defaultValue] - Optional default value.
   * @param {string[]} [enumValues] - Optional enum values.
   * @returns {SchemaDefinitionProperty<string>} String field definition.
   */
  static createStringField(
    required: boolean = false,
    defaultValue?: string,
    enumValues?: string[],
  ): SchemaDefinitionProperty<string> {
    return {
      type: String,
      required: required || undefined,
      ...(defaultValue && defaultValue !== 'na' && { default: defaultValue }),
      ...(enumValues && { enum: enumValues }),
    };
  }

  /**
   * Creates a boolean field definition with an optional default value.
   *
   * @param {boolean} required - Whether the field is required.
   * @param {boolean} [defaultValue] - Optional default value.
   * @returns {SchemaDefinitionProperty<boolean>} Boolean field definition.
   */
  static createBooleanField(
    required: boolean = false,
    defaultValue?: boolean,
  ): SchemaDefinitionProperty<boolean> {
    return {
      type: Boolean,
      required: required || undefined,
      ...(defaultValue !== undefined && { default: defaultValue }),
    };
  }

  /**
   * Creates a number field definition with an optional default value.
   *
   * @param {boolean} required - Whether the field is required.
   * @param {number} [defaultValue] - Optional default value.
   * @returns {SchemaDefinitionProperty<number>} Number field definition.
   */
  static createNumberField(
    required: boolean = false,
    defaultValue?: number,
  ): SchemaDefinitionProperty<number> {
    return {
      type: Number,
      required: required || undefined,
      ...(defaultValue !== undefined && { default: defaultValue }),
    };
  }

  /**
   * Helper function to generate a field based on type and options.
   *
   * @param {FieldType} fieldType - Type of the field (String, Number, Boolean).
   * @param {Record<string, unknown>} options - Field options such as default, enum, required.
   * @returns {SchemaDefinitionProperty} The field definition.
   */
  static createField(
    fieldType: unknown,
    options: Record<string, unknown>,
  ): SchemaDefinitionProperty {
    return { type: fieldType, ...options };
  }
}

export class SchemaIndexUtils {
  /**
   * Adds common fields to a schema (createdAt, updatedAt, etc.).
   *
   * @param {Schema} schema - The schema to add common fields to.
   * @returns {void}
   */
  static addCommonFields(schema: Schema): void {
    schema.add({
      createdAt: { type: Date, default: Date.now },
      updatedAt: { type: Date, default: Date.now },
      createdBy: { type: String },
      updatedBy: { type: String },
      isDeleted: { type: Boolean, default: false },
      tenantId: { type: String, required: true },
      platformId: { type: String, required: true },
    });
  }

  /**
   * Adds indexes to a schema.
   *
   * @param {Schema} schema - The schema to apply indexes to.
   * @param {IndexDefinition[]} indexes - An array of index definitions.
   * @throws {Error} If indexes is not an array or contains invalid entries.
   * @returns {void}
   */
  static addIndexes(schema: Schema, indexes: IndexDefinition[]): void {
    if (!Array.isArray(indexes)) {
      throw new Error('Indexes should be an array of objects');
    }

    indexes.forEach((index) => {
      if (typeof index === 'object') {
        schema.index(index);
      } else {
        throw new Error('Each index must be an object');
      }
    });
  }

  /**
   * Adds the default tenant and platform indexes to a schema.
   *
   * @param {Schema} schema - The schema to apply default indexes to.
   * @returns {void}
   */
  static addDefaultIndexes(schema: Schema): void {
    this.addIndexes(schema, [{ name: 1, tenantId: 1, platformId: 1 }]);
  }
}
