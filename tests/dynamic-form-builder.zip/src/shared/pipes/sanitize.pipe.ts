import { Injectable, PipeTransform, BadRequestException } from '@nestjs/common';
import DOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';

type DOMPurifyWindow = Window & typeof globalThis;

@Injectable()
export class SanitizePipe implements PipeTransform {
  private purify: DOMPurify.DOMPurify;

  constructor() {
    const dom = new JSDOM('');
    this.purify = DOMPurify(dom.window as unknown as DOMPurifyWindow);
  }

  /**
   * Transforms and sanitizes the input value.
   * @param value - The input value to be sanitized
   * @returns - The sanitized value
   * @throws BadRequestException for invalid input types
   */
  transform(value: unknown): unknown {
    this.validateValue(value);

    if (Array.isArray(value)) {
      return value.map((item) => this.sanitizeItem(item));
    } else if (this.isPlainObject(value)) {
      return this.sanitizeObject(value as Record<string, unknown>);
    } else if (typeof value === 'string') {
      return this.purify.sanitize(value);
    } else if (typeof value === 'number' || typeof value === 'boolean') {
      return value;
    } else {
      throw new BadRequestException(
        'Invalid input type. Expected object, array, string, number, or boolean.',
      );
    }
  }

  /**
   * Validates the input value.
   * @param value - The value to validate
   * @throws BadRequestException if the value is null or undefined
   */
  private validateValue(value: unknown): void {
    if (value === null || value === undefined) {
      throw new BadRequestException('Input value cannot be null or undefined.');
    }
  }

  /**
   * Checks if the value is a plain object (not null, array, or other non-object types).
   * @param value - The value to check
   * @returns boolean - True if the value is a plain object
   */
  private isPlainObject(value: unknown): boolean {
    return (
      typeof value === 'object' &&
      value !== null &&
      !Array.isArray(value) &&
      Object.prototype.toString.call(value) === '[object Object]'
    );
  }

  /**
   * Sanitizes a plain object by recursively sanitizing its properties.
   * @param obj - The object to sanitize
   * @returns - A sanitized object
   */
  private sanitizeObject(
    obj: Record<string, unknown>,
  ): Record<string, unknown> {
    const sanitized: Record<string, unknown> = {};
    Object.keys(obj).forEach((key) => {
      const value = obj[key];
      sanitized[key] = this.sanitizeItem(value);
    });
    return sanitized;
  }

  /**
   * Sanitizes an individual item, which could be a string, object, or array.
   * @param item - The item to sanitize
   * @returns - The sanitized item
   */
  private sanitizeItem(item: unknown): unknown {
    if (typeof item === 'string') {
      return this.purify.sanitize(item);
    } else if (this.isPlainObject(item)) {
      return this.sanitizeObject(item as Record<string, unknown>);
    } else if (Array.isArray(item)) {
      return item.map((subItem) => this.sanitizeItem(subItem));
    }
    return item;
  }
}
