import { NotFoundException } from '@nestjs/common';

export interface User {
  id: number;
  email: string;
  password: string;
}

export interface ApiKeys {
  publicKey: string;
  privateKey: string;
  systemToken: string;
}

export interface Tenant {
  tenantId: string;
  name: string;
  platformId: string;
  appId: string;
  apiKeys: ApiKeys;
  users: User[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TenantConfig {
  tenants: Tenant[];
}

export class TenantPlatformService {
  private config: TenantConfig;

  constructor() {
    this.config = {
      tenants: [
        {
          tenantId: 'T203',
          name: 'Tenant 1',
          platformId: 'P203',
          appId: 'com.example.app',
          apiKeys: {
            publicKey: 'Tenant1',
            privateKey: 'Tenant1',
            systemToken:
              'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwdWJsaWNLZXkiOiJUZW5hbnQxIiwidGVuYW50SWQiOiJUMjAzIiwicGxhdGZvcm1JZCI6IlAyMDMiLCJ1c2VySWQiOjEsImVtYWlsIjoidGVuYW50QGRlbW8uY29tIiwiaWF0IjoxNzM2NzkxODY2LCJleHAiOjE3NjgzNDk0NjZ9.aZumdkX9eUatJ37VkvsaAA9qpZZmdGws_DXv9z6s3_Q',
          },
          users: [
            {
              id: 1,
              email: 'tenant@demo.com',
              password: 'Test@123',
            },
          ],
          isActive: true,
          createdAt: '2023-01-01T12:00:00Z',
          updatedAt: '2024-12-01T12:00:00Z',
        },
        {
          tenantId: 'T501',
          name: 'Tenant 2',
          platformId: 'P501',
          appId: 'com.example.app2',
          apiKeys: {
            publicKey: 'Tenant1',
            privateKey: 'Tenant1',
            systemToken:
              'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwdWJsaWNLZXkiOiJUZW5hbnQxIiwidGVuYW50SWQiOiJUNTAxIiwicGxhdGZvcm1JZCI6IlA1MDEiLCJ1c2VySWQiOjIsImVtYWlsIjoiZGVtb0BkZW1vLmNvbSIsImlhdCI6MTczNjc5MTk4OSwiZXhwIjoxNzY4MzQ5NTg5fQ.30DxMDpotwm_YIS2j9pZcaqHRKm6RkSTQ8rpxWGEpDI',
          },
          users: [
            {
              id: 2,
              email: 'demo@demo.com',
              password: 'Test@123',
            },
          ],
          isActive: true,
          createdAt: '2023-06-15T09:30:00Z',
          updatedAt: '2024-10-01T15:00:00Z',
        },
      ],
    };
  }

  /**
   * Retrieves all tenants.
   */
  getTenants(): Tenant[] {
    return this.config.tenants;
  }

  /**
   * Validates the tenant and platform combination.
   * @param tenantId - The ID of the tenant to validate.
   * @param platformId - The ID of the platform to validate.
   * @returns {boolean} - Returns true if the tenant and platform are valid.
   * @throws {NotFoundException} - Throws if the combination is invalid.
   */
  validateTenantAndPlatform(tenantId: string, platformId: string): boolean {
    const tenant = this.config.tenants.find(
      (entry) => entry.tenantId === tenantId && entry.platformId === platformId,
    );

    if (!tenant) {
      throw new NotFoundException(
        `Tenant ID: ${tenantId} or Platform ID: ${platformId} is invalid.`,
      );
    }

    return true;
  }

  /**
   * Retrieves a tenant by ID.
   * @param tenantId - The ID of the tenant to retrieve.
   * @returns {Tenant} - Returns the matching tenant.
   * @throws {NotFoundException} - Throws if the tenant is not found.
   */
  getTenantById(tenantId: string): Tenant {
    const tenant = this.config.tenants.find(
      (entry) => entry.tenantId === tenantId,
    );

    if (!tenant) {
      throw new NotFoundException(`Tenant ID: ${tenantId} not found.`);
    }

    return tenant;
  }
}
