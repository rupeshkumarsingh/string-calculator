import { AppConfig } from './app-config.type';

export type AllConfigType = {
  app: AppConfig;
};

export type ConfigKey =
  | keyof AllConfigType
  | `${keyof AllConfigType}.${string}`;
