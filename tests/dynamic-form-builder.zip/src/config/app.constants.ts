export const DEFAULT_VALUES = {
  NODE_ENV: 'development',
  APP_NAME: 'app',
  BACKEND_DOMAIN: 'http://localhost',
  APP_PORT: 3000,
  API_PREFIX: 'api',
  ALLOWED_ORIGINS: ['http://localhost:3000'],
  DEFAULT_PLATFORM_ID: 'P101',
  DEFAULT_TENANT_ID: 'T101',
  DEFAULT_USER_ID: 'U101',
  X_API_KEY: 'xkey',
  AUDIT_LOG_BASE_URL: 'http://localhost:3001',
};
