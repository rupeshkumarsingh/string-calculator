import { registerAs } from '@nestjs/config';
import { AppConfig } from './app-config.type';
import { DEFAULT_VALUES } from './app.constants';
import validateConfig from '../shared/utils/validate-config';
import { EnvironmentVariablesValidator } from './environment.validator';

export default registerAs<AppConfig>('app', (): AppConfig => {
  validateConfig(process.env, EnvironmentVariablesValidator);

  const {
    NODE_ENV,
    APP_NAME,
    PWD,
    FRONTEND_DOMAIN,
    BACKEND_DOMAIN,
    APP_PORT,
    API_PREFIX,
    ALLOWED_ORIGINS,
    DEFAULT_PLATFORM_ID,
    DEFAULT_TENANT_ID,
    DEFAULT_USER_ID,
    X_API_KEY,
    AUDIT_LOG_BASE_URL,
  } = process.env;

  return {
    nodeEnv: NODE_ENV || DEFAULT_VALUES.NODE_ENV,
    name: APP_NAME || DEFAULT_VALUES.APP_NAME,
    workingDirectory: PWD || process.cwd(),
    frontendDomain: FRONTEND_DOMAIN,
    backendDomain: BACKEND_DOMAIN || DEFAULT_VALUES.BACKEND_DOMAIN,
    port: APP_PORT ? parseInt(APP_PORT, 10) : DEFAULT_VALUES.APP_PORT,
    apiPrefix: API_PREFIX || DEFAULT_VALUES.API_PREFIX,
    allowedOrigins: ALLOWED_ORIGINS
      ? ALLOWED_ORIGINS.split(',').map((origin) => origin.trim())
      : DEFAULT_VALUES.ALLOWED_ORIGINS,
    platformId: DEFAULT_PLATFORM_ID || DEFAULT_VALUES.DEFAULT_PLATFORM_ID,
    tenantId: DEFAULT_TENANT_ID || DEFAULT_VALUES.DEFAULT_TENANT_ID,
    userId: DEFAULT_USER_ID || DEFAULT_VALUES.DEFAULT_USER_ID,
    xApiKey: X_API_KEY || DEFAULT_VALUES.X_API_KEY,
    auditLogBaseUrl: AUDIT_LOG_BASE_URL || DEFAULT_VALUES.AUDIT_LOG_BASE_URL,
  };
});
