import { Test, TestingModule } from '@nestjs/testing';
import { AuditLogService } from '../../../logging/audit-log/audit-log.service';
import { LoggerService } from '../../../logging/error-log/logger.service';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';
import { AuditService } from '../../../logging/audit-log/audit-log.enums';

jest.mock('axios');
jest.mock('../../../logging/error-log/logger.service');
jest.mock('@nestjs/config');

const mockedAxios = axios as jest.Mocked<typeof axios>;

describe('AuditLogService', () => {
  let auditLogService: AuditLogService;
  let loggerService: LoggerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [AuditLogService, LoggerService, ConfigService],
    }).compile();

    auditLogService = module.get<AuditLogService>(AuditLogService);
    loggerService = module.get<LoggerService>(LoggerService);
  });

  it('should be defined', () => {
    expect(auditLogService).toBeDefined();
  });

  it('should successfully send audit log and log success', async () => {
    mockedAxios.post.mockResolvedValue({ status: 200 });

    const details = {
      action: 'TestEvent',
      platformId: 'testPlatform',
      tenantId: 'testTenant',
      userId: 'testUser',
      additionalInfo: 'Test Info',
      effectedEntityId: '123',
      entityName: 'TestEntity',
      ipAddress: '127.0.0.1',
      newValue: { key: 'value' },
      oldValue: { key: 'oldValue' },
      relatedEntities: 'TestRelatedEntity',
      serviceName: AuditService.FORM_BUILDER,
      version: '1.0',
    };

    await auditLogService.logAudit(details);

    expect(loggerService.log).toHaveBeenCalledWith(
      'Audit log sent successfully',
    );
  });
});
