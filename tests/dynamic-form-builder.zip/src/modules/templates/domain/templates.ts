import { Document } from 'mongoose';

export interface ITemplate extends Document {
  _id: string;
  name: string;
  description?: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
  isDeleted?: boolean;
  tenantId: string;
  platformId: string;
  formId?: string;
  uiData?: unknown;
  schemaData?: unknown;
  dataStore?: {
    type: string;
    internalStore?: string;
    externalStore?: {
      endpoint: string;
      method: string;
      headers?: Array<{ key: string; value: string }>;
    };
  };
  systemToken?: string;
}
