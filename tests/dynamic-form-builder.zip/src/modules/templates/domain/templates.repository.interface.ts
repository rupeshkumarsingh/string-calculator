import { BaseRepository } from '../../common/pagination/interfaces/base.repository.interface';
import { ITemplate } from './templates';

export interface ITemplatesRepository extends BaseRepository<ITemplate> {
  createTemplate(templateData: ITemplate): Promise<ITemplate>;
  getTemplateById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<ITemplate | null>;

  updateTemplate(
    id: string,
    updateData: Partial<ITemplate>,
  ): Promise<ITemplate | null>;
  deleteTemplate(id: string): Promise<ITemplate | null>;
  findAllPaginated(
    filters: Record<string, unknown>,
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
    includeDeleted?: boolean,
    tenantId?: string,
    platformId?: string,
  );
}
