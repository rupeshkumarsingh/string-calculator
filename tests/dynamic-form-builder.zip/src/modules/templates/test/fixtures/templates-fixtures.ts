import { ITemplate } from '../../domain/templates';
import { CreateTemplateDto } from '../../application/dto/create-template.dto';
import { UpdateTemplateDto } from '../../application/dto/update-template.dto';
import { Status } from '../../../../shared/utils/status.enum';

export const validTemplateDto: CreateTemplateDto = {
  name: 'createTemplate',
  description: 'Registration Form Template',
  status: Status.ACTIVE,
  createdBy: 'user123',
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
  formId: '6798bc302d7605b80b2ad5f4',
};

export const TemplateWithErrors: CreateTemplateDto = {
  name: 'createTemplate',
  description: 'Registration Form Template',
  status: Status.ACTIVE,
  createdBy: 'user123',
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
  formId: '6798bc302d7605b80b2ad5f4',
};

export const existingTemplate = {
  _id: '670e0a510e63a8b44e2d3521',
  name: 'Login Form Template',
  description: 'Login Form Template',
  formId: '6798bc302d7605b80b2ad5f4',
  status: Status.ACTIVE,
} as ITemplate;

export const updatedTemplateDto: UpdateTemplateDto = {
  name: 'Login Form Template',
  description: 'Login Form Template',
  status: Status.ACTIVE,
};

export const newTemplateDto: CreateTemplateDto = {
  name: 'Login Form Template',
  description: 'Login Form Template',
  status: Status.ACTIVE,
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
  formId: '6798bc302d7605b80b2ad5f4',
};

export const nonExistentTemplateId = 'non-existent-id';
