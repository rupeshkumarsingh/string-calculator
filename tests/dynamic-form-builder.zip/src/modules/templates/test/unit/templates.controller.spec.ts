import { Test, TestingModule } from '@nestjs/testing';
import {
  existingTemplate,
  validTemplateDto,
  nonExistentTemplateId,
} from '../fixtures/templates-fixtures';
import { NotFoundException } from '@nestjs/common';
import { TemplatesController } from '../../application/templates.controller';
import { TemplatesService } from '../../application/templates.service';
import { CreateTemplateDto } from '../../application/dto/create-template.dto';
import { UpdateTemplateDto } from '../../application/dto/update-template.dto';
import { PaginatedResult } from '../../../common/pagination/interfaces/paginated-result.interface';
import { PaginationDto } from '../../../common/pagination/dto/pagination.dto';
import { LoggerService } from '../../../../logging/error-log/logger.service';

describe('TemplatesController', () => {
  let controller: TemplatesController;
  let service: TemplatesService;
  const mockPaginatedResult: PaginatedResult<unknown> = {
    items: [], // Simulate empty results for the test
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  };
  const mockTemplatesService = {
    createTemplate: jest.fn(),
    getTemplateById: jest.fn(),
    getAllTemplates: jest.fn(),
    updateTemplate: jest.fn(),
    deleteTemplate: jest.fn(),
    findAllWithPopulatedData: jest.fn().mockResolvedValue(mockPaginatedResult),
  };

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const tenantId = '679c94019aba869fd50d2864';
  const platformId = '6708eaee1f18d52405c72f88';

  const populate = {
    path: 'form',
    select: 'name description',
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TemplatesController],
      providers: [
        { provide: TemplatesService, useValue: mockTemplatesService },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    controller = module.get<TemplatesController>(TemplatesController);
    service = module.get<TemplatesService>(TemplatesService);
  });

  describe('createTemplate', () => {
    it('should create and return a form successfully', async () => {
      mockTemplatesService.createTemplate.mockResolvedValue(existingTemplate);

      const result = await controller.createTemplate(
        validTemplateDto as CreateTemplateDto,
      );
      const formId = existingTemplate.formId;
      expect(result).toEqual(existingTemplate);
      expect(service.createTemplate).toHaveBeenCalledWith(
        formId,
        validTemplateDto,
      );
    });
  });

  describe('getTemplateById', () => {
    it('should return a form by id', async () => {
      const id = '66f529997383a45da1867131';
      mockTemplatesService.getTemplateById.mockResolvedValue(existingTemplate);

      const result = await controller.getTemplateById(id, {
        tenantId,
        platformId,
      });
      expect(result).toEqual(existingTemplate);
      expect(service.getTemplateById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if form not found', async () => {
      const id = nonExistentTemplateId;
      mockTemplatesService.getTemplateById.mockResolvedValue(null);

      await expect(
        controller.getTemplateById(id, { tenantId, platformId }),
      ).rejects.toThrow(
        new NotFoundException(`Template with ID ${id} not found`),
      );
    });
  });

  describe('getAllTemplates', () => {
    it('should be defined', () => {
      expect(controller).toBeDefined();
    });
    it('should call TemplatesService.findAllWithPopulatedData and return result', async () => {
      const query: PaginationDto = { page: 1, limit: 10 };

      const result = await controller.getAllTemplates(query, {
        tenantId,
        platformId,
      });

      expect(service.findAllWithPopulatedData).toHaveBeenCalledWith(
        query,
        populate,
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should call TemplatesService.findAllWithPopulatedData with default query if none provided', async () => {
      const defaultQuery: PaginationDto = {};

      const result = await controller.getAllTemplates(undefined, {
        tenantId,
        platformId,
      });

      expect(service.findAllWithPopulatedData).toHaveBeenCalledWith(
        defaultQuery,
        populate,
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });
  });

  describe('updateTemplate', () => {
    it('should update and return the template', async () => {
      const id = '670e0a510e63a8b44e2d3521';
      const updateDto = {
        name: 'Updated template',
        tenantId,
        platformId,
      } as UpdateTemplateDto;

      mockTemplatesService.updateTemplate.mockResolvedValue({
        ...existingTemplate,
      });

      const result = await controller.updateTemplate(id, updateDto);
      expect(result).toEqual({
        ...existingTemplate,
      });
      expect(service.updateTemplate).toHaveBeenCalledWith(
        id,
        updateDto,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if template to update is not found', async () => {
      const id = nonExistentTemplateId;
      const updateDto = { name: 'Updated template' } as UpdateTemplateDto;

      mockTemplatesService.updateTemplate.mockResolvedValue(null);

      await expect(controller.updateTemplate(id, updateDto)).rejects.toThrow(
        new NotFoundException(`Template with ID ${id} not found`),
      );
    });
  });

  describe('deleteTemplate', () => {
    it('should delete the template', async () => {
      const id = '670e0a510e63a8b44e2d3521';
      mockTemplatesService.deleteTemplate.mockResolvedValue(existingTemplate);

      await controller.deleteTemplate(id, { tenantId, platformId });
      expect(service.deleteTemplate).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if template to delete is not found', async () => {
      const id = nonExistentTemplateId;

      mockTemplatesService.deleteTemplate.mockResolvedValue(null);

      await expect(
        controller.deleteTemplate(id, { tenantId, platformId }),
      ).rejects.toThrow(
        new NotFoundException(`Template with ID ${id} not found`),
      );
    });
  });
});
