import { Test, TestingModule } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { ITemplate } from '../../domain/templates';
import { Model, Types } from 'mongoose';
import { TemplatesRepository } from '../../infrastructure/repositories/templates.repository';
import { LoggerService } from '../../../../logging/error-log/logger.service';
import { RepositoryException } from '../../../../shared/exceptions/repository.exception';

describe('TemplatesRepository', () => {
  let repository: TemplatesRepository;
  let model: Model<ITemplate>;
  let logger: LoggerService;

  const mockTemplateModel = jest.fn().mockImplementation(() => ({
    save: jest.fn(),
    findById: jest.fn().mockReturnThis(),
    exec: jest.fn(),
    countDocuments: jest.fn(),
    find: jest.fn(),
    sort: jest.fn().mockReturnThis(),
    skip: jest.fn().mockReturnThis(),
    limit: jest.fn().mockReturnThis(),
    updateMany: jest.fn(),
  }));

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const mockTemplateData = {
    _id: '670e0e640cd41b6881c65c48',
    name: 'Sales Form Template',
    description: 'Sales Form Template',
    status: 'active',
    isDeleted: false,
    tenantId: '679c94019aba869fd50d2864',
    platformId: '6708eaee1f18d52405c72f88',
  } as ITemplate;

  const tenantId = '679c94019aba869fd50d2864';
  const platformId = '6708eaee1f18d52405c72f88';

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TemplatesRepository,
        {
          provide: getModelToken('Template'),
          useValue: mockTemplateModel,
        },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    repository = module.get<TemplatesRepository>(TemplatesRepository);
    model = module.get<Model<ITemplate>>(getModelToken('Template'));
    logger = module.get<LoggerService>(LoggerService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('createTemplate', () => {
    it('should create and save a new template successfully', async () => {
      const formInstance = new mockTemplateModel();
      mockTemplateModel.mockImplementation(() => formInstance);
      formInstance.save.mockResolvedValue(mockTemplateData);

      const result = await repository.createTemplate(mockTemplateData);

      expect(mockTemplateModel).toHaveBeenCalledWith(mockTemplateData);
      expect(formInstance.save).toHaveBeenCalled();
      expect(result).toEqual(mockTemplateData);
    });

    it('should log an error and throw RepositoryException when save fails', async () => {
      const errorMessage = 'Failed to save template';
      const error = new Error(errorMessage);

      const formInstance = new mockTemplateModel();
      mockTemplateModel.mockImplementation(() => formInstance);
      formInstance.save.mockRejectedValue(error);

      await expect(repository.createTemplate(mockTemplateData)).rejects.toThrow(
        RepositoryException,
      );
      expect(logger.error).toHaveBeenCalledWith(
        'Error creating template',
        errorMessage,
      );
    });
  });

  describe('getTemplateById', () => {
    it('should return a template by id', async () => {
      const objectId = new Types.ObjectId(mockTemplateData._id);

      const execMock = jest.fn().mockResolvedValue(mockTemplateData);
      const findByIdMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findByIdMock;

      const result = await repository.getTemplateById(
        mockTemplateData._id,
        tenantId,
        platformId,
      );

      expect(model.findOne).toHaveBeenCalledWith({
        _id: objectId,
        tenantId,
        platformId,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockTemplateData);
    });

    it('should return null if template is not found', async () => {
      const objectId = new Types.ObjectId(mockTemplateData._id);

      const execMock = jest.fn().mockResolvedValue(null);
      const findByIdMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findByIdMock;

      const result = await repository.getTemplateById(
        mockTemplateData._id,
        tenantId,
        platformId,
      );

      expect(model.findOne).toHaveBeenCalledWith({
        _id: objectId,
        tenantId,
        platformId,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toBeNull();
      expect(logger.warn).toHaveBeenCalledWith(
        `Template with id ${mockTemplateData._id} not found for Tenant ID: ${tenantId} and Platform ID: ${platformId}`,
      );
    });

    it('should throw a RepositoryException if findOne fails', async () => {
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findByIdMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findByIdMock;

      await expect(
        repository.getTemplateById(mockTemplateData._id, tenantId, platformId),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error fetching template with id ${mockTemplateData._id}`,
        mockError.message,
      );
    });
  });

  describe('updateTemplate', () => {
    const mockUpdateData = { name: 'Purchase Form Templates' };

    it('should update and return the updated template', async () => {
      const mockUpdatedTemplate = { ...mockTemplateData, ...mockUpdateData };

      const execMock = jest.fn().mockResolvedValue(mockUpdatedTemplate);
      const findOneAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findOneAndUpdate = findOneAndUpdateMock;

      const result = await repository.updateTemplate(
        mockTemplateData._id,
        mockUpdateData,
      );

      expect(model.findOneAndUpdate).toHaveBeenCalledWith(
        new Types.ObjectId(mockTemplateData._id),
        mockUpdateData,
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockUpdatedTemplate);
    });

    it('should throw a RepositoryException if updating fails', async () => {
      const mockError = new Error('Update failed');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findOneAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findOneAndUpdate = findOneAndUpdateMock;

      await expect(
        repository.updateTemplate(mockTemplateData._id, mockUpdateData),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error updating template with id ${mockTemplateData._id}`,
        mockError.message,
      );
    });
  });

  describe('deleteTemplate', () => {
    it('should soft delete and return the updated template', async () => {
      const mockSoftDeletedTemplate = { ...mockTemplateData, isDeleted: true };

      // Create a mock return value that includes the exec method
      const execMock = jest.fn().mockResolvedValue(mockSoftDeletedTemplate);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.deleteTemplate(mockTemplateData._id);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        new Types.ObjectId(mockTemplateData._id),
        { isDeleted: true },
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockSoftDeletedTemplate);
    });

    it('should throw a RepositoryException if soft deletion fails', async () => {
      const mockError = new Error('Soft delete failed');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.deleteTemplate(mockTemplateData._id),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error deleting template with id ${mockTemplateData._id}`,
        mockError.message,
      );
    });
  });

  describe('findByFormIdAndName', () => {
    const formId = '679c94019aba869fd50d2864';
    const name = 'Sales Form Template';
    const mockTemplateData = {
      _id: '670e0e640cd41b6881c65c48',
      name: 'Sales Form Template',
      description: 'Sales Form Template',
      status: 'active',
      isDeleted: false,
      tenantId: '679c94019aba869fd50d2864',
      platformId: '6708eaee1f18d52405c72f88',
    } as ITemplate;

    it('should return the template when found', async () => {
      const execMock = jest.fn().mockResolvedValue(mockTemplateData);
      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });
      model.findOne = findOneMock;

      const result = await repository.findByFormIdAndName(formId, name);

      expect(model.findOne).toHaveBeenCalledWith({
        formId,
        name,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockTemplateData);
    });

    it('should return null if no template is found', async () => {
      const execMock = jest.fn().mockResolvedValue(null);
      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });
      model.findOne = findOneMock;

      const result = await repository.findByFormIdAndName(formId, name);

      expect(model.findOne).toHaveBeenCalledWith({
        formId,
        name,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toBeNull();
    });

    it('should throw RepositoryException if an error occurs during find', async () => {
      const mockError = new Error('Database error');
      const execMock = jest.fn().mockRejectedValue(mockError);
      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });
      model.findOne = findOneMock;

      await expect(
        repository.findByFormIdAndName(formId, name),
      ).rejects.toThrow(RepositoryException);
      expect(logger.error).toHaveBeenCalledWith(
        `Error finding tab by formId ${formId} and name ${name}:`,
        mockError,
      );
    });

    it('should throw error if formId or name are not provided', async () => {
      await expect(repository.findByFormIdAndName('', name)).rejects.toThrow(
        'formId and name are required to find a template',
      );
      await expect(repository.findByFormIdAndName(formId, '')).rejects.toThrow(
        'formId and name are required to find a template',
      );
    });
  });

  describe('deleteByFormId', () => {
    const formId = '679c94019aba869fd50d2864';
    const mockResult = { modifiedCount: 3 };

    it('should soft delete templates by formId and return result', async () => {
      const execMock = jest.fn().mockResolvedValue(mockResult);
      const updateManyMock = jest.fn().mockReturnValue({ exec: execMock });

      model.updateMany = updateManyMock;

      const result = await repository.deleteByFormId(formId);

      expect(model.updateMany).toHaveBeenCalledWith(
        { formId },
        { isDeleted: true },
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockResult);

      expect(logger.log).toHaveBeenCalledWith(
        `Updated 3 ${formId} records of form id ${formId}`,
      );
    });

    it('should log an error and throw when updateMany fails', async () => {
      const errorMessage = 'Failed to update templates';
      const error = new Error(errorMessage);

      const execMock = jest.fn().mockRejectedValue(error);
      const updateManyMock = jest.fn().mockReturnValue({ exec: execMock });

      model.updateMany = updateManyMock;

      await expect(repository.deleteByFormId(formId)).rejects.toThrow(error);
      expect(logger.error).toHaveBeenCalledWith(
        `Failed to delete templates for form: ${formId}`,
        error,
      );
    });
  });
});
