import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import mongoose from 'mongoose';
import { TemplateModel } from '../../infrastructure/schema/templates.schema';
import databaseConfig from '../../../../database/config/database.config';
import { DatabaseModule } from '../../../../database/database.module';

describe('Template Model and Schema', () => {
  let module: TestingModule;

  beforeAll(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          load: [databaseConfig],
          envFilePath: '.env',
          isGlobal: true,
        }),
        DatabaseModule,
      ],
    }).compile();
  });

  afterAll(async () => {
    //await mongoose.connection.close();
    module.close();
  });

  beforeEach(async () => {
    //await TemplateModel.deleteMany({});
  });

  it('should throw an error if name is missing', async () => {
    const templateData = {
      description: 'Template without a name',
      status: 'active',
    };

    const tempalte = new TemplateModel(templateData);
    await expect(tempalte.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });

  it('should throw an error if description is missing', async () => {
    const templateData = {
      name: 'Tempalte without description',
      status: 'active',
    };

    const form = new TemplateModel(templateData);
    await expect(form.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });

  it('should throw an error if status is invalid', async () => {
    const templateData = {
      name: 'Invalid Status template',
      description: 'This template has an invalid status',
      status: 'invalid_status', // Invalid status not in enum
    };

    const tempalte = new TemplateModel(templateData);
    await expect(tempalte.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });
});
