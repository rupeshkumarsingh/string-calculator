import { Test, TestingModule } from '@nestjs/testing';
import {
  BadRequestException,
  ConflictException,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { TemplatesService } from '../../application/templates.service';
import { TemplatesRepository } from '../../infrastructure/repositories/templates.repository';
import {
  validTemplateDto,
  existingTemplate,
  newTemplateDto,
  updatedTemplateDto,
  nonExistentTemplateId,
} from '../fixtures/templates-fixtures';
import { PaginatedResult } from '../../../common/pagination/interfaces/paginated-result.interface';
import { ITemplate } from '../../domain/templates';
import { PaginationDto } from '../../../common/pagination/dto/pagination.dto';
import { LoggerService } from '../../../../logging/error-log/logger.service';
import { AuditLogService } from '../../../../logging/audit-log/audit-log.service';
import { FormRepository } from '../../../forms/infrastructure/repositories/forms.repository';
import { TenantPlatformService } from '../../../../config/tenants/tenant-platform.service';

describe('TemplatesService', () => {
  let service: TemplatesService;
  let repository: TemplatesRepository;
  //let formRepository: FormRepository;

  const mockPaginatedResult: PaginatedResult<ITemplate> = {
    items: [],
    total: 0,
    page: 1,
    limit: 100,
    totalPages: 0,
  };
  const mockTemplatesRepository = {
    createTemplate: jest.fn(),
    getTemplateById: jest.fn(),
    findAllPaginated: jest.fn().mockResolvedValue(mockPaginatedResult),
    updateTemplate: jest.fn(),
    deleteTemplate: jest.fn(),
    findByFormIdAndName: jest.fn(),
  };

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const mockAuditLogService = {
    logAudit: jest.fn(),
  };

  const tenantId = 'T203';
  const platformId = 'P203';
  const formId = existingTemplate.formId || '';

  const mockFormRepository = {
    updateFormTemplates: jest.fn(),
    detachTemplateFromFormById: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TemplatesService,
        { provide: TemplatesRepository, useValue: mockTemplatesRepository },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
        {
          provide: AuditLogService,
          useValue: mockAuditLogService,
        },
        { provide: FormRepository, useValue: mockFormRepository },
        TenantPlatformService,
      ],
    }).compile();

    service = module.get<TemplatesService>(TemplatesService);
    repository = module.get<TemplatesRepository>(TemplatesRepository);
    //formRepository = module.get<FormRepository>(FormRepository);
  });

  describe('createTemplate', () => {
    it('should create and return a Template successfully', async () => {
      mockTemplatesRepository.findByFormIdAndName.mockResolvedValue(undefined);
      mockTemplatesRepository.createTemplate.mockResolvedValue(
        existingTemplate,
      );
      mockFormRepository.updateFormTemplates.mockResolvedValue(undefined);

      const result = await service.createTemplate(formId, validTemplateDto);

      expect(mockTemplatesRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        validTemplateDto.name,
      );
      expect(mockTemplatesRepository.createTemplate).toHaveBeenCalledWith(
        expect.objectContaining(validTemplateDto),
      );

      expect(result).toEqual(existingTemplate);
    });

    it('should throw BadRequestException on validation failure', async () => {
      mockTemplatesRepository.findByFormIdAndName.mockResolvedValue(undefined);
      mockTemplatesRepository.createTemplate.mockRejectedValue(
        new Error('validation failed'),
      );

      await expect(
        service.createTemplate(formId, validTemplateDto),
      ).rejects.toThrow(InternalServerErrorException);
    });

    it('should throw ConflictException for duplicate Template', async () => {
      mockTemplatesRepository.createTemplate.mockResolvedValue(undefined);
      mockTemplatesRepository.findByFormIdAndName.mockResolvedValue(
        validTemplateDto,
      );

      await expect(
        service.createTemplate(formId, validTemplateDto),
      ).rejects.toThrow(ConflictException);
    });

    it('should create and return a new Template with new values', async () => {
      mockTemplatesRepository.createTemplate.mockResolvedValue(newTemplateDto);
      mockTemplatesRepository.findByFormIdAndName.mockResolvedValue(undefined);

      const result = await service.createTemplate(formId, newTemplateDto);

      expect(result).toEqual(newTemplateDto);
    });

    it('should throw InternalServerErrorException on unexpected error', async () => {
      mockTemplatesRepository.createTemplate.mockRejectedValue(
        new Error('Database error'),
      );
      mockTemplatesRepository.findByFormIdAndName.mockResolvedValue(undefined);

      await expect(
        service.createTemplate(formId, validTemplateDto),
      ).rejects.toThrow(InternalServerErrorException);
    });
  });

  describe('getTemplateById', () => {
    it('should return a template successfully', async () => {
      const id = '66ebcb8f570e341a486525cd';
      mockTemplatesRepository.getTemplateById.mockResolvedValue(
        existingTemplate,
      );

      const result = await service.getTemplateById(id, tenantId, platformId);
      expect(result._id).toBe(existingTemplate._id);
      expect(mockTemplatesRepository.getTemplateById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if template not found', async () => {
      const id = 'non-existent-id';
      mockTemplatesRepository.getTemplateById.mockResolvedValue(null);

      await expect(
        service.getTemplateById(id, tenantId, platformId),
      ).rejects.toThrow(
        new NotFoundException(`Template with ID ${id} not found`),
      );
      expect(mockTemplatesRepository.getTemplateById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });
  });

  describe('findAllPaginated', () => {
    it('should call repository findAllPaginated with default values', async () => {
      const paginationQuery: PaginationDto = {};
      await service.findAllPaginated(
        paginationQuery,
        false,
        tenantId,
        platformId,
      );

      expect(repository.findAllPaginated).toHaveBeenCalledWith(
        {},
        1,
        100,
        'createdAt',
        'asc',
        false,
        tenantId,
        platformId,
      );
    });

    it('should call repository findAllPaginated with passed values', async () => {
      const paginationQuery: PaginationDto = {
        page: 2,
        limit: 50,
        sortBy: 'title',
        sortOrder: 'desc',
        filters: { status: 'active' },
      };

      await service.findAllPaginated(
        paginationQuery,
        false,
        tenantId,
        platformId,
      );

      expect(repository.findAllPaginated).toHaveBeenCalledWith(
        { status: 'active' },
        2,
        50,
        'title',
        'desc',
        false,
        tenantId,
        platformId,
      );
    });

    it('should return the paginated result from repository', async () => {
      const result = await service.findAllPaginated(
        {},
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should handle errors from the repository', async () => {
      const error = new Error('Repository error');
      mockTemplatesRepository.findAllPaginated.mockRejectedValueOnce(error);

      await expect(
        service.findAllPaginated({}, false, tenantId, platformId),
      ).rejects.toThrow('Repository error');
    });
  });

  describe('updateTemplate', () => {
    const id = '66ebcb8f570e341a486525cd';

    it('should update and return the template successfully', async () => {
      const updateDto = updatedTemplateDto;
      const updatedTemplate = { ...existingTemplate, ...updateDto };

      mockTemplatesRepository.getTemplateById.mockResolvedValue(
        existingTemplate,
      );

      mockTemplatesRepository.updateTemplate.mockResolvedValue(updatedTemplate);

      const result = await service.updateTemplate(
        id,
        updateDto,
        tenantId,
        platformId,
      );

      expect(mockTemplatesRepository.getTemplateById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockTemplatesRepository.updateTemplate).toHaveBeenCalledWith(
        id,
        updateDto,
      );
      expect(result).toEqual({ ...existingTemplate, ...updateDto });
    });

    it('should throw NotFoundException if template to update is not found', async () => {
      mockTemplatesRepository.getTemplateById.mockResolvedValueOnce(null);

      await expect(
        service.updateTemplate(
          nonExistentTemplateId,
          updatedTemplateDto,
          tenantId,
          platformId,
        ),
      ).rejects.toThrow(NotFoundException);

      expect(mockTemplatesRepository.updateTemplate).toHaveBeenCalled();
    });

    it('should throw InternalServerErrorException if update returns null', async () => {
      // Arrange: Mock the repository methods
      mockTemplatesRepository.getTemplateById.mockResolvedValue(
        existingTemplate,
      );
      mockTemplatesRepository.updateTemplate.mockResolvedValue(null);
      await expect(
        service.updateTemplate(
          existingTemplate.id,
          updatedTemplateDto,
          tenantId,
          platformId,
        ),
      ).rejects.toThrow(InternalServerErrorException);
      expect(mockTemplatesRepository.getTemplateById).toHaveBeenCalledWith(
        existingTemplate.id,
        tenantId,
        platformId,
      );
      expect(mockTemplatesRepository.updateTemplate).toHaveBeenCalledWith(
        existingTemplate.id,
        updatedTemplateDto,
      );
    });

    it('should validate unique name when name and formId are provided', async () => {
      mockTemplatesRepository.getTemplateById.mockResolvedValue(
        existingTemplate,
      );
      mockTemplatesRepository.updateTemplate.mockResolvedValue(
        existingTemplate,
      );

      jest.spyOn(service, 'validateUniqueName').mockResolvedValue(true);

      await service.updateTemplate(
        id,
        { name: 'New Template', formId: 'form123' },
        tenantId,
        platformId,
      );

      expect(service.validateUniqueName).toHaveBeenCalledWith(
        'form123',
        'New Template',
        id,
      );
      expect(mockTemplatesRepository.updateTemplate).toHaveBeenCalled();
    });

    it('should handle partial updates successfully', async () => {
      const partialUpdate = { name: 'Partially Updated Name' };
      const updatedTemplate = { ...existingTemplate, ...partialUpdate };

      mockTemplatesRepository.getTemplateById.mockResolvedValue(
        existingTemplate,
      );
      mockTemplatesRepository.updateTemplate.mockResolvedValue(updatedTemplate);

      const result = await service.updateTemplate(
        id,
        partialUpdate,
        tenantId,
        platformId,
      );

      expect(mockTemplatesRepository.getTemplateById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockTemplatesRepository.updateTemplate).toHaveBeenCalledWith(
        id,
        partialUpdate,
      );
      expect(result).toEqual(updatedTemplate);
    });
  });
  describe('deletetemplate', () => {
    it('should delete the Template successfully and detach with formId', async () => {
      const id = existingTemplate._id;
      const formId = existingTemplate.formId;

      mockTemplatesRepository.getTemplateById.mockResolvedValueOnce(
        existingTemplate,
      );
      mockTemplatesRepository.deleteTemplate.mockResolvedValueOnce(
        existingTemplate,
      );
      mockFormRepository.detachTemplateFromFormById.mockResolvedValueOnce(true);

      const result = await service.deleteTemplate(id, tenantId, platformId);

      expect(mockTemplatesRepository.getTemplateById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      // Ensure detachTemplateFromFormById was called with the actual formId
      expect(
        mockFormRepository.detachTemplateFromFormById,
      ).toHaveBeenCalledWith(formId, id);
      expect(mockTemplatesRepository.deleteTemplate).toHaveBeenCalledWith(id);
      expect(result).toEqual(existingTemplate);
    });

    it('should delete the Template successfully with empty formId', async () => {
      // Mock a template with no formId (or null/undefined)
      const templateWithoutFormId = { ...existingTemplate, formId: null };

      const id = templateWithoutFormId._id;

      mockTemplatesRepository.getTemplateById.mockResolvedValueOnce(
        templateWithoutFormId,
      );
      mockTemplatesRepository.deleteTemplate.mockResolvedValueOnce(
        templateWithoutFormId,
      );
      mockFormRepository.detachTemplateFromFormById.mockResolvedValueOnce(true);

      const result = await service.deleteTemplate(id, tenantId, platformId);

      expect(mockTemplatesRepository.getTemplateById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      // Ensure detachTemplateFromFormById was called with an empty string (default value for formId)
      expect(
        mockFormRepository.detachTemplateFromFormById,
      ).toHaveBeenCalledWith('', id);
      expect(mockTemplatesRepository.deleteTemplate).toHaveBeenCalledWith(id);
      expect(result).toEqual(templateWithoutFormId);
    });

    it('should throw NotFoundException if Template to delete is not found', async () => {
      const id = nonExistentTemplateId;
      mockTemplatesRepository.getTemplateById.mockResolvedValueOnce(null);

      await expect(
        service.deleteTemplate(id, tenantId, platformId),
      ).rejects.toThrow(
        new NotFoundException(`Template with ID ${id} not found`),
      );
      expect(mockTemplatesRepository.getTemplateById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockTemplatesRepository.deleteTemplate).toHaveBeenCalled();
    });

    it('should throw InternalServerErrorException if delete fails', async () => {
      const id = existingTemplate.id;
      mockTemplatesRepository.getTemplateById.mockResolvedValueOnce(
        existingTemplate,
      );
      mockTemplatesRepository.deleteTemplate.mockResolvedValueOnce(null);

      await expect(
        service.deleteTemplate(id, tenantId, platformId),
      ).rejects.toThrow(InternalServerErrorException);

      expect(mockTemplatesRepository.getTemplateById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockTemplatesRepository.deleteTemplate).toHaveBeenCalledWith(id);
    });
  });

  describe('validateUniqueName', () => {
    const formId = 'test-form-id';
    const name = 'Unique Template';
    const currentFieldId = 'current-field-id';
    const existingTemplate = {
      _id: 'existing-template-id',
      formId,
      name,
    };

    beforeEach(() => {
      jest.clearAllMocks();
    });
    it('should return true if no existing template is found', async () => {
      mockTemplatesRepository.findByFormIdAndName.mockResolvedValueOnce(null);

      const result = await service.validateUniqueName(formId, name);

      expect(mockTemplatesRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        name,
      );
      expect(result).toBe(true);
    });

    it('should return true if no existing template is found', async () => {
      mockTemplatesRepository.findByFormIdAndName.mockResolvedValueOnce(null);

      const result = await service.validateUniqueName(formId, name);

      expect(mockTemplatesRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        name,
      );
      expect(result).toBe(true);
    });

    it('should return true if an existing template is found but has the same ID as the current field', async () => {
      mockTemplatesRepository.findByFormIdAndName.mockResolvedValueOnce(
        existingTemplate,
      );

      const result = await service.validateUniqueName(
        formId,
        name,
        existingTemplate._id,
      );

      expect(mockTemplatesRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        name,
      );
      expect(result).toBe(true);
    });

    it('should return false if an existing template with a different ID is found', async () => {
      mockTemplatesRepository.findByFormIdAndName.mockResolvedValueOnce(
        existingTemplate,
      );

      const result = await service.validateUniqueName(
        formId,
        name,
        currentFieldId,
      );

      expect(mockTemplatesRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        name,
      );
      expect(result).toBe(false);
    });

    it('should throw BadRequestException if formId or name is missing', async () => {
      await expect(service.validateUniqueName('', name)).rejects.toThrow(
        BadRequestException,
      );
      await expect(service.validateUniqueName(formId, '')).rejects.toThrow(
        BadRequestException,
      );
    });

    it('should log an error and throw BadRequestException on repository failure', async () => {
      const error = new Error('Repository error');
      mockTemplatesRepository.findByFormIdAndName.mockRejectedValueOnce(error);

      await expect(service.validateUniqueName(formId, name)).rejects.toThrow(
        BadRequestException,
      );

      expect(mockLoggerService.error).toHaveBeenCalledWith(
        `Error during Template name validation for formId ${formId} and name ${name}:`,
        error,
      );
    });
  });
});
