import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import { TemplatesModule } from '../../templates.module';
import { TemplatesController } from '../../application/templates.controller';
import { TemplatesService } from '../../application/templates.service';
import { TemplatesRepository } from '../../infrastructure/repositories/templates.repository';
import { LoggerModule } from '../../../../logging/error-log/logger.module';
import databaseConfig from '../../../../database/config/database.config';
import { DatabaseModule } from '../../../../database/database.module';

describe('TemplatesModule', () => {
  let module: TestingModule;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          load: [databaseConfig],
          envFilePath: '.env',
          isGlobal: true,
        }),
        DatabaseModule,
        TemplatesModule,
        LoggerModule,
      ],
    }).compile();
  });

  it('should compile the module successfully', () => {
    expect(module).toBeDefined();
  });

  it('should have the TemplatesController defined', () => {
    const controller = module.get<TemplatesController>(TemplatesController);
    expect(controller).toBeDefined();
  });

  it('should have the TemplatesService defined', () => {
    const service = module.get<TemplatesService>(TemplatesService);
    expect(service).toBeDefined();
  });

  it('should have the TemplatesRepository defined', () => {
    const repository = module.get<TemplatesRepository>(TemplatesRepository);
    expect(repository).toBeDefined();
  });
});
