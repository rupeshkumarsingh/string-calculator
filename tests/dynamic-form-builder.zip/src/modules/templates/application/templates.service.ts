import {
  Injectable,
  NotFoundException,
  ConflictException,
  InternalServerErrorException,
  BadRequestException,
} from '@nestjs/common';
import { TemplatesRepository } from '../infrastructure/repositories/templates.repository';
import { CreateTemplateDto } from './dto/create-template.dto';
import { UpdateTemplateDto } from './dto/update-template.dto';
import { ITemplate } from '../domain/templates';
import { BaseService } from '../../common/pagination/services/base.service';
import { LoggerService } from '../../../logging/error-log/logger.service';
import { AuditLogService } from '../../../logging/audit-log/audit-log.service';
import {
  AuditAction,
  AuditEntity,
} from '../../../logging/audit-log/audit-log.enums';
import { FormRepository } from '../../forms/infrastructure/repositories/forms.repository';
import { TenantPlatformService } from '../../../config/tenants/tenant-platform.service';

@Injectable()
export class TemplatesService extends BaseService<ITemplate> {
  constructor(
    private readonly templatesRepository: TemplatesRepository,
    private readonly logger: LoggerService,
    private readonly auditLog: AuditLogService,
    private readonly formRepository: FormRepository,
    private readonly tenantService: TenantPlatformService,
  ) {
    super(templatesRepository);
  }

  /**
   * Create a new template
   * @param CreateTemplateDto The DTO containing the template data
   * @returns The newly created template
   */
  async createTemplate(
    formId: string,
    createTemplateDto: CreateTemplateDto,
  ): Promise<ITemplate> {
    try {
      const isUnique = await this.validateUniqueName(
        formId,
        createTemplateDto.name,
      );
      if (!isUnique) {
        this.logger.warn('Template name must be unique', {
          createTemplateDto,
        });
        throw new ConflictException('Template with this name already exists');
      }

      const templateData: ITemplate = { ...createTemplateDto } as ITemplate;
      const template =
        await this.templatesRepository.createTemplate(templateData);

      await this.formRepository.updateFormTemplates(formId, template._id);

      //Audit Log
      await this.auditLog.logAudit({
        action: AuditAction.CREATE,
        entityName: AuditEntity.TEMPLATE,
        effectedEntityId: template.id,
        newValue: template,
      });

      this.logger.log(
        `Template created successfully: ${template.id}`,
        'TemplatesService',
      );
      return template;
    } catch (error) {
      if (error instanceof ConflictException) {
        this.logger.warn('Conflict occurred while creating template', error);
        throw error;
      }
      this.logger.error('Error creating Template', error.stack);
      throw new InternalServerErrorException('Failed to create template');
    }
  }

  /**
   * Get template by ID
   * @param id template ID
   * @returns The template if found, otherwise throws NotFoundException
   */
  async getTemplateById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<ITemplate> {
    const template = await this.templatesRepository.getTemplateById(
      id,
      tenantId,
      platformId,
    );
    if (!template) {
      this.logger.warn(`Template with ID ${id} not found`);
      throw new NotFoundException(`Template with ID ${id} not found`);
    }
    const tenant = await this.tenantService.getTenantById(tenantId);
    if (!tenant || !tenant.apiKeys || !tenant.apiKeys.systemToken) {
      this.logger.error(
        `Failed to retrieve tenant or system token for tenant ID: ${tenantId}`,
      );
      throw new Error(
        `Unable to retrieve system token for tenant ID: ${tenantId}`,
      );
    }

    const systemToken = tenant.apiKeys.systemToken;

    const enrichedTemplate = {
      ...JSON.parse(JSON.stringify(template)),
      systemToken,
    };
    this.logger.log(`Template retrieved: ${template.id}`);
    return enrichedTemplate;
  }

  /**
   * Update a template
   * @param id template ID
   * @param updateDto DTO containing update data
   * @returns The updated template, or throws NotFoundException if not found
   */
  async updateTemplate(
    id: string,
    updateTemplateDto: UpdateTemplateDto,
    tenantId: string,
    platformId: string,
  ): Promise<ITemplate> {
    const existingTemplate = await this.templatesRepository.getTemplateById(
      id,
      tenantId,
      platformId,
    );

    if (!existingTemplate) {
      this.logger.warn(`Template with ID ${id} not found`);
      throw new NotFoundException(`Template with ID ${id} not found`);
    }

    if (updateTemplateDto.name && updateTemplateDto.formId) {
      await this.validateUniqueName(
        updateTemplateDto.formId,
        updateTemplateDto.name,
        id,
      );
    }

    const updatedTemplate = await this.templatesRepository.updateTemplate(
      id,
      updateTemplateDto as Partial<ITemplate>,
    );

    if (!updatedTemplate) {
      this.logger.warn(
        `Failed to update Template with ID ${id} - returned null`,
      );
      throw new InternalServerErrorException(
        'Failed to update Template - returned null',
      );
    }
    // Audit Log for Update
    await this.auditLog.logAudit({
      action: AuditAction.UPDATE,
      entityName: AuditEntity.TEMPLATE,
      effectedEntityId: updatedTemplate.id,
      oldValue: existingTemplate,
      newValue: updatedTemplate,
    });

    this.logger.log(`Template updated: ${updatedTemplate.id}`);
    return updatedTemplate;
  }

  /**
   * Delete a template
   * @param id template ID
   * @returns The deleted template, or throws NotFoundException if not found
   */
  async deleteTemplate(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<ITemplate | null> {
    const existingTemplate = await this.templatesRepository.getTemplateById(
      id,
      tenantId,
      platformId,
    );

    if (!existingTemplate) {
      this.logger.warn(`Template with ID ${id} not found`);
      throw new NotFoundException(`Template with ID ${id} not found`);
    }

    const formId = existingTemplate.formId || '';

    await this.formRepository.detachTemplateFromFormById(formId, id);
    const deletedTemplate = await this.templatesRepository.deleteTemplate(id);
    if (!deletedTemplate) {
      this.logger.warn(
        `Failed to delete Template with ID ${id} - returned null`,
      );
      throw new InternalServerErrorException(
        'Failed to delete Template - returned null',
      );
    }

    // Audit Log for Delete
    await this.auditLog.logAudit({
      action: AuditAction.DELETE,
      entityName: AuditEntity.TEMPLATE,
      effectedEntityId: deletedTemplate.id,
      oldValue: existingTemplate,
    });

    this.logger.log(`Template deleted: ${deletedTemplate.id}`);
    return deletedTemplate;
  }

  /**
   * Validates that the provided Field name is unique for the specified form ID.
   *
   * This function checks if a Field with the same name already exists for the
   * given form ID. If an existing Field is found and it's not the current Field
   *
   * @param {string} formId - The unique identifier of the form to which the Field belongs.
   * @param {string} name - The Field name to validate for uniqueness.
   * @param {string} [currentFieldId] - Optional. The ID of the current Field, used during update operations.
   * @returns {Promise<void>} - Resolves successfully if the name is uniq
   */
  async validateUniqueName(
    formId: string,
    name: string,
    currentFieldId?: string,
  ): Promise<boolean> {
    if (!formId || !name) {
      throw new BadRequestException('Form ID and name are required.');
    }

    try {
      const existingTemplate =
        await this.templatesRepository.findByFormIdAndName(formId, name);

      if (
        existingTemplate &&
        (!currentFieldId || existingTemplate._id.toString() !== currentFieldId)
      ) {
        this.logger.log(
          `Template name conflict detected: ${name} for formId ${formId}`,
        );
        return false;
      }

      return true;
    } catch (error) {
      this.logger.error(
        `Error during Template name validation for formId ${formId} and name ${name}:`,
        error,
      );
      throw new BadRequestException(
        'Unable to validate the Template name at this time. Please try again later.',
      );
    }
  }
}
