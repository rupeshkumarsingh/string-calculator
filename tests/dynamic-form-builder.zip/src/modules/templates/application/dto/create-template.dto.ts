import {
  IsNotEmpty,
  IsString,
  IsEnum,
  IsOptional,
  Length,
  MaxLength,
  IsObject,
  IsArray,
  ValidateNested,
  ValidateIf,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import DOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';
import { Status } from '../../../../shared/utils/status.enum';

const dom = new JSDOM();
const purify = DOMPurify(dom.window);

class HeaderDto {
  @IsString()
  @ApiProperty({ example: 'Authorization', description: 'Header key' })
  key: string;

  @IsString()
  @ApiProperty({ example: 'Bearer token', description: 'Header value' })
  value: string;
}

class ExternalDataStoreDto {
  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'https://api.example.com/data',
    description: 'API endpoint for external data store',
  })
  endpoint: string;

  @IsOptional()
  @IsEnum(['GET', 'POST'])
  @ApiProperty({
    enum: ['GET', 'POST'],
    description: 'HTTP method for external data store',
  })
  method: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => HeaderDto)
  @Transform(({ value }) => value ?? undefined)
  @ApiProperty({
    type: [HeaderDto],
    description: 'Headers for external data store',
    example: [{ key: 'Authorization', value: 'Bearer token' }],
  })
  headers: { key: string; value: string }[];
}

class DataStoreDto {
  @IsEnum(['internal', 'external'], {
    message: 'Data store type must be either "internal" or "external".',
  })
  @IsOptional()
  @ApiProperty({
    enum: ['internal', 'external'],
    description: 'Type of the data store',
  })
  type?: 'internal' | 'external';

  @ValidateIf((o) => o.type === 'internal')
  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'internalStoreName',
    description:
      'Name of the internal data store (only applicable for "internal" type)',
  })
  internalStore?: string;

  @ValidateIf((o) => o.type === 'external')
  @IsOptional()
  @ValidateNested()
  @Type(() => ExternalDataStoreDto)
  @Transform(({ value }) => value ?? undefined)
  @ApiProperty({
    type: ExternalDataStoreDto,
    description:
      'External data store configuration (only applicable for "external" type)',
  })
  externalStore?: ExternalDataStoreDto;
}

export class CreateTemplateDto {
  @IsNotEmpty()
  @IsString()
  @Length(3, 256)
  @ApiProperty({ example: 'User Registration' })
  @Transform(({ value }) => purify.sanitize(value))
  name: string;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  @ApiProperty({
    example: 'User Registration Template',
  })
  @Transform(({ value }) => purify.sanitize(value))
  description: string;

  @IsEnum(Status)
  @ApiProperty({
    enum: Status,
    example: Status.ACTIVE,
  })
  status: Status;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'user123',
    description: 'The ID of the user who created the template.',
  })
  createdBy?: string;

  @IsOptional()
  @IsString()
  updatedBy?: string;

  @IsNotEmpty()
  @IsString()
  tenantId: string;

  @IsNotEmpty()
  @IsString()
  platformId: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty({
    example: '67109aa1ddd11a771522c050',
    description: 'The ID of the form.',
  })
  formId: string;

  @IsOptional()
  @IsObject()
  @ApiProperty({
    type: Object,
    example: { layout: 'VerticalLayout', elements: [] },
    description: 'UI configuration data for the template.',
  })
  uiData?: Record<string, unknown>;

  @IsOptional()
  @IsObject()
  @ApiProperty({
    type: Object,
    example: { schema: {} },
    description: 'Schema configuration data for the template.',
  })
  schemaData?: Record<string, unknown>;

  @IsOptional()
  @ValidateNested()
  @Type(() => DataStoreDto)
  @Transform(({ value }) => value ?? undefined)
  @ApiProperty({
    type: DataStoreDto,
    description: 'Data store configuration for the template',
  })
  dataStore?: DataStoreDto;
}
