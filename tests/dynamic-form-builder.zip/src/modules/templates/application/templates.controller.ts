import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  HttpCode,
  HttpStatus,
  NotFoundException,
  Query,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBody,
  ApiParam,
  ApiQuery,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { CreateTemplateDto } from './dto/create-template.dto';
import { UpdateTemplateDto } from './dto/update-template.dto';
import { ITemplate } from '../domain/templates';
import { PaginationDto } from '../../common/pagination/dto/pagination.dto';
import { TemplatesService } from './templates.service';
import { LoggerService } from '../../../logging/error-log/logger.service';

@ApiTags('Templates')
@Controller('templates')
@ApiBearerAuth('Authorization')
@ApiBearerAuth('x-api-key')
export class TemplatesController {
  constructor(
    private readonly templateService: TemplatesService,
    private readonly logger: LoggerService,
  ) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create a new template' })
  @ApiBody({ type: CreateTemplateDto })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Template successfully created.',
  })
  @ApiResponse({
    status: HttpStatus.CONFLICT,
    description: 'Duplicate Template.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid request payload.',
  })
  async createTemplate(
    @Body() createTemplateDto: CreateTemplateDto,
  ): Promise<ITemplate> {
    this.logger.log('Creating a new template');
    const formId = createTemplateDto.formId;
    const template = await this.templateService.createTemplate(
      formId,
      createTemplateDto,
    );
    this.logger.log(`Template created successfully: ${template.id}`);
    return template;
  }

  @Get(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Get a template by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the template',
    type: String,
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Template successfully retrieved.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Template not found.',
  })
  async getTemplateById(
    @Param('id') id: string,
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<ITemplate> {
    this.logger.log(`Retrieving template with ID: ${id}`);
    const template = await this.templateService.getTemplateById(
      id,
      body.tenantId,
      body.platformId,
    );
    if (!template) {
      this.logger.warn(`Template with ID ${id} not found`);
      throw new NotFoundException(`Template with ID ${id} not found`);
    }
    this.logger.log(`Template retrieved: ${template.id}`);
    return template;
  }

  @Get()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Get all templates with optional pagination and sorting',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    description: 'Page number for pagination.',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Number of items per page.',
    example: 10,
  })
  @ApiQuery({
    name: 'sortBy',
    required: false,
    description: 'Field to sort by.',
    example: 'name',
  })
  @ApiQuery({
    name: 'sortOrder',
    required: false,
    description: 'Sort order: "asc" or "desc".',
    example: 'asc',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'List of templates retrieved successfully.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid pagination or sorting parameters.',
  })
  async getAllTemplates(
    @Query() query: PaginationDto = {},
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<unknown> {
    this.logger.log('Retrieving all templates with pagination and sorting');
    const includeDeleted = query.includeDeleted ?? false;
    const populate = {
      path: 'form',
      select: 'name description',
    };
    const templates = await this.templateService.findAllWithPopulatedData(
      query,
      populate,
      includeDeleted,
      body.tenantId,
      body.platformId,
    );
    this.logger.log(`Retrieved ${templates?.items?.length} templates`);
    return templates;
  }

  @Put(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Update a template by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the template to be updated',
    type: String,
  })
  @ApiBody({ type: UpdateTemplateDto })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Template successfully updated.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Template not found.',
  })
  async updateTemplate(
    @Param('id') id: string,
    @Body() updateTemplateDto: UpdateTemplateDto,
  ): Promise<ITemplate> {
    this.logger.log(`Updating template with ID: ${id}`);

    const tenantId = updateTemplateDto.tenantId || 'defaultTenantId';
    const platformId = updateTemplateDto.platformId || 'defaultPlatformId';
    const template = await this.templateService.updateTemplate(
      id,
      updateTemplateDto,
      tenantId,
      platformId,
    );
    if (!template) {
      this.logger.warn(`Template with ID ${id} not found`);
      throw new NotFoundException(`Template with ID ${id} not found`);
    }
    this.logger.log(`Template updated: ${template.id}`);
    return template;
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete a template by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the template to be deleted',
    type: String,
  })
  @ApiResponse({
    status: HttpStatus.NO_CONTENT,
    description: 'Template successfully deleted.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Template not found.',
  })
  async deleteTemplate(
    @Param('id') id: string,
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<void> {
    this.logger.log(`Deleting template with ID: ${id}`);
    const result = await this.templateService.deleteTemplate(
      id,
      body.tenantId,
      body.platformId,
    );
    if (!result) {
      this.logger.warn(`Template with ID ${id} not found`);
      throw new NotFoundException(`Template with ID ${id} not found`);
    }
    this.logger.log(`Template deleted: ${id}`);
  }
}
