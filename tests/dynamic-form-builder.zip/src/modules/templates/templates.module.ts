import { forwardRef, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TemplatesController } from './application/templates.controller';
import { TemplatesService } from './application/templates.service';
import { TemplatesRepository } from './infrastructure/repositories/templates.repository';
import { TemplateSchema } from './infrastructure/schema/templates.schema';
import { AuditLogModule } from '../../logging/audit-log/audit-log.module';
import { FormsModule } from '../forms/forms.module';
import { TenantPlatformService } from '../../config/tenants/tenant-platform.service';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Template', schema: TemplateSchema }]),
    AuditLogModule,
    forwardRef(() => FormsModule),
  ],
  controllers: [TemplatesController],
  providers: [TemplatesService, TemplatesRepository, TenantPlatformService],
  exports: [TemplatesService, TemplatesRepository],
})
export class TemplatesModule {}
