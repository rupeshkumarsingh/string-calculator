import { Schema } from 'mongoose';
import { SchemaFieldUtils } from '../../../../shared/utils/schema-utils';
import { HttpMethod, DefaultValue } from '../../../../shared/utils/status.enum';

const ExternalDataStoreSchema = new Schema(
  {
    endpoint: SchemaFieldUtils.createStringField(),
    method: SchemaFieldUtils.createStringField(
      true,
      DefaultValue.NA,
      Object.values(HttpMethod),
    ),
    headers: [
      {
        key: SchemaFieldUtils.createStringField(true),
        value: SchemaFieldUtils.createStringField(true),
      },
    ],
  },
  { _id: false },
);

export { ExternalDataStoreSchema };
