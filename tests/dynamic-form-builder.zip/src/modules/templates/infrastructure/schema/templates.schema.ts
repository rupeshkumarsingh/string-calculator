import { model, Schema } from 'mongoose';
import { ITemplate } from '../../domain/templates';
import { ExternalDataStoreSchema } from './external-data-schema';
import {
  SchemaFieldUtils,
  SchemaIndexUtils,
} from '../../../../shared/utils/schema-utils';
import {
  Status,
  DataStoreType,
  DefaultValue,
} from '../../../../shared/utils/status.enum';

const DataStoreSchema = new Schema(
  {
    type: SchemaFieldUtils.createStringField(
      true,
      DefaultValue.NA,
      Object.values(DataStoreType),
    ),
    internalStore: SchemaFieldUtils.createStringField(),
    externalStore: ExternalDataStoreSchema,
  },
  { _id: false },
);

const TemplateSchema = new Schema<ITemplate>({
  name: SchemaFieldUtils.createStringField(true),
  description: SchemaFieldUtils.createStringField(),
  status: SchemaFieldUtils.createStringField(
    false,
    Status.ACTIVE,
    Object.values(Status),
  ),
  formId: SchemaFieldUtils.createField(Schema.Types.ObjectId, { ref: 'Form' }),
  uiData: SchemaFieldUtils.createField(Schema.Types.Mixed, { default: {} }),
  schemaData: SchemaFieldUtils.createField(Schema.Types.Mixed, { default: {} }),
  dataStore: { type: DataStoreSchema },
});

// Add common fields and indexes
SchemaIndexUtils.addCommonFields(TemplateSchema);
SchemaIndexUtils.addIndexes(TemplateSchema, [
  { tenantId: 1, platformId: 1, formId: 1 },
]);

TemplateSchema.virtual('form', {
  ref: 'Form',
  localField: 'formId',
  foreignField: '_id',
  justOne: true,
});

TemplateSchema.set('toJSON', { virtuals: true });
TemplateSchema.set('toObject', { virtuals: true });

export { TemplateSchema };

export const TemplateModel = model<ITemplate>('Template', TemplateSchema);
