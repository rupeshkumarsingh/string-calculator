import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { ITemplate } from '../../domain/templates';
import { ITemplatesRepository } from '../../domain/templates.repository.interface';
import { RepositoryException } from '../../../../shared/exceptions/repository.exception';
import LoggerService from '../../../../logging/error-log/logger.service';
import { BaseRepository } from '../../../common/pagination/repositories/base.repository';

@Injectable()
export class TemplatesRepository
  extends BaseRepository<ITemplate>
  implements ITemplatesRepository
{
  constructor(
    @InjectModel('Template')
    private readonly templateModel: Model<ITemplate>,
    private readonly logger: LoggerService,
  ) {
    super(templateModel);
  }

  /**
   * Creates a new template and saves it to the database.
   * @param templateData - The data for the template to be created.
   * @returns The created template.
   * @throws RepositoryException if the creation fails.
   */
  async createTemplate(templateData: ITemplate): Promise<ITemplate> {
    try {
      const template = new this.templateModel(templateData);
      this.logger.log('Creating template', templateData);
      return await template.save();
    } catch (error) {
      this.logger.error('Error creating template', error.message);
      throw new RepositoryException('Failed to create template', error);
    }
  }

  /**
   * Retrieves a template by its MongoDB ObjectId.
   * @param id - The string representation of the template's MongoDB ObjectId.
   * @returns The template if found, or null if not found.
   * @throws RepositoryException if the retrieval fails.
   */
  async getTemplateById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<ITemplate | null> {
    try {
      // Log the fetching process
      this.logger.log(
        `Fetching template by id: ${id} for Tenant ID: ${tenantId} and Platform ID: ${platformId}`,
      );

      // Convert string id to MongoDB ObjectId
      const objectId = new Types.ObjectId(id);

      // Fetch the template by ID, tenant ID, and platform ID
      const template = await this.templateModel
        .findOne({
          _id: objectId,
          tenantId,
          platformId,
          isDeleted: false,
        })
        .exec();

      if (!template) {
        this.logger.warn(
          `Template with id ${id} not found for Tenant ID: ${tenantId} and Platform ID: ${platformId}`,
        );
        return null;
      }

      return template;
    } catch (error) {
      this.logger.error(`Error fetching template with id ${id}`, error.message);
      throw new RepositoryException(
        `Failed to get template with id ${id}`,
        error,
      );
    }
  }

  /**
   * Updates a template with the specified id.
   * @param id - The MongoDB ObjectId of the template to be updated.
   * @param updateData - The partial data to update the template with.
   * @returns The updated template if successful, or null if not found.
   * @throws RepositoryException if the update fails.
   */
  async updateTemplate(
    id: string,
    updateData: Partial<ITemplate>,
  ): Promise<ITemplate | null> {
    try {
      this.logger.log(`Updating template with id: ${id}`, updateData);
      const objectId = new Types.ObjectId(id);
      return await this.templateModel
        .findOneAndUpdate(objectId, updateData, {
          new: true,
        })
        .exec();
    } catch (error) {
      this.logger.error(`Error updating template with id ${id}`, error.message);
      throw new RepositoryException(
        `Failed to update template with id ${id}`,
        error,
      );
    }
  }

  /**
   * Deletes a template by its MongoDB ObjectId.
   * @param id - The MongoDB ObjectId of the template to be deleted.
   * @returns The deleted template if successful, or null if not found.
   * @throws RepositoryException if the deletion fails.
   */
  async deleteTemplate(id: string): Promise<ITemplate | null> {
    try {
      this.logger.log(`Deleting template with id: ${id}`);
      const objectId = new Types.ObjectId(id);
      //return await this.templateModel.findOneAndDelete(objectId).exec();
      return await this.templateModel
        .findByIdAndUpdate(objectId, { isDeleted: true }, { new: true })
        .exec();
    } catch (error) {
      this.logger.error(`Error deleting template with id ${id}`, error.message);
      throw new RepositoryException(
        `Failed to delete template with id ${id}`,
        error,
      );
    }
  }

  /**
   * Finds a single tab document based on the provided form ID and tab name,
   * @param {string} formId - The unique identifier of the form to which the tab belongs.
   * @param {string} name - The name of the tab to be retrieved.
   * @returns {Promise<ITemplate | null>} - A promise that resolves to the found tab document
   */
  async findByFormIdAndName(
    formId: string,
    name: string,
  ): Promise<ITemplate | null> {
    try {
      if (!formId || !name) {
        throw new Error('formId and name are required to find a template');
      }

      const tab = await this.templateModel
        .findOne({ formId, name, isDeleted: false })
        .exec();

      return tab;
    } catch (error) {
      this.logger.error(
        `Error finding tab by formId ${formId} and name ${name}:`,
        error,
      );

      throw new RepositoryException(
        'Unable to retrieve the tab at this time. Please try again later.',
        error,
      );
    }
  }

  /**
   * Deletes all templates associated with the given form ID.
   * @param formId The ID of the form.
   */
  async deleteByFormId(formId: string): Promise<unknown> {
    try {
      const result = await this.templateModel
        .updateMany({ formId }, { isDeleted: true }, { new: true })
        .exec();
      this.logger.log(
        `Updated ${result.modifiedCount} ${formId} records of form id ${formId}`,
      );
      return result;
    } catch (error) {
      this.logger.error(
        `Failed to delete templates for form: ${formId}`,
        error,
      );
      throw error;
    }
  }
}
