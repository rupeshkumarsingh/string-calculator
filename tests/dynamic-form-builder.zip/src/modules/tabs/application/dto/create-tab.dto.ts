import {
  IsNotEmpty,
  IsString,
  IsEnum,
  IsOptional,
  Length,
  MaxLength,
  IsArray,
  ValidateNested,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import DOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';
import { Status } from '../../../../shared/utils/status.enum';

const dom = new JSDOM();
const purify = DOMPurify(dom.window);

export class TabItemDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    example: 'General',
    description: 'The label of the tab item.',
  })
  label: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'General',
    description: 'The name of the tab item.',
  })
  name: string;
}

export class CreateTabDto {
  @IsNotEmpty()
  @IsString()
  @Length(3, 256)
  @ApiProperty({ example: 'User Registration' })
  @Transform(({ value }) => purify.sanitize(value))
  name: string;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  @ApiProperty({
    example: 'User Registration Tab',
  })
  @Transform(({ value }) => purify.sanitize(value))
  description: string;

  @IsEnum(Status)
  @ApiProperty({
    enum: Status,
    example: Status.ACTIVE,
  })
  status: Status;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'user123',
    description: 'The ID of the user who created the tab.',
  })
  createdBy?: string;

  @IsOptional()
  @IsString()
  updatedBy?: string;

  @IsNotEmpty()
  @IsString()
  tenantId: string;

  @IsNotEmpty()
  @IsString()
  platformId: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty({
    example: '67109aa1ddd11a771522c050',
    description: 'The ID of the form.',
  })
  formId: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => TabItemDto)
  @ApiProperty({
    description: 'The list of tab items.',
    type: [TabItemDto],
    example: [
      {
        label: 'General',
        name: 'General',
      },
      {
        label: 'Details',
        name: 'Details',
      },
    ],
  })
  items: TabItemDto[];
}
