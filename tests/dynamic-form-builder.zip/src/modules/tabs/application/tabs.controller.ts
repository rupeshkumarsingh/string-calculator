import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  HttpCode,
  HttpStatus,
  NotFoundException,
  Query,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBody,
  ApiParam,
  ApiQuery,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { CreateTabDto } from './dto/create-tab.dto';
import { UpdateTabDto } from './dto/update.tab.dto';
import { ITab } from '../domain/tabs';
import { PaginationDto } from '../../common/pagination/dto/pagination.dto';
import { TabsService } from './tabs.service';
import { LoggerService } from '../../../logging/error-log/logger.service';

@ApiTags('Tabs')
@Controller('tabs')
@ApiBearerAuth('Authorization')
@ApiBearerAuth('x-api-key')
export class TabsController {
  constructor(
    private readonly tabService: TabsService,
    private readonly logger: LoggerService,
  ) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create a new tab' })
  @ApiBody({ type: CreateTabDto })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Tab successfully created.',
  })
  @ApiResponse({
    status: HttpStatus.CONFLICT,
    description: 'Duplicate  tab .',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid request payload.',
  })
  async createTab(@Body() createTabDto: CreateTabDto): Promise<ITab> {
    this.logger.log('Creating a new tab');
    const formId = createTabDto.formId;

    const tab = await this.tabService.createTab(formId, createTabDto);

    if (!tab) {
      this.logger.warn(
        `Failed to create tab. Form with ID ${formId} does not exist.`,
      );
      throw new NotFoundException(`Form with ID ${formId} not found`);
    }

    this.logger.log(`Tab created successfully: ${tab.id}`);
    return tab;
  }

  @Get(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Get a tab by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the tab',
    type: String,
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Tab successfully retrieved.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Tab not found.',
  })
  async getTabById(
    @Param('id') id: string,
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<ITab> {
    this.logger.log(`Retrieving tab with ID: ${id}`);
    const tab = await this.tabService.getTabById(
      id,
      body.tenantId,
      body.platformId,
    );
    if (!tab) {
      this.logger.warn(`Tab with ID ${id} not found`);
      throw new NotFoundException(`Tab with ID ${id} not found`);
    }
    this.logger.log(`Tab retrieved: ${tab.id}`);
    return tab;
  }

  @Get()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Get all Tabs with optional pagination and sorting',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    description: 'Page number for pagination.',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Number of items per page.',
    example: 10,
  })
  @ApiQuery({
    name: 'sortBy',
    required: false,
    description: 'Field to sort by.',
    example: 'name',
  })
  @ApiQuery({
    name: 'sortOrder',
    required: false,
    description: 'Sort order: "asc" or "desc".',
    example: 'asc',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'List of Tabs retrieved successfully.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid pagination or sorting parameters.',
  })
  async getAllTabs(
    @Query() query: PaginationDto = {},
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<unknown> {
    this.logger.log('Retrieving all Tabs with pagination and sorting');
    const includeDeleted = query.includeDeleted ?? false;
    const populate = {
      path: 'form',
      select: 'name description',
    };
    const tabs = await this.tabService.findAllWithPopulatedData(
      query,
      populate,
      includeDeleted,
      body.tenantId,
      body.platformId,
    );
    this.logger.log(`Retrieved ${tabs?.items?.length} Tabs`);
    return tabs;
  }

  @Put(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Update a tab by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the tab to be updated',
    type: String,
  })
  @ApiBody({ type: UpdateTabDto })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Tab successfully updated.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Tab not found.',
  })
  async updateTab(
    @Param('id') id: string,
    @Body() updateTabDto: UpdateTabDto,
  ): Promise<ITab> {
    this.logger.log(`Updating tab with ID: ${id}`);

    const tenantId = updateTabDto.tenantId || 'defaultTenantId';
    const platformId = updateTabDto.platformId || 'defaultPlatformId';
    const tab = await this.tabService.updateTab(
      id,
      updateTabDto,
      tenantId,
      platformId,
    );
    if (!tab) {
      this.logger.warn(`Tab with ID ${id} not found`);
      throw new NotFoundException(`Tab with ID ${id} not found`);
    }
    this.logger.log(`Tab updated: ${tab.id}`);
    return tab;
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete a tab by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the tab to be deleted',
    type: String,
  })
  @ApiResponse({
    status: HttpStatus.NO_CONTENT,
    description: 'Tab successfully deleted.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Tab not found.',
  })
  async deleteTab(
    @Param('id') id: string,
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<void> {
    this.logger.log(`Deleting tab with ID: ${id}`);
    const result = await this.tabService.deleteTab(
      id,
      body.tenantId,
      body.platformId,
    );
    if (!result) {
      this.logger.warn(`Tab with ID ${id} not found`);
      throw new NotFoundException(`Tab with ID ${id} not found`);
    }
    this.logger.log(`Tab deleted: ${id}`);
  }
}
