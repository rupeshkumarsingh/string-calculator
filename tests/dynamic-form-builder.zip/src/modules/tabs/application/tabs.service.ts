import {
  Injectable,
  NotFoundException,
  ConflictException,
  InternalServerErrorException,
  BadRequestException,
} from '@nestjs/common';
import { TabsRepository } from '../infrastructure/repositories/tabs.repository';
import { CreateTabDto } from './dto/create-tab.dto';
import { UpdateTabDto } from './dto/update.tab.dto';
import { ITab } from '../domain/tabs';
import { BaseService } from '../../common/pagination/services/base.service';
import { LoggerService } from '../../../logging/error-log/logger.service';
import { AuditLogService } from '../../../logging/audit-log/audit-log.service';
import {
  AuditAction,
  AuditEntity,
} from '../../../logging/audit-log/audit-log.enums';
import { FormRepository } from '../../forms/infrastructure/repositories/forms.repository';

@Injectable()
export class TabsService extends BaseService<ITab> {
  constructor(
    private readonly tabsRepository: TabsRepository,
    private readonly logger: LoggerService,
    private readonly auditLog: AuditLogService,
    private readonly formRepository: FormRepository,
  ) {
    super(tabsRepository);
  }

  /**
   * Create a new Tab
   * @param CreateTabDto The DTO containing the Tab data
   * @returns The newly created Tab
   */
  async createTab(formId: string, createTabDto: CreateTabDto): Promise<ITab> {
    try {
      const isUnique = await this.validateUniqueName(
        createTabDto.formId,
        createTabDto.name,
      );
      if (!isUnique) {
        this.logger.warn('Tab name must be unique', {
          CreateTabDto,
        });
        throw new ConflictException('Tab with this name already exists');
      }
      const tabData: ITab = { ...createTabDto } as ITab;
      const tab = await this.tabsRepository.createTab(tabData);

      await this.formRepository.updateFormTabs(formId, tab._id);

      //Audit Log
      await this.auditLog.logAudit({
        action: AuditAction.CREATE,
        entityName: AuditEntity.TAB,
        effectedEntityId: tab.id,
        newValue: tab,
      });

      this.logger.log(`Tab created successfully: ${tab.id}`, 'TabsService');
      return tab;
    } catch (error) {
      if (error instanceof ConflictException) {
        this.logger.warn('Conflict occurred while creating tab', error);
        throw error;
      }
      this.logger.error('Error creating Tab', error.stack);
      throw new InternalServerErrorException('Failed to create Tab');
    }
  }

  /**
   * Get Tab by ID
   * @param id Tab ID
   * @returns The Tab if found, otherwise throws NotFoundException
   */
  async getTabById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<ITab> {
    const Tab = await this.tabsRepository.getTabById(id, tenantId, platformId);
    if (!Tab) {
      this.logger.warn(`Tab with ID ${id} not found`);
      throw new NotFoundException(`Tab with ID ${id} not found`);
    }
    this.logger.log(`Tab retrieved: ${Tab.id}`);
    return Tab;
  }

  /**
   * Update a Tab
   * @param id Tab ID
   * @param updateDto DTO containing update data
   * @returns The updated Tab, or throws NotFoundException if not found
   */
  async updateTab(
    id: string,
    updateTabDto: UpdateTabDto,
    tenantId: string,
    platformId: string,
  ): Promise<ITab> {
    const existingTab = await this.tabsRepository.getTabById(
      id,
      tenantId,
      platformId,
    );

    if (!existingTab) {
      this.logger.warn(`Tab with ID ${id} not found`);
      throw new NotFoundException(`Tab with ID ${id} not found`);
    }

    if (updateTabDto.name && updateTabDto.formId) {
      await this.validateUniqueName(updateTabDto.formId, updateTabDto.name, id);
    }

    const updatedItems = updateTabDto.items?.map((item) => ({
      label: item.label,
      name: item.name,
    }));

    const updateData: Partial<ITab> = {
      ...updateTabDto,
      items: updatedItems,
    } as ITab;

    const updatedTab = await this.tabsRepository.updateTab(id, updateData);

    if (!updatedTab) {
      this.logger.warn(`Failed to update Tab with ID ${id} - returned null`);
      throw new InternalServerErrorException(
        'Failed to update Tab - returned null',
      );
    }
    // Audit Log for Update
    await this.auditLog.logAudit({
      action: AuditAction.UPDATE,
      entityName: AuditEntity.TAB,
      effectedEntityId: updatedTab.id,
      oldValue: existingTab,
      newValue: updatedTab,
    });

    this.logger.log(`Tab updated: ${updatedTab.id}`);
    return updatedTab;
  }

  /**
   * Delete a Tab
   * @param id Tab ID
   * @returns The deleted Tab, or throws NotFoundException if not found
   */
  async deleteTab(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<ITab | null> {
    const existingTab = await this.tabsRepository.getTabById(
      id,
      tenantId,
      platformId,
    );

    if (!existingTab) {
      this.logger.warn(`Tab with ID ${id} not found`);
      throw new NotFoundException(`Tab with ID ${id} not found`);
    }

    const formId = existingTab.formId || '';

    await this.formRepository.detachTabFromFormById(formId, id);
    const deletedTab = await this.tabsRepository.deleteTab(id);
    if (!deletedTab) {
      this.logger.warn(`Failed to delete Tab with ID ${id} - returned null`);
      throw new InternalServerErrorException(
        'Failed to delete tab - returned null',
      );
    }

    // Audit Log for Delete
    await this.auditLog.logAudit({
      action: AuditAction.DELETE,
      entityName: AuditEntity.TAB,
      effectedEntityId: deletedTab.id,
      oldValue: existingTab,
    });

    this.logger.log(`Tab deleted: ${deletedTab.id}`);
    return deletedTab;
  }

  /**
   * Validates that the provided tab name is unique for the specified form ID.
   *
   * This function checks if a tab with the same name already exists for the
   * given form ID. If an existing tab is found and it's not the current tab
   *
   * @param {string} formId - The unique identifier of the form to which the tab belongs.
   * @param {string} name - The tab name to validate for uniqueness.
   * @param {string} [currentTabId] - Optional. The ID of the current tab, used during update operations.
   * @returns {Promise<void>} - Resolves successfully if the name is uniq
   */
  async validateUniqueName(
    formId: string,
    name: string,
    currentTabId?: string,
  ): Promise<boolean> {
    if (!formId || !name) {
      throw new BadRequestException('Form ID and name are required.');
    }

    try {
      const existingTab = await this.tabsRepository.findByFormIdAndName(
        formId,
        name,
      );

      if (
        existingTab &&
        (!currentTabId || existingTab._id.toString() !== currentTabId)
      ) {
        this.logger.log(
          `Tab name conflict detected: ${name} for formId ${formId}`,
        );
        return false;
      }

      return true;
    } catch (error) {
      this.logger.error(
        `Error during tab name validation for formId ${formId} and name ${name}:`,
        error,
      );
      throw new BadRequestException(
        'Unable to validate the tab name at this time. Please try again later.',
      );
    }
  }
}
