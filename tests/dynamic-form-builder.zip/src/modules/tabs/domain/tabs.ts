import { Document, ObjectId } from 'mongoose';

export interface ITabItem extends Document {
  _id: ObjectId;
  label: string;
  name: string;
}

export interface ITab extends Document {
  _id: string;
  name: string;
  description?: string;
  status: string;
  items?: ITabItem[];
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
  isDeleted?: boolean;
  tenantId: string;
  platformId: string;
  formId?: string;
}
