import { BaseRepository } from '../../common/pagination/interfaces/base.repository.interface';
import { ITab } from './tabs';

export interface ITabsRepository extends BaseRepository<ITab> {
  createTab(tabData: ITab): Promise<ITab>;
  getTabById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<ITab | null>;
  updateTab(id: string, updateData: Partial<ITab>): Promise<ITab | null>;
  deleteTab(id: string): Promise<ITab | null>;
  findAllPaginated(
    filters: Record<string, unknown>,
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
    includeDeleted?: boolean,
    tenantId?: string,
    platformId?: string,
  );
}
