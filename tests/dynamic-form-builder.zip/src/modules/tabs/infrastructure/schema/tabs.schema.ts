import { model, Schema } from 'mongoose';
import { ITab } from '../../domain/tabs';
import { Status } from '../../../../shared/utils/status.enum';
import {
  SchemaFieldUtils,
  SchemaIndexUtils,
} from '../../../../shared/utils/schema-utils';
import { TabItemSchema } from './tab-item-schema';

const TabSchema = new Schema<ITab>({
  name: SchemaFieldUtils.createStringField(true),
  description: SchemaFieldUtils.createStringField(),
  status: SchemaFieldUtils.createStringField(
    false,
    Status.ACTIVE,
    Object.values(Status),
  ),
  formId: SchemaFieldUtils.createField(Schema.Types.ObjectId, { ref: 'Form' }),
  items: [TabItemSchema],
});

// Add common fields and indexes
SchemaIndexUtils.addCommonFields(TabSchema);
SchemaIndexUtils.addIndexes(TabSchema, [
  { tenantId: 1, platformId: 1, formId: 1 },
]);

TabSchema.virtual('form', {
  ref: 'Form',
  localField: 'formId',
  foreignField: '_id',
  justOne: true,
});

TabSchema.set('toJSON', { virtuals: true });
TabSchema.set('toObject', { virtuals: true });

export { TabSchema };

export const TabModel = model<ITab>('Tab', TabSchema);
