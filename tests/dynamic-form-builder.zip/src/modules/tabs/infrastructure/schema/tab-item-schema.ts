import { Schema } from 'mongoose';
import { SchemaFieldUtils } from '../../../../shared/utils/schema-utils';

export const TabItemSchema = new Schema(
  {
    label: SchemaFieldUtils.createStringField(true),
    name: SchemaFieldUtils.createField(Schema.Types.Mixed, { required: false }),
  },
  { _id: false },
);
