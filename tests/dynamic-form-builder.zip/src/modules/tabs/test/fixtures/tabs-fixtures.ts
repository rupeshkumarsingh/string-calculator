import { ITab } from '../../domain/tabs';
import { CreateTabDto } from '../../application/dto/create-tab.dto';
import { UpdateTabDto } from '../../application/dto/update.tab.dto';
import { Status } from '../../../../shared/utils/status.enum';

export const validTabDto: CreateTabDto = {
  name: 'Registration Form Tab',
  description: 'Registration Form Tab',
  status: Status.ACTIVE,
  createdBy: 'user123',
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
  formId: '6798bc302d7605b80b2ad5f4',
  items: [],
};

export const TabWithErrors: CreateTabDto = {
  name: 'Registration Form Tab',
  description: 'Registration Form Tab',
  status: Status.ACTIVE,
  createdBy: 'user123',
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
  formId: '6798bc302d7605b80b2ad5f4',
  items: [],
};

export const existingTab = {
  _id: '670e0a510e63a8b44e2d3521',
  name: 'Login Form Tab',
  description: 'Login Form Tab',
  formId: '6798bc302d7605b80b2ad5f4',
  status: Status.ACTIVE,
} as ITab;

export const updatedTabDto: UpdateTabDto = {
  name: 'Login Form Tab',
  description: 'Login Form Tab',
  status: Status.ACTIVE,
};

export const newTabDto: CreateTabDto = {
  name: 'Login Form Tab',
  description: 'Login Form Tab',
  status: Status.ACTIVE,
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
  formId: '6798bc302d7605b80b2ad5f4',
  items: [],
};

export const nonExistentTabId = 'non-existent-id';
