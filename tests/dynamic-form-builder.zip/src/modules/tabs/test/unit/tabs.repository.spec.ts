import { Test, TestingModule } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { ITab } from '../../domain/tabs';
import { Model, Types } from 'mongoose';
import { TabsRepository } from '../../infrastructure/repositories/tabs.repository';
import { LoggerService } from '../../../../logging/error-log/logger.service';
import { RepositoryException } from '../../../../shared/exceptions/repository.exception';

describe('TabsRepository', () => {
  let repository: TabsRepository;
  let model: Model<ITab>;
  let logger: LoggerService;

  const mockTabModel = jest.fn().mockImplementation(() => ({
    save: jest.fn(),
    findById: jest.fn().mockReturnThis(),
    exec: jest.fn(),
    countDocuments: jest.fn(),
    find: jest.fn(),
    sort: jest.fn().mockReturnThis(),
    skip: jest.fn().mockReturnThis(),
    limit: jest.fn().mockReturnThis(),
  }));

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const mockTabData = {
    _id: '670e0e640cd41b6881c65c48',
    name: 'Sales Form Tab',
    description: 'Sales Form Tab',
    status: 'active',
    isDeleted: false,
    tenantId: '6708eaf5ab7b16c964098737',
    platformId: '6708eaee1f18d52405c72f88',
  } as ITab;

  const tenantId = '6708eaf5ab7b16c964098737';
  const platformId = '6708eaee1f18d52405c72f88';

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TabsRepository,
        {
          provide: getModelToken('Tab'),
          useValue: mockTabModel,
        },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    repository = module.get<TabsRepository>(TabsRepository);
    model = module.get<Model<ITab>>(getModelToken('Tab'));
    logger = module.get<LoggerService>(LoggerService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('createTab', () => {
    it('should create and save a new form', async () => {
      const formInstance = new mockTabModel();
      mockTabModel.mockImplementation(() => formInstance);
      formInstance.save.mockResolvedValue(mockTabData);

      const result = await repository.createTab(mockTabData);

      expect(mockTabModel).toHaveBeenCalledWith(mockTabData);
      expect(formInstance.save).toHaveBeenCalled();
      expect(result).toEqual(mockTabData);
    });
    it('should throw RepositoryException if an error occurs during tab creation', async () => {
      const errorMessage = 'Failed to create tab';
      const formInstance = new mockTabModel();
      mockTabModel.mockImplementation(() => formInstance);
      formInstance.save.mockRejectedValue(new Error(errorMessage));

      await expect(repository.createTab(mockTabData)).rejects.toThrow(
        new RepositoryException('Failed to create tab', errorMessage),
      );
    });
  });

  describe('getTabById', () => {
    it('should return a tab by id when found', async () => {
      const objectId = new Types.ObjectId(mockTabData._id);

      const execMock = jest.fn().mockResolvedValue(mockTabData);
      const findByIdMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findByIdMock;

      const result = await repository.getTabById(
        mockTabData._id,
        tenantId,
        platformId,
      );

      expect(model.findOne).toHaveBeenCalledWith({
        _id: objectId,
        tenantId,
        platformId,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockTabData);
    });

    it('should return null when no tab is found for the given id', async () => {
      const objectId = new Types.ObjectId(mockTabData._id);

      const execMock = jest.fn().mockResolvedValue(null);
      const findByIdMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findByIdMock;

      const result = await repository.getTabById(
        mockTabData._id,
        tenantId,
        platformId,
      );

      expect(model.findOne).toHaveBeenCalledWith({
        _id: objectId,
        tenantId,
        platformId,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toBeNull();
    });

    it('should throw a RepositoryException if findOne fails', async () => {
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findByIdMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findByIdMock;

      await expect(
        repository.getTabById(mockTabData._id, tenantId, platformId),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error fetching tab with id ${mockTabData._id}`,
        mockError.message,
      );
    });

    it('should log a warning and return null if tab is not found', async () => {
      const execMock = jest.fn().mockResolvedValue(null);
      const findByIdMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findByIdMock;

      const result = await repository.getTabById(
        mockTabData._id,
        tenantId,
        platformId,
      );

      expect(logger.warn).toHaveBeenCalledWith(
        `tab with id ${mockTabData._id} not found for Tenant ID: ${tenantId} and Platform ID: ${platformId}`,
      );
      expect(result).toBeNull();
    });
  });

  describe('updateTab', () => {
    const mockUpdateData = { name: 'Purchase Form Tabs' };

    it('should update and return the updated Tab', async () => {
      const mockUpdatedTemplate = { ...mockTabData, ...mockUpdateData };

      const execMock = jest.fn().mockResolvedValue(mockUpdatedTemplate);
      const findOneAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findOneAndUpdate = findOneAndUpdateMock;

      const result = await repository.updateTab(
        mockTabData._id,
        mockUpdateData,
      );

      expect(model.findOneAndUpdate).toHaveBeenCalledWith(
        new Types.ObjectId(mockTabData._id),
        mockUpdateData,
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockUpdatedTemplate);
    });

    it('should throw a RepositoryException if updating fails', async () => {
      const mockError = new Error('Update failed');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findOneAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findOneAndUpdate = findOneAndUpdateMock;

      await expect(
        repository.updateTab(mockTabData._id, mockUpdateData),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error updating tab with id ${mockTabData._id}`,
        mockError.message,
      );
    });
  });

  describe('deleteTab', () => {
    it('should soft delete and return the updated Tab', async () => {
      const mockSoftDeletedTemplate = { ...mockTabData, isDeleted: true };

      // Create a mock return value that includes the exec method
      const execMock = jest.fn().mockResolvedValue(mockSoftDeletedTemplate);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.deleteTab(mockTabData._id);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        new Types.ObjectId(mockTabData._id),
        { isDeleted: true },
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockSoftDeletedTemplate);
    });

    it('should throw a RepositoryException if soft deletion fails', async () => {
      const mockError = new Error('Soft delete failed');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(repository.deleteTab(mockTabData._id)).rejects.toThrow(
        RepositoryException,
      );

      expect(logger.error).toHaveBeenCalledWith(
        `Error deleting tab with id ${mockTabData._id}`,
        mockError.message,
      );
    });

    it('should throw a RepositoryException for invalid id format', async () => {
      const invalidId = 'invalid-object-id';

      await expect(repository.deleteTab(invalidId)).rejects.toThrow(
        RepositoryException,
      );

      expect(logger.error).toHaveBeenCalledWith(
        `Error deleting tab with id ${invalidId}`,
        expect.any(String),
      );
    });

    it('should return null if no tab is found for the given id', async () => {
      const execMock = jest.fn().mockResolvedValue(null);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.deleteTab(mockTabData._id);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        new Types.ObjectId(mockTabData._id),
        { isDeleted: true },
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toBeNull();
    });
  });

  describe('findByFormIdAndName', () => {
    const mockFormId = '6708eaee1f18d52405c72f88';
    const mockName = 'Sample Tab Name';
    const mockTab = {
      _id: new Types.ObjectId('670e0e640cd41b6881c65c48'),
      formId: mockFormId,
      name: mockName,
      isDeleted: false,
    };

    it('should return a tab when found', async () => {
      const execMock = jest.fn().mockResolvedValue(mockTab);
      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findOneMock;

      const result = await repository.findByFormIdAndName(mockFormId, mockName);

      expect(model.findOne).toHaveBeenCalledWith({
        formId: mockFormId,
        name: mockName,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockTab);
    });

    it('should return null when no tab is found', async () => {
      const execMock = jest.fn().mockResolvedValue(null);
      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findOneMock;

      const result = await repository.findByFormIdAndName(mockFormId, mockName);

      expect(model.findOne).toHaveBeenCalledWith({
        formId: mockFormId,
        name: mockName,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toBeNull();
    });

    it('should throw a RepositoryException if an error occurs', async () => {
      const mockError = new Error('Database error');
      const execMock = jest.fn().mockRejectedValue(mockError);
      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findOneMock;

      await expect(
        repository.findByFormIdAndName(mockFormId, mockName),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error finding tab by formId ${mockFormId} and name ${mockName}:`,
        mockError,
      );
    });

    it('should throw an error if formId or name is missing', async () => {
      await expect(
        repository.findByFormIdAndName('', mockName),
      ).rejects.toThrow('formId and name are required to find a tab');

      await expect(
        repository.findByFormIdAndName(mockFormId, ''),
      ).rejects.toThrow('formId and name are required to find a tab');
    });
  });

  describe('deleteByFormId', () => {
    const mockFormId = '6708eaee1f18d52405c72f88';
    const mockResult = { modifiedCount: 3 };

    it('should soft delete tabs by formId and return the result', async () => {
      const execMock = jest.fn().mockResolvedValue(mockResult);
      const updateManyMock = jest.fn().mockReturnValue({ exec: execMock });

      model.updateMany = updateManyMock;

      const result = await repository.deleteByFormId(mockFormId);

      expect(model.updateMany).toHaveBeenCalledWith(
        { formId: mockFormId },
        { isDeleted: true },
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(logger.log).toHaveBeenCalledWith(
        `Updated tabs ${mockResult.modifiedCount} records of form id ${mockFormId}.`,
      );
      expect(result).toEqual(mockResult);
    });

    it('should throw an error and log it if updateMany fails', async () => {
      const mockError = new Error('Database error');
      const execMock = jest.fn().mockRejectedValue(mockError);
      const updateManyMock = jest.fn().mockReturnValue({ exec: execMock });

      model.updateMany = updateManyMock;

      await expect(repository.deleteByFormId(mockFormId)).rejects.toThrow(
        mockError,
      );

      expect(model.updateMany).toHaveBeenCalledWith(
        { formId: mockFormId },
        { isDeleted: true },
        { new: true },
      );
      expect(logger.error).toHaveBeenCalledWith(
        `Failed to delete tabs for form: ${mockFormId}`,
        mockError,
      );
    });
  });
});
