import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import mongoose from 'mongoose';
import { TabModel } from '../../infrastructure/schema/tabs.schema';
import databaseConfig from '../../../../database/config/database.config';
import { DatabaseModule } from '../../../../database/database.module';

describe('Tab Model and Schema', () => {
  let module: TestingModule;

  beforeAll(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          load: [databaseConfig],
          envFilePath: '.env',
          isGlobal: true,
        }),
        DatabaseModule,
      ],
    }).compile();
  });

  afterAll(async () => {
    //await mongoose.connection.close();
    module.close();
  });

  beforeEach(async () => {
    //await tabModel.deleteMany({});
  });

  it('should throw an error if name is missing', async () => {
    const tabData = {
      description: 'tab without a name',
      status: 'active',
    };

    const tab = new TabModel(tabData);
    await expect(tab.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });

  it('should throw an error if description is missing', async () => {
    const tabData = {
      name: 'Tab without description',
      status: 'active',
    };

    const form = new TabModel(tabData);
    await expect(form.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });

  it('should throw an error if status is invalid', async () => {
    const tabData = {
      name: 'Invalid Status tab',
      description: 'This tab has an invalid status',
      status: 'invalid_status', // Invalid status not in enum
    };

    const tab = new TabModel(tabData);
    await expect(tab.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });
});
