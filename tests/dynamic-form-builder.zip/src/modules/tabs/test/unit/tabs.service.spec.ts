import { Test, TestingModule } from '@nestjs/testing';
import {
  BadRequestException,
  ConflictException,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { TabsService } from '../../application/tabs.service';
import { TabsRepository } from '../../infrastructure/repositories/tabs.repository';
import {
  validTabDto,
  existingTab,
  newTabDto,
  updatedTabDto,
  nonExistentTabId,
} from '../fixtures/tabs-fixtures';
import { PaginatedResult } from '../../../common/pagination/interfaces/paginated-result.interface';
import { ITab } from '../../domain/tabs';
import { PaginationDto } from '../../../common/pagination/dto/pagination.dto';
import { LoggerService } from '../../../../logging/error-log/logger.service';
import { AuditLogService } from '../../../../logging/audit-log/audit-log.service';
import { FormRepository } from '../../../forms/infrastructure/repositories/forms.repository';

describe('TabsService', () => {
  let service: TabsService;
  let repository: TabsRepository;
  //let formRepository: FormRepository;

  const mockPaginatedResult: PaginatedResult<ITab> = {
    items: [],
    total: 0,
    page: 1,
    limit: 100,
    totalPages: 0,
  };
  const mockTabRepository = {
    createTab: jest.fn(),
    getTabById: jest.fn(),
    findAllPaginated: jest.fn().mockResolvedValue(mockPaginatedResult),
    updateTab: jest.fn(),
    deleteTab: jest.fn(),
    findByFormIdAndName: jest.fn(),
  };

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const mockAuditLogService = {
    logAudit: jest.fn(),
  };

  const tenantId = '6708eaf5ab7b16c964098737';
  const platformId = '6708eaee1f18d52405c72f88';
  const formId = existingTab.formId || '';

  const mockFormRepository = {
    updateFormTabs: jest.fn(),
    detachTabFromFormById: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TabsService,
        { provide: TabsRepository, useValue: mockTabRepository },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
        {
          provide: AuditLogService,
          useValue: mockAuditLogService,
        },
        { provide: FormRepository, useValue: mockFormRepository },
      ],
    }).compile();

    service = module.get<TabsService>(TabsService);
    repository = module.get<TabsRepository>(TabsRepository);
    //formRepository = module.get<FormRepository>(FormRepository);
  });

  describe('createTab', () => {
    it('should create and return a Tab successfully', async () => {
      mockTabRepository.findByFormIdAndName.mockResolvedValue(undefined);
      mockTabRepository.createTab.mockResolvedValue(existingTab);
      mockFormRepository.updateFormTabs.mockResolvedValue(undefined);

      const result = await service.createTab(formId, validTabDto);

      expect(mockTabRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        validTabDto.name,
      );
      expect(mockTabRepository.createTab).toHaveBeenCalledWith(
        expect.objectContaining(validTabDto),
      );

      expect(result).toEqual(existingTab);
    });

    it('should throw BadRequestException on validation failure', async () => {
      mockTabRepository.findByFormIdAndName.mockResolvedValue(undefined);
      mockTabRepository.createTab.mockRejectedValue(
        new Error('validation failed'),
      );

      await expect(service.createTab(formId, validTabDto)).rejects.toThrow(
        InternalServerErrorException,
      );
    });

    it('should throw ConflictException for duplicate Tab', async () => {
      mockTabRepository.createTab.mockResolvedValue(undefined);
      mockTabRepository.findByFormIdAndName.mockResolvedValue(validTabDto);

      await expect(service.createTab(formId, validTabDto)).rejects.toThrow(
        ConflictException,
      );
    });

    it('should create and return a new Tab with new values', async () => {
      mockTabRepository.createTab.mockResolvedValue(newTabDto);
      mockTabRepository.findByFormIdAndName.mockResolvedValue(undefined);

      const result = await service.createTab(formId, newTabDto);

      expect(result).toEqual(newTabDto);
    });

    it('should throw InternalServerErrorException on unexpected error', async () => {
      mockTabRepository.createTab.mockRejectedValue(
        new Error('Database error'),
      );
      mockTabRepository.findByFormIdAndName.mockResolvedValue(undefined); // Ensure uniqueness check passes

      await expect(service.createTab(formId, validTabDto)).rejects.toThrow(
        InternalServerErrorException,
      );
    });
  });

  describe('getTabById', () => {
    it('should return a Tab successfully', async () => {
      const id = '66ebcb8f570e341a486525cd';
      mockTabRepository.getTabById.mockResolvedValue(existingTab);

      const result = await service.getTabById(id, tenantId, platformId);
      expect(result).toBe(existingTab);
      expect(mockTabRepository.getTabById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if Tab not found', async () => {
      const id = 'non-existent-id';
      mockTabRepository.getTabById.mockResolvedValue(null);

      await expect(
        service.getTabById(id, tenantId, platformId),
      ).rejects.toThrow(new NotFoundException(`Tab with ID ${id} not found`));
      expect(mockTabRepository.getTabById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });
  });

  describe('findAllPaginated', () => {
    it('should call repository findAllPaginated with default values', async () => {
      const paginationQuery: PaginationDto = {};
      await service.findAllPaginated(
        paginationQuery,
        false,
        tenantId,
        platformId,
      );

      expect(repository.findAllPaginated).toHaveBeenCalledWith(
        {},
        1,
        100,
        'createdAt',
        'asc',
        false,
        tenantId,
        platformId,
      );
    });

    it('should call repository findAllPaginated with passed values', async () => {
      const paginationQuery: PaginationDto = {
        page: 2,
        limit: 50,
        sortBy: 'title',
        sortOrder: 'desc',
        filters: { status: 'active' },
      };

      await service.findAllPaginated(
        paginationQuery,
        false,
        tenantId,
        platformId,
      );

      expect(repository.findAllPaginated).toHaveBeenCalledWith(
        { status: 'active' },
        2,
        50,
        'title',
        'desc',
        false,
        tenantId,
        platformId,
      );
    });

    it('should return the paginated result from repository', async () => {
      const result = await service.findAllPaginated(
        {},
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should handle errors from the repository', async () => {
      const error = new Error('Repository error');
      mockTabRepository.findAllPaginated.mockRejectedValueOnce(error);

      await expect(
        service.findAllPaginated({}, false, tenantId, platformId),
      ).rejects.toThrow('Repository error');
    });
  });

  describe('updateTab', () => {
    it('should update and return the Tab successfully', async () => {
      const id = '66ebcb8f570e341a486525cd';
      const updateDto = updatedTabDto;
      const updatedTab = { ...existingTab, ...updateDto };

      mockTabRepository.getTabById.mockResolvedValue(existingTab);

      mockTabRepository.updateTab.mockResolvedValue(updatedTab);

      const result = await service.updateTab(
        id,
        updateDto,
        tenantId,
        platformId,
      );

      expect(mockTabRepository.getTabById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockTabRepository.updateTab).toHaveBeenCalledWith(id, updateDto);
      expect(result).toEqual({ ...existingTab, ...updateDto });
    });

    it('should throw NotFoundException if Tab to update is not found', async () => {
      mockTabRepository.getTabById.mockResolvedValueOnce(null);

      await expect(
        service.updateTab(
          nonExistentTabId,
          updatedTabDto,
          tenantId,
          platformId,
        ),
      ).rejects.toThrow(NotFoundException);

      expect(mockTabRepository.updateTab).toHaveBeenCalled();
    });

    it('should throw InternalServerErrorException if update returns null1', async () => {
      // Arrange: Mock the repository methods
      mockTabRepository.getTabById.mockResolvedValue(existingTab);
      mockTabRepository.updateTab.mockResolvedValue(null);
      await expect(
        service.updateTab(existingTab.id, updatedTabDto, tenantId, platformId),
      ).rejects.toThrow(InternalServerErrorException);
      expect(mockTabRepository.getTabById).toHaveBeenCalledWith(
        existingTab.id,
        tenantId,
        platformId,
      );
      expect(mockTabRepository.updateTab).toHaveBeenCalledWith(
        existingTab.id,
        updatedTabDto,
      );
    });

    it('should call validateUniqueName when name and formId are provided', async () => {
      const id = '66ebcb8f570e341a486525cd';
      const updateDto = {
        ...updatedTabDto,
        name: 'newName',
        formId: 'newFormId',
      };

      mockTabRepository.getTabById.mockResolvedValue(existingTab);
      mockTabRepository.updateTab.mockResolvedValue({
        ...existingTab,
        ...updateDto,
      });
      jest.spyOn(service, 'validateUniqueName').mockResolvedValue(true);

      await service.updateTab(id, updateDto, tenantId, platformId);

      expect(service.validateUniqueName).toHaveBeenCalledWith(
        updateDto.formId,
        updateDto.name,
        id,
      );
    });
  });
  describe('deleteTab', () => {
    it('should delete the Tab successfully', async () => {
      const id = existingTab._id;
      const formId = existingTab.formId;
      mockTabRepository.getTabById.mockResolvedValueOnce(existingTab);
      mockTabRepository.deleteTab.mockResolvedValueOnce(existingTab);
      mockFormRepository.detachTabFromFormById.mockResolvedValue(true);

      const result = await service.deleteTab(id, tenantId, platformId);

      expect(result).toEqual(existingTab);
      expect(mockTabRepository.getTabById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.detachTabFromFormById).toHaveBeenCalledWith(
        formId,
        id,
      );

      expect(mockTabRepository.deleteTab).toHaveBeenCalledWith(id);
    });

    it('should delete the Tab successfully when formId is null', async () => {
      const tabWithoutFormId = { ...existingTab, formId: null }; // Mock Tab with no formId
      const id = tabWithoutFormId._id;

      mockTabRepository.getTabById.mockResolvedValueOnce(tabWithoutFormId);
      mockTabRepository.deleteTab.mockResolvedValueOnce(tabWithoutFormId);
      mockFormRepository.detachTabFromFormById.mockResolvedValue(true);

      const result = await service.deleteTab(id, tenantId, platformId);

      expect(result).toEqual(tabWithoutFormId);
      expect(mockTabRepository.getTabById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      // Validate that detachTabFromFormById was called with empty string for formId
      expect(mockFormRepository.detachTabFromFormById).toHaveBeenCalledWith(
        '',
        id,
      );
      expect(mockTabRepository.deleteTab).toHaveBeenCalledWith(id);
    });

    it('should throw NotFoundException if Tab to delete is not found', async () => {
      const id = nonExistentTabId;
      mockTabRepository.getTabById.mockResolvedValueOnce(null);

      await expect(service.deleteTab(id, tenantId, platformId)).rejects.toThrow(
        new NotFoundException(`Tab with ID ${id} not found`),
      );
      expect(mockTabRepository.getTabById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });

    it('should throw InternalServerErrorException if deleteTab returns null', async () => {
      const id = existingTab._id;

      mockTabRepository.getTabById.mockResolvedValueOnce(existingTab);
      mockTabRepository.deleteTab.mockResolvedValueOnce(null);
      mockFormRepository.detachTabFromFormById.mockResolvedValue(true);

      await expect(
        service.deleteTab(id, tenantId, platformId),
      ).rejects.toThrowError(
        new InternalServerErrorException(
          'Failed to delete tab - returned null',
        ),
      );

      expect(mockTabRepository.getTabById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.detachTabFromFormById).toHaveBeenCalledWith(
        existingTab.formId,
        id,
      );
      expect(mockTabRepository.deleteTab).toHaveBeenCalledWith(id);
      expect(mockLoggerService.warn).toHaveBeenCalledWith(
        `Failed to delete Tab with ID ${id} - returned null`,
      );
    });
  });

  describe('validateUniqueName', () => {
    it('should return true when the name is unique for the given form', async () => {
      const formId = 'form123';
      const name = 'uniqueTabName';
      const currentTabId = 'currentTabId';

      mockTabRepository.findByFormIdAndName.mockResolvedValueOnce(null);

      // Call the service method
      const result = await service.validateUniqueName(
        formId,
        name,
        currentTabId,
      );

      expect(result).toBe(true);
      expect(mockTabRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        name,
      );
    });

    it('should return false if a tab with the same name already exists (name conflict)', async () => {
      const formId = 'form123';
      const name = 'duplicateTabName';
      const currentTabId = 'currentTabId';

      const existingTab = { _id: 'existingTabId' };
      mockTabRepository.findByFormIdAndName.mockResolvedValueOnce(existingTab);

      const result = await service.validateUniqueName(
        formId,
        name,
        currentTabId,
      );

      expect(result).toBe(false);
      expect(mockTabRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        name,
      );
    });

    it('should return true if the tab name matches the current tab being updated', async () => {
      const formId = 'form123';
      const name = 'duplicateTabName';
      const currentTabId = 'existingTabId';

      const existingTab = { _id: 'existingTabId' };
      mockTabRepository.findByFormIdAndName.mockResolvedValueOnce(existingTab);

      const result = await service.validateUniqueName(
        formId,
        name,
        currentTabId,
      );

      expect(result).toBe(true);
      expect(mockTabRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        name,
      );
    });

    it('should throw BadRequestException if formId or name is missing', async () => {
      const formId = '';
      const name = 'tabName';

      await expect(
        service.validateUniqueName(formId, name),
      ).rejects.toThrowError(
        new BadRequestException('Form ID and name are required.'),
      );
    });

    it('should throw BadRequestException if there is an error during validation', async () => {
      const formId = 'form123';
      const name = 'tabName';

      mockTabRepository.findByFormIdAndName.mockRejectedValueOnce(
        new Error('Database error'),
      );

      await expect(
        service.validateUniqueName(formId, name),
      ).rejects.toThrowError(
        new BadRequestException(
          'Unable to validate the tab name at this time. Please try again later.',
        ),
      );
    });
  });
});
