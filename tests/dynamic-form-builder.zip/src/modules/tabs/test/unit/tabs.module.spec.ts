import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import { TabsModule } from '../../tabs.module';
import { TabsController } from '../../application/tabs.controller';
import { TabsService } from '../../application/tabs.service';
import { TabsRepository } from '../../infrastructure/repositories/tabs.repository';
import { LoggerModule } from '../../../../logging/error-log/logger.module';
import databaseConfig from '../../../../database/config/database.config';
import { DatabaseModule } from '../../../../database/database.module';

describe('TabsModule', () => {
  let module: TestingModule;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          load: [databaseConfig],
          envFilePath: '.env',
          isGlobal: true,
        }),
        DatabaseModule,
        TabsModule,
        LoggerModule,
      ],
    }).compile();
  });

  it('should compile the module successfully', () => {
    expect(module).toBeDefined();
  });

  it('should have the TabsController defined', () => {
    const controller = module.get<TabsController>(TabsController);
    expect(controller).toBeDefined();
  });

  it('should have the TabsService defined', () => {
    const service = module.get<TabsService>(TabsService);
    expect(service).toBeDefined();
  });

  it('should have the TabsRepository defined', () => {
    const repository = module.get<TabsRepository>(TabsRepository);
    expect(repository).toBeDefined();
  });
});
