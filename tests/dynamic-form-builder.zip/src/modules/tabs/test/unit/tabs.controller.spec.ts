import { Test, TestingModule } from '@nestjs/testing';
import {
  existingTab,
  validTabDto,
  nonExistentTabId,
} from '../fixtures/tabs-fixtures';
import { NotFoundException } from '@nestjs/common';
import { TabsController } from '../../application/tabs.controller';
import { TabsService } from '../../application/tabs.service';
import { CreateTabDto } from '../../application/dto/create-tab.dto';
import { UpdateTabDto } from '../../application/dto/update.tab.dto';
import { PaginatedResult } from '../../../common/pagination/interfaces/paginated-result.interface';
import { PaginationDto } from '../../../common/pagination/dto/pagination.dto';
import { LoggerService } from '../../../../logging/error-log/logger.service';

describe('TabsController', () => {
  let controller: TabsController;
  let service: TabsService;
  const mockPaginatedResult: PaginatedResult<unknown> = {
    items: [], // Simulate empty results for the test
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  };
  const mockTabsService = {
    createTab: jest.fn(),
    getTabById: jest.fn(),
    getAllTabs: jest.fn(),
    updateTab: jest.fn(),
    deleteTab: jest.fn(),
    findAllWithPopulatedData: jest.fn().mockResolvedValue(mockPaginatedResult),
  };

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const tenantId = '6708eaf5ab7b16c964098737';
  const platformId = '6708eaee1f18d52405c72f88';

  const populate = {
    path: 'form',
    select: 'name description',
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TabsController],
      providers: [
        { provide: TabsService, useValue: mockTabsService },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    controller = module.get<TabsController>(TabsController);
    service = module.get<TabsService>(TabsService);
  });

  describe('createTab', () => {
    it('should create and return a form successfully', async () => {
      mockTabsService.createTab.mockResolvedValue(existingTab);

      const result = await controller.createTab(validTabDto as CreateTabDto);
      const formId = existingTab.formId;
      expect(result).toEqual(existingTab);
      expect(service.createTab).toHaveBeenCalledWith(formId, validTabDto);
      expect(mockLoggerService.log).toHaveBeenCalledWith('Creating a new tab');
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Tab created successfully: ${existingTab.id}`,
      );
    });
    it('should throw NotFoundException if formId is invalid or missing', async () => {
      const invalidDto = { ...validTabDto, formId: nonExistentTabId };
      mockTabsService.createTab.mockResolvedValue(null);

      await expect(
        controller.createTab(invalidDto as CreateTabDto),
      ).rejects.toThrow(
        new NotFoundException(`Form with ID ${nonExistentTabId} not found`),
      );
      expect(mockLoggerService.warn).toHaveBeenCalledWith(
        `Failed to create tab. Form with ID ${nonExistentTabId} does not exist.`,
      );
    });
  });

  describe('getTabById', () => {
    it('should return a form by id', async () => {
      const id = '66f529997383a45da1867131';
      mockTabsService.getTabById.mockResolvedValue(existingTab);

      const result = await controller.getTabById(id, {
        tenantId,
        platformId,
      });
      expect(result).toEqual(existingTab);
      expect(service.getTabById).toHaveBeenCalledWith(id, tenantId, platformId);
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Retrieving tab with ID: ${id}`,
      );
    });

    it('should throw NotFoundException if form not found', async () => {
      const id = nonExistentTabId;
      mockTabsService.getTabById.mockResolvedValue(null);

      await expect(
        controller.getTabById(id, { tenantId, platformId }),
      ).rejects.toThrow(new NotFoundException(`Tab with ID ${id} not found`));
    });
  });

  describe('getAllTabs', () => {
    it('should be defined', () => {
      expect(controller).toBeDefined();
    });
    it('should call TabsService.findAllWithPopulatedData and return result', async () => {
      const query: PaginationDto = { page: 1, limit: 10 };

      const result = await controller.getAllTabs(query, {
        tenantId,
        platformId,
      });

      expect(service.findAllWithPopulatedData).toHaveBeenCalledWith(
        query,
        populate,
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should call TabsService.findAllWithPopulatedData with default query if none provided', async () => {
      const defaultQuery: PaginationDto = {};

      const result = await controller.getAllTabs(undefined, {
        tenantId,
        platformId,
      });

      expect(service.findAllWithPopulatedData).toHaveBeenCalledWith(
        defaultQuery,
        populate,
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });
  });

  describe('updateTab', () => {
    it('should update and return the tab', async () => {
      const id = '670e0a510e63a8b44e2d3521';
      const updateDto = {
        name: 'Updated tab',
        tenantId,
        platformId,
      } as UpdateTabDto;

      mockTabsService.updateTab.mockResolvedValue({
        ...existingTab,
      });

      const result = await controller.updateTab(id, updateDto);
      expect(result).toEqual({
        ...existingTab,
      });
      expect(service.updateTab).toHaveBeenCalledWith(
        id,
        updateDto,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if tab to update is not found', async () => {
      const id = nonExistentTabId;
      const updateDto = { name: 'Updated tab' } as UpdateTabDto;

      mockTabsService.updateTab.mockResolvedValue(null);

      await expect(controller.updateTab(id, updateDto)).rejects.toThrow(
        new NotFoundException(`Tab with ID ${id} not found`),
      );
    });
  });

  describe('deleteTab', () => {
    it('should delete the tab', async () => {
      const id = '670e0a510e63a8b44e2d3521';
      mockTabsService.deleteTab.mockResolvedValue(existingTab);

      await controller.deleteTab(id, { tenantId, platformId });
      expect(service.deleteTab).toHaveBeenCalledWith(id, tenantId, platformId);
    });

    it('should throw NotFoundException if tab to delete is not found', async () => {
      const id = nonExistentTabId;

      mockTabsService.deleteTab.mockResolvedValue(null);

      await expect(
        controller.deleteTab(id, { tenantId, platformId }),
      ).rejects.toThrow(new NotFoundException(`Tab with ID ${id} not found`));
    });
  });
});
