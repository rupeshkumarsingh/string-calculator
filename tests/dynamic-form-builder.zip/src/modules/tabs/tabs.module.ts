import { forwardRef, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TabsController } from './application/tabs.controller';
import { TabsService } from './application/tabs.service';
import { TabsRepository } from './infrastructure/repositories/tabs.repository';
import { TabSchema } from './infrastructure/schema/tabs.schema';
import { AuditLogModule } from '../../logging/audit-log/audit-log.module';
import { FormsModule } from '../forms/forms.module';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Tab', schema: TabSchema }]),
    forwardRef(() => FormsModule),
    AuditLogModule,
  ],
  controllers: [TabsController],
  providers: [TabsService, TabsRepository],
  exports: [TabsService, TabsRepository],
})
export class TabsModule {}
