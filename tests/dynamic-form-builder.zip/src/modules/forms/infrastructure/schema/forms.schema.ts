import { model, Schema } from 'mongoose';
import { IForm } from '../../domain/forms';
import {
  SchemaFieldUtils,
  SchemaIndexUtils,
} from '../../../../shared/utils/schema-utils';
import { Status } from '../../../../shared/utils/status.enum';

const FormSchema = new Schema<IForm>({
  name: SchemaFieldUtils.createStringField(true),
  description: SchemaFieldUtils.createStringField(),
  status: SchemaFieldUtils.createStringField(
    false,
    Status.ACTIVE,
    Object.values(Status),
  ),
  templates: [
    SchemaFieldUtils.createField(Schema.Types.ObjectId, { ref: 'Template' }),
  ],
  tabs: [SchemaFieldUtils.createField(Schema.Types.ObjectId, { ref: 'Tab' })],
  fields: [
    SchemaFieldUtils.createField(Schema.Types.ObjectId, { ref: 'Field' }),
  ],
});

// Add common fields and indexes
SchemaIndexUtils.addCommonFields(FormSchema);
SchemaIndexUtils.addIndexes(FormSchema, [
  { name: 1, tenantId: 1, platformId: 1 },
]);

export { FormSchema };

export const FormModel = model<IForm>('Form', FormSchema);
