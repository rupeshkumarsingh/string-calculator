import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { IForm } from '../../domain/forms';
import { IFormRepository } from '../../domain/forms.repository.interface';
import { RepositoryException } from '../../../../shared/exceptions/repository.exception';
import LoggerService from '../../../../logging/error-log/logger.service';
import { BaseRepository } from '../../../common/pagination/repositories/base.repository';
import { NotFoundError } from 'rxjs';

@Injectable()
export class FormRepository
  extends BaseRepository<IForm>
  implements IFormRepository
{
  constructor(
    @InjectModel('Form')
    private readonly formModel: Model<IForm>,
    private readonly logger: LoggerService,
  ) {
    super(formModel);
  }

  /**
   * Creates a new Form and saves it to the database.
   * @param formData - The data for the Form to be created.
   * @returns The created Form.
   * @throws RepositoryException if the creation fails.
   */
  async createForm(formData: IForm): Promise<IForm> {
    try {
      const form = new this.formModel(formData);
      this.logger.log('Creating Form', formData);
      return await form.save();
    } catch (error) {
      this.logger.error('Error creating Form', error.message);
      throw new RepositoryException('Failed to create Form', error);
    }
  }

  /**
   * Retrieves a Form by its MongoDB ObjectId.
   * @param id - The string representation of the Form's MongoDB ObjectId.
   * @param tenantId - The tenant ID for filtering.
   * @param platformId - The platform ID for filtering.
   * @returns The Form if found, or null if not found.
   * @throws RepositoryException if the retrieval fails.
   */
  async getFormById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<IForm | null> {
    try {
      this.logger.log(`Fetching Form by id: ${id}`);
      const objectId = new Types.ObjectId(id);

      // const form = await this.formModel
      //   .findOne({ _id: objectId, tenantId, platformId, isDeleted: false })
      //   .exec();

      const form = await this.formModel
        .findOne({ _id: objectId, tenantId, platformId, isDeleted: false })
        .populate([
          {
            path: 'fields',
            select:
              '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy',
            populate: {
              path: 'items',
              select:
                '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy -id -__v -id -formId -status -childFieldIds',
            },
          },
          {
            path: 'tabs',
            select:
              '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy',
          },
          {
            path: 'templates',
            select:
              '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy',
          },
        ])
        .select(
          '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy',
        )
        .exec();

      if (!form) {
        this.logger.warn(
          `Form with id ${id} not found for Tenant ID: ${tenantId} and Platform ID: ${platformId}`,
        );
        return null;
      }

      return form;
    } catch (error) {
      this.logger.error(`Error fetching Form with id ${id}`, error.message);
      throw new RepositoryException(`Failed to get Form with id ${id}`, error);
    }
  }

  /**
   * Updates a Form with the specified id.
   * @param id - The MongoDB ObjectId of the Form to be updated.
   * @param updateData - The partial data to update the Form with.
   * @returns The updated Form if successful, or null if not found.
   * @throws RepositoryException if the update fails.
   */
  async updateForm(
    id: string,
    updateData: Partial<IForm>,
  ): Promise<IForm | null> {
    try {
      this.logger.log(`Updating Form with id: ${id}`, updateData);
      const objectId = new Types.ObjectId(id);
      return await this.formModel
        .findOneAndUpdate(objectId, updateData, { new: true })
        .exec();
    } catch (error) {
      this.logger.error(`Error updating Form with id ${id}`, error.message);
      throw new RepositoryException(
        `Failed to update Form with id ${id}`,
        error,
      );
    }
  }

  /**
   * Deletes a Form by its MongoDB ObjectId.
   * @param id - The MongoDB ObjectId of the Form to be deleted.
   * @returns The deleted Form if successful, or null if not found.
   * @throws RepositoryException if the deletion fails.
   */
  async deleteForm(id: string): Promise<IForm | null> {
    try {
      this.logger.log(`Deleting Form with id: ${id}`);
      const objectId = new Types.ObjectId(id);
      return await this.formModel
        .findByIdAndUpdate(objectId, { isDeleted: true }, { new: true })
        .exec();
    } catch (error) {
      this.logger.error(`Error deleting Form with id ${id}`, error.message);
      throw new RepositoryException(
        `Failed to delete Form with id ${id}`,
        error,
      );
    }
  }

  /**
   * Updates a form by adding a template ID to the templates array.
   * @param formId - The ID of the form to update.
   * @param templateId - The ID of the template to add.
   * @returns A promise that resolves to the updated form.
   * @throws RepositoryException if the update fails.
   */
  async updateFormTemplates(
    formId: string,
    templateId: string,
  ): Promise<IForm> {
    try {
      this.logger.log(
        `Updating Form ${formId} to include template ${templateId}`,
      );
      const updatedForm = await this.formModel
        .findByIdAndUpdate(
          formId,
          { $addToSet: { templates: templateId } },
          { new: true, runValidators: true },
        )
        .exec();

      if (!updatedForm) {
        throw new NotFoundError(`Form with ID ${formId} not found.`);
      }

      this.logger.log(
        `Form with ID ${formId} updated successfully, template ${templateId} added.`,
      );
      return updatedForm;
    } catch (error) {
      this.logger.error(
        `Error updating Form ${formId} with template ${templateId}`,
        error.message,
      );
      throw new RepositoryException(
        `Failed to update Form with ID ${formId}`,
        error,
      );
    }
  }

  /**
   * Detaches a specified template from a form by its ID.
   * @param formId - The ID of the form from which the template will be detached.
   * @param templateId - The ID of the template to be detached from the form.
   * @returns A promise that resolves to the updated form if successful.
   * @throws RepositoryException if the detachment fails.
   */
  async detachTemplateFromFormById(
    formId: string,
    templateId: string,
  ): Promise<IForm> {
    try {
      this.logger.log(`Detaching template ${templateId} from form ${formId}`);
      const updatedForm = await this.formModel
        .findByIdAndUpdate(
          formId,
          { $pull: { templates: templateId } },
          { new: true, runValidators: true },
        )
        .exec();

      if (!updatedForm) {
        throw new NotFoundError(`Form with ID ${formId} not found.`);
      }

      this.logger.log(
        `Template ${templateId} detached from form ${formId} successfully.`,
      );
      return updatedForm;
    } catch (error) {
      this.logger.error(
        `Error detaching template from form ${formId}: ${error.message}`,
      );
      throw new RepositoryException(
        `Failed to detach template from form ${formId}`,
        error,
      );
    }
  }

  /**
   * Finds a form by ID and populates its templates.
   * @param formId - The ID of the form to find.
   * @returns The form with populated templates or null if not found.
   * @throws RepositoryException if the retrieval fails.
   */
  async findByIdWithTemplates(formId: string): Promise<IForm | null> {
    try {
      const form = await this.formModel
        .findById(formId)
        .populate('templates')
        .select(
          '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy',
        )
        .exec();

      if (!form) {
        this.logger.warn(`Form with ID ${formId} not found.`);
        return null;
      }

      return form;
    } catch (error) {
      this.logger.error(`Error fetching Form with ID ${formId}`, error.message);
      throw new RepositoryException(
        `Failed to find Form with ID ${formId}`,
        error,
      );
    }
  }

  /**
   * Updates a form by adding a template ID to the tabs array.
   * @param formId - The ID of the form to update.
   * @param tabId - The ID of the template to add.
   * @returns A promise that resolves to the updated form.
   * @throws RepositoryException if the update fails.
   */
  async updateFormTabs(formId: string, tabId: string): Promise<IForm> {
    try {
      this.logger.log(`Updating Form ${formId} to include tab ${tabId}`);
      const updatedForm = await this.formModel
        .findByIdAndUpdate(
          formId,
          { $addToSet: { tabs: tabId } },
          { new: true, runValidators: true },
        )
        .exec();

      if (!updatedForm) {
        throw new NotFoundError(`Form with ID ${formId} not found.`);
      }

      this.logger.log(
        `Form with ID ${formId} updated successfully, tab ${tabId} added.`,
      );
      return updatedForm;
    } catch (error) {
      this.logger.error(
        `Error updating Form ${formId} with tab ${tabId}`,
        error.message,
      );
      throw new RepositoryException(
        `Failed to update Form with ID ${formId}`,
        error,
      );
    }
  }

  /**
   * Detaches a specified tab from a form by its ID.
   * @param formId - The ID of the form from which the tab will be detached.
   * @param tabId - The ID of the tab to be detached from the form.
   * @returns A promise that resolves to the updated form if successful.
   * @throws RepositoryException if the detachment fails.
   */
  async detachTabFromFormById(formId: string, tabId: string): Promise<IForm> {
    try {
      this.logger.log(`Detaching tab ${tabId} from form ${formId}`);
      const updatedForm = await this.formModel
        .findByIdAndUpdate(
          formId,
          { $pull: { tabs: tabId } },
          { new: true, runValidators: true },
        )
        .exec();

      if (!updatedForm) {
        throw new NotFoundError(`Form with ID ${formId} not found.`);
      }

      this.logger.log(
        `Tab ${tabId} detached from form ${formId} successfully.`,
      );
      return updatedForm;
    } catch (error) {
      this.logger.error(
        `Error detaching tab from form ${formId}: ${error.message}`,
      );
      throw new RepositoryException(
        `Failed to detach tab from form ${formId}`,
        error,
      );
    }
  }

  /**
   * Updates a form by adding a template ID to the tabs array.
   * @param formId - The ID of the form to update.
   * @param fieldId - The ID of the template to add.
   * @returns A promise that resolves to the updated form.
   * @throws RepositoryException if the update fails.
   */
  async updateFormFields(formId: string, fieldId: string): Promise<IForm> {
    try {
      this.logger.log(`Updating Form ${formId} to include field ${fieldId}`);
      const updatedForm = await this.formModel
        .findByIdAndUpdate(
          formId,
          { $addToSet: { fields: fieldId } },
          { new: true, runValidators: true },
        )
        .exec();

      if (!updatedForm) {
        throw new NotFoundError(`Form with ID ${formId} not found.`);
      }

      this.logger.log(
        `Form with ID ${formId} updated successfully, field ${fieldId} added.`,
      );
      return updatedForm;
    } catch (error) {
      this.logger.error(
        `Error updating Form ${formId} with field ${fieldId}`,
        error.message,
      );
      throw new RepositoryException(
        `Failed to update Form with ID ${formId}`,
        error,
      );
    }
  }

  /**
   * Detaches a specified tab from a form by its ID.
   * @param formId - The ID of the form from which the tab will be detached.
   * @param fieldId - The ID of the tab to be detached from the form.
   * @returns A promise that resolves to the updated form if successful.
   * @throws RepositoryException if the detachment fails.
   */
  async detachFieldFromFormById(
    formId: string,
    fieldId: string,
  ): Promise<IForm> {
    try {
      this.logger.log(`Detaching field ${fieldId} from form ${formId}`);
      const updatedForm = await this.formModel
        .findByIdAndUpdate(
          formId,
          { $pull: { fields: fieldId } },
          { new: true, runValidators: true },
        )
        .exec();

      if (!updatedForm) {
        throw new NotFoundError(`Form with ID ${formId} not found.`);
      }

      this.logger.log(
        `Tab ${fieldId} detached from form ${formId} successfully.`,
      );
      return updatedForm;
    } catch (error) {
      this.logger.error(
        `Error detaching field from form ${formId}: ${error.message}`,
      );
      throw new RepositoryException(
        `Failed to detach field from form ${formId}`,
        error,
      );
    }
  }

  /**
   * Finds a single form document based on the provided form ID and form name,
   * @param {string} name - The name of the form to be retrieved.
   * @returns {Promise<IForm | null>} - A promise that resolves to the found form document
   */
  async findFormName(
    name: string,
    platformId: string,
    tenantId: string,
  ): Promise<IForm | null> {
    try {
      if (!name) {
        throw new Error('name are required to find a form');
      }

      const tab = await this.formModel
        .findOne({ name, platformId, tenantId, isDeleted: false })
        .exec();

      return tab;
    } catch (error) {
      this.logger.error(`Error finding tab by name ${name}:`, error);

      throw new RepositoryException(
        'Unable to retrieve the form at this time. Please try again later.',
        error,
      );
    }
  }
}
