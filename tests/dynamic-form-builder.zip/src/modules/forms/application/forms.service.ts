import {
  Injectable,
  NotFoundException,
  ConflictException,
  InternalServerErrorException,
  BadRequestException,
} from '@nestjs/common';
import { FormRepository } from '../infrastructure/repositories/forms.repository';
import { CreateFormDto } from './dto/create-form.dto';
import { UpdateFormDto } from './dto/update-form.dto';
import { IForm } from '../domain/forms';
import { BaseService } from '../../common/pagination/services/base.service';
import { LoggerService } from '../../../logging/error-log/logger.service';
import { AuditLogService } from '../../../logging/audit-log/audit-log.service';
import {
  AuditAction,
  AuditEntity,
} from '../../../logging/audit-log/audit-log.enums';
import { TemplatesRepository } from '../../templates/infrastructure/repositories/templates.repository';
import { FieldsRepository } from '../../fields/infrastructure/repositories/fields.repository';
import { TabsRepository } from '../../tabs/infrastructure/repositories/tabs.repository';

@Injectable()
export class FormService extends BaseService<IForm> {
  constructor(
    private readonly formRepository: FormRepository,
    private readonly logger: LoggerService,
    private readonly auditLog: AuditLogService,
    private readonly templateRepositoty: TemplatesRepository,
    private readonly fieldRepositoty: FieldsRepository,
    private readonly tabRepositoty: TabsRepository,
  ) {
    super(formRepository);
  }

  /**
   * Create a new Form.
   * @param createFormDto The DTO containing the Form data.
   * @returns The newly created Form.
   */
  async createForm(createFormDto: CreateFormDto): Promise<IForm> {
    try {
      const isUnique = await this.validateUniqueName(
        createFormDto.name,
        createFormDto.platformId,
        createFormDto.tenantId,
      );
      //this.logger.log(`Test ${isUnique}`);
      if (!isUnique) {
        this.logger.warn('Form name must be unique', {
          createFormDto,
        });
        throw new ConflictException('Form with this name already exists');
      }

      const formData: IForm = { ...createFormDto } as IForm;
      const createdForm = await this.formRepository.createForm(formData);

      // Audit Log
      await this.auditLog.logAudit({
        action: AuditAction.CREATE,
        entityName: AuditEntity.FORM,
        effectedEntityId: createdForm.id,
        newValue: formData,
      });

      this.logger.log(`Form created successfully: ${createdForm.id}`);
      return createdForm;
    } catch (error) {
      if (error instanceof ConflictException) {
        this.logger.warn('Conflict occurred while creating form', error);
        throw error;
      }
      this.logger.error('Error creating form', error.stack);
      throw new InternalServerErrorException('Failed to create form');
    }
  }

  /**
   * Get Form by ID.
   * @param id Form ID.
   * @param tenantId Tenant ID.
   * @param platformId Platform ID.
   * @returns The Form if found, otherwise throws NotFoundException.
   */
  async getFormById(
    id: string,
    tenantId: string,
    platformId: string,
    isGlobal: boolean = false,
  ): Promise<IForm> {
    const globalFields = await this.fieldRepositoty.getGlobalFields();

    const form = await this.formRepository.getFormById(
      id,
      tenantId,
      platformId,
    );
    if (!form) {
      throw this.logAndThrowNotFoundException(`Form with ID ${id} not found`);
    }

    let modifiedForm;

    if (isGlobal) {
      modifiedForm = {
        ...(form instanceof Object && form.toObject ? form.toObject() : form),
        globalFields: globalFields || [],
      };
    } else {
      modifiedForm = form;
    }

    //this.logger.log(`${JSON.stringify(modifiedForm)}`);

    this.logger.log(`Form retrieved: ${modifiedForm.id}`);
    return modifiedForm;
  }

  /**
   * Update a Form.
   * @param id Form ID.
   * @param updateFormDto DTO containing update data.
   * @param tenantId Tenant ID.
   * @param platformId Platform ID.
   * @returns The updated Form, or throws NotFoundException if not found.
   */
  async updateForm(
    id: string,
    updateFormDto: UpdateFormDto,
    tenantId: string,
    platformId: string,
  ): Promise<IForm> {
    const existingForm = await this.getFormById(id, tenantId, platformId);

    const updatedForm = await this.formRepository.updateForm(id, updateFormDto);
    if (!updatedForm) {
      throw new InternalServerErrorException(
        'Failed to update Form - returned null',
      );
    }

    if (updateFormDto.name) {
      await this.validateUniqueName(
        updateFormDto.name,
        platformId,
        tenantId,
        id,
      );
    }

    // Audit Log for Update
    await this.auditLog.logAudit({
      action: AuditAction.UPDATE,
      entityName: AuditEntity.FORM,
      effectedEntityId: updatedForm.id,
      oldValue: existingForm,
      newValue: updatedForm,
    });

    this.logger.log(`Form updated: ${updatedForm.id}`);
    return updatedForm;
  }

  /**
   * Delete a Form.
   * @param id Form ID.
   * @param tenantId Tenant ID.
   * @param platformId Platform ID.
   * @returns The deleted Form, or throws NotFoundException if not found.
   */
  async deleteForm(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<IForm | null> {
    const existingForm = await this.getFormById(id, tenantId, platformId);

    const deletedForm = await this.formRepository.deleteForm(id);
    if (!deletedForm) {
      throw new InternalServerErrorException(
        'Failed to delete Form - returned null',
      );
    }

    await this.deleteAssociatedEntities(id);

    // Audit Log for Delete
    await this.auditLog.logAudit({
      action: AuditAction.DELETE,
      entityName: AuditEntity.FORM,
      effectedEntityId: deletedForm.id,
      oldValue: existingForm,
    });

    this.logger.log(`Form deleted: ${deletedForm.id}`);
    return deletedForm;
  }

  /**
   * Get Form with Templates by ID.
   * @param formId Form ID.
   * @returns The Form with templates if found, otherwise throws NotFoundException.
   */
  async getFormWithTemplates(formId: string): Promise<IForm> {
    const form = await this.formRepository.findByIdWithTemplates(formId);

    if (!form) {
      throw this.logAndThrowNotFoundException(
        `Form with ID ${formId} not found`,
      );
    }

    return form;
  }

  private logAndThrowNotFoundException(message: string): never {
    this.logger.warn(message);
    throw new NotFoundException(message);
  }

  /**
   * Validates that the provided form name is unique for the specified form ID.
   *
   * This function checks if a form with the same name already exists for the
   * given form ID. If an existing Field is found and it's not the current Field
   *
   * @param {string} name - The Field name to validate for uniqueness.
   * @param {string} [currentFieldId] - Optional. The ID of the current Field, used during update operations.
   * @returns {Promise<void>} - Resolves successfully if the name is uniq
   */
  async validateUniqueName(
    name: string,
    platformId: string,
    tenantId: string,
    currentFieldId?: string,
  ): Promise<boolean> {
    if (!name) {
      throw new BadRequestException('Name are required.');
    }

    try {
      const existingForm = await this.formRepository.findFormName(
        name,
        platformId,
        tenantId,
      );

      if (
        existingForm &&
        (!currentFieldId || existingForm._id.toString() !== currentFieldId)
      ) {
        this.logger.log(`Form name conflict detected: ${name}`);
        return false;
      }

      return true;
    } catch (error) {
      this.logger.error(
        `Error during Form name validation for name ${name}:`,
        error,
      );
      throw new BadRequestException(
        'Unable to validate the Template name at this time. Please try again later.',
      );
    }
  }

  /**
   * Deletes associated tabs, fields, and templates by form ID.
   * @param formId The ID of the form.
   */
  async deleteAssociatedEntities(formId: string): Promise<void> {
    try {
      // Delete tabs
      await this.tabRepositoty.deleteByFormId(formId);

      // Delete fields
      await this.fieldRepositoty.deleteByFormId(formId);

      // Delete templates
      await this.templateRepositoty.deleteByFormId(formId);

      this.logger.log(
        `Associated tabs, fields, and templates deleted successfully for form: ${formId}`,
      );
    } catch (error) {
      this.logger.error(
        `Failed to delete associated entities for form: ${formId}, Error: ${error.message}`,
      );
      throw new Error(`Deletion failed: ${error.message}`);
    }
  }
}
