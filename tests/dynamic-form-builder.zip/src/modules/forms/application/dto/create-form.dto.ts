import {
  IsNotEmpty,
  IsString,
  IsEnum,
  IsOptional,
  Length,
  MaxLength,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import DOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';
import { Status } from '../../../../shared/utils/status.enum';

const dom = new JSDOM();
const purify = DOMPurify(dom.window);

export class CreateFormDto {
  @IsNotEmpty()
  @IsString()
  @Length(3, 256)
  @ApiProperty({ example: 'Sales' })
  @Transform(({ value }) => purify.sanitize(value))
  name: string;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  @ApiProperty({
    example: 'Sales Order Form',
  })
  @Transform(({ value }) => purify.sanitize(value))
  description: string;

  @IsEnum(Status)
  @ApiProperty({
    enum: Status,
    example: Status.ACTIVE,
  })
  status: Status;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'user123',
    description: 'The ID of the user who created the form.',
  })
  createdBy?: string;

  @IsOptional()
  @IsString()
  updatedBy?: string;

  @IsNotEmpty()
  @IsString()
  tenantId: string;

  @IsNotEmpty()
  @IsString()
  platformId: string;
}
