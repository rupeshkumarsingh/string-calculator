import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  HttpCode,
  HttpStatus,
  NotFoundException,
  Query,
  BadRequestException,
  ConflictException,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBody,
  ApiParam,
  ApiQuery,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { CreateFormDto } from './dto/create-form.dto';
import { UpdateFormDto } from './dto/update-form.dto';
import { IForm } from '../domain/forms';
import { PaginationDto } from '../../common/pagination/dto/pagination.dto';
import { FormService } from './forms.service';
import { LoggerService } from '../../../logging/error-log/logger.service';

@ApiTags('Forms')
@Controller('forms')
@ApiBearerAuth('Authorization')
@ApiBearerAuth('x-api-key')
export class FormController {
  constructor(
    private readonly formService: FormService,
    private readonly logger: LoggerService,
  ) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create a new form' })
  @ApiBody({ type: CreateFormDto })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Form successfully created.',
  })
  @ApiResponse({
    status: HttpStatus.CONFLICT,
    description: 'Duplicate Form.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid request payload.',
  })
  async createForm(@Body() createFormDto: CreateFormDto): Promise<IForm> {
    this.logger.log('Creating new form', { createFormDto });
    try {
      const form = await this.formService.createForm(createFormDto);
      this.logger.log('Form created successfully', { form });
      return form;
    } catch (error) {
      if (error instanceof ConflictException) {
        this.logger.warn('Conflict occurred while creating form', error);
        throw error;
      }
      this.logger.error('Error creating form', error);
      throw new BadRequestException('Failed to create form');
    }
  }

  @Get(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Get a form by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the Form',
    type: String,
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Form successfully retrieved.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Form not found.',
  })
  async getFormById(
    @Param('id') id: string,
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<IForm> {
    this.logger.log(`Fetching form with ID: ${id}`);
    const isGlobal = true;
    const form = await this.formService.getFormById(
      id,
      body.tenantId,
      body.platformId,
      isGlobal,
    );
    if (!form) {
      this.logger.warn(`Form with ID ${id} not found`);
      throw new NotFoundException(`Form with ID ${id} not found`);
    }
    this.logger.log(`Form with ID ${id} retrieved successfully`, { form });
    return form;
  }

  @Get()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Get all forms with optional pagination and sorting',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    description: 'Page number for pagination.',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Number of items per page.',
    example: 10,
  })
  @ApiQuery({
    name: 'sortBy',
    required: false,
    description: 'Field to sort by.',
    example: 'name',
  })
  @ApiQuery({
    name: 'sortOrder',
    required: false,
    description: 'Sort order: "asc" or "desc".',
    example: 'asc',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'List of Forms retrieved successfully.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid pagination or sorting parameters.',
  })
  async getAllForms(
    @Query() query: PaginationDto = {},
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<unknown> {
    this.logger.log('Fetching all forms', { query });
    try {
      const includeDeleted = query.includeDeleted ?? false;
      const forms = await this.formService.findAllPaginated(
        query,
        includeDeleted,
        body.tenantId,
        body.platformId,
      );
      this.logger.log('Forms retrieved successfully', { forms });
      return forms;
    } catch (error) {
      this.logger.error('Error fetching forms', error);
      throw new BadRequestException('Invalid query parameters');
    }
  }

  @Put(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Update a form by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the form to be updated',
    type: String,
  })
  @ApiBody({ type: UpdateFormDto })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Form successfully updated.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Form not found.',
  })
  async updateForm(
    @Param('id') id: string,
    @Body() updateFormDto: UpdateFormDto,
  ): Promise<IForm> {
    this.logger.log(`Updating form with ID: ${id}`, { updateFormDto });

    const tenantId = updateFormDto.tenantId || 'defaultTenantId';
    const platformId = updateFormDto.platformId || 'defaultPlatformId';
    const updatedForm = await this.formService.updateForm(
      id,
      updateFormDto,
      tenantId,
      platformId,
    );
    if (!updatedForm) {
      this.logger.warn(`Form with ID ${id} not found for update`);
      throw new NotFoundException(`Form with ID ${id} not found`);
    }
    this.logger.log(`Form with ID ${id} updated successfully`, { updatedForm });
    return updatedForm;
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete a form by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the form to be deleted',
    type: String,
  })
  @ApiResponse({
    status: HttpStatus.NO_CONTENT,
    description: 'Form successfully deleted.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Form not found.',
  })
  async deleteForm(
    @Param('id') id: string,
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<void> {
    this.logger.log(`Deleting form with ID: ${id}`);
    const result = await this.formService.deleteForm(
      id,
      body.tenantId,
      body.platformId,
    );
    if (!result) {
      this.logger.warn(`Form with ID ${id} not found for deletion`);
      throw new NotFoundException(`Form with ID ${id} not found`);
    }
    this.logger.log(`Form with ID ${id} deleted successfully`);
  }

  @Get(':id/templates')
  @ApiOperation({ summary: 'Get all templates for a form' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Templates retrieved successfully.',
  })
  @ApiResponse({ status: HttpStatus.NOT_FOUND, description: 'Form not found.' })
  async getTemplatesByFormId(@Param('id') formId: string): Promise<IForm> {
    try {
      const templates = await this.formService.getFormWithTemplates(formId);
      if (!templates) {
        throw new NotFoundException(`Form with ID ${formId} not found`);
      }

      return templates;
    } catch (error) {
      // Log the error with the correct message
      this.logger.error(
        `Error fetching templates for form with ID: ${formId}`,
        error,
      );
      throw new BadRequestException(error?.message);
    }
  }
}
