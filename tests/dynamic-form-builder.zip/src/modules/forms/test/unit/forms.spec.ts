import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import mongoose from 'mongoose';
import { FormModel } from '../../infrastructure/schema/forms.schema';
import databaseConfig from '../../../../database/config/database.config';
import { DatabaseModule } from '../../../../database/database.module';

describe('Form Model and Schema', () => {
  let module: TestingModule;

  beforeAll(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          load: [databaseConfig],
          envFilePath: '.env',
          isGlobal: true,
        }),
        DatabaseModule,
      ],
    }).compile();
  });

  afterAll(async () => {
    //await mongoose.connection.close();
    module.close();
  });

  beforeEach(async () => {
    //await FormModel.deleteMany({});
  });

  // it('should create a form with valid data', async () => {
  //   const formData = {
  //     name: 'Sample Form',
  //     description: 'This is a test form',
  //     status: 'active',
  //     createdBy: 'user123',
  //     updatedBy: 'user123',
  //   };

  //   const form = new FormModel(formData);
  //   const savedForm = await form.save();

  //   expect(savedForm._id).toBeDefined();
  //   expect(savedForm.name).toEqual(formData.name);
  //   expect(savedForm.description).toEqual(formData.description);
  //   expect(savedForm.status).toEqual('active');
  //   expect(savedForm.createdBy).toEqual('user123');
  //   expect(savedForm.createdAt).toBeInstanceOf(Date);
  // });

  it('should throw an error if name is missing', async () => {
    const formData = {
      description: 'Form without a name',
      status: 'active',
    };

    const form = new FormModel(formData);
    await expect(form.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });

  it('should throw an error if description is missing', async () => {
    const formData = {
      name: 'Form without description',
      status: 'active',
    };

    const form = new FormModel(formData);
    await expect(form.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });

  it('should throw an error if status is invalid', async () => {
    const formData = {
      name: 'Invalid Status Form',
      description: 'This form has an invalid status',
      status: 'invalid_status', // Invalid status not in enum
    };

    const form = new FormModel(formData);
    await expect(form.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });

  // it('should throw an error if a duplicate name is used', async () => {
  //   const formData = {
  //     name: 'Duplicate Form',
  //     description: 'This is the first form',
  //   };

  //   const form1 = new FormModel(formData);
  //   await form1.save();

  //   const form2 = new FormModel(formData);
  //   await expect(form2.save()).rejects.toThrowError(mongoose.Error);
  // });
});
