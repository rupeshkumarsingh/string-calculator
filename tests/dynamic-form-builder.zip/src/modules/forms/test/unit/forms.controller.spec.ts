import { Test, TestingModule } from '@nestjs/testing';
import {
  existingForm,
  validFormDto,
  nonExistentFormId,
} from '../fixtures/form-fixtures';
import {
  BadRequestException,
  ConflictException,
  NotFoundException,
} from '@nestjs/common';
import { FormController } from '../../application/forms.controller';
import { FormService } from '../../application/forms.service';
import { CreateFormDto } from '../../application/dto/create-form.dto';
import { UpdateFormDto } from '../../application/dto/update-form.dto';
import { PaginatedResult } from '../../../common/pagination/interfaces/paginated-result.interface';
import { PaginationDto } from '../../../common/pagination/dto/pagination.dto';
import { LoggerService } from '../../../../logging/error-log/logger.service';

describe('FormController', () => {
  let controller: FormController;
  let service: FormService;
  const mockPaginatedResult: PaginatedResult<unknown> = {
    items: [], // Simulate empty results for the test
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  };
  const mockFormService = {
    createForm: jest.fn(),
    getFormById: jest.fn(),
    getAllForms: jest.fn(),
    updateForm: jest.fn(),
    deleteForm: jest.fn(),
    findAllPaginated: jest.fn().mockResolvedValue(mockPaginatedResult),
    getFormWithTemplates: jest.fn(),
  };

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const tenantId = '6708eaf5ab7b16c964098737';
  const platformId = '6708eaee1f18d52405c72f88';

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [FormController],
      providers: [
        { provide: FormService, useValue: mockFormService },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    controller = module.get<FormController>(FormController);
    service = module.get<FormService>(FormService);
  });

  describe('createForm', () => {
    it('should create and return a form successfully', async () => {
      mockFormService.createForm.mockResolvedValue(existingForm);

      const result = await controller.createForm(validFormDto as CreateFormDto);
      expect(result).toEqual(existingForm);
      expect(service.createForm).toHaveBeenCalledWith(validFormDto);
    });

    it('should throw ConflictException if a conflict occurs while creating a form', async () => {
      const mockError = new ConflictException('Conflict error');
      mockFormService.createForm.mockRejectedValue(mockError);

      await expect(
        controller.createForm(validFormDto as CreateFormDto),
      ).rejects.toThrowError(new ConflictException('Conflict error'));

      // Check that logger.warn was called with the expected parameters
      expect(mockLoggerService.warn).toHaveBeenCalledWith(
        'Conflict occurred while creating form',
        mockError,
      );
    });
    it('should handle database errors and throw BadRequestException', async () => {
      const mockError = new Error('Database error');
      mockFormService.createForm.mockRejectedValue(mockError);

      await expect(
        controller.createForm(validFormDto as CreateFormDto),
      ).rejects.toThrowError(new BadRequestException('Failed to create form'));
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        'Error creating form',
        mockError,
      );
    });
  });

  describe('getFormById', () => {
    it('should return a form by id', async () => {
      const id = '66f529997383a45da1867131';
      mockFormService.getFormById.mockResolvedValue(existingForm);

      const result = await controller.getFormById(id, { tenantId, platformId });
      expect(result).toEqual(existingForm);
      expect(service.getFormById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
        true,
      );
    });

    it('should throw NotFoundException if form not found', async () => {
      const id = nonExistentFormId;
      mockFormService.getFormById.mockResolvedValue(null);

      await expect(
        controller.getFormById(id, { tenantId, platformId }),
      ).rejects.toThrow(new NotFoundException(`Form with ID ${id} not found`));
    });
  });

  describe('getAllForms', () => {
    it('should be defined', () => {
      expect(controller).toBeDefined();
    });
    it('should call FormService.findAllPaginated and return result', async () => {
      const query: PaginationDto = { page: 1, limit: 10 };

      const result = await controller.getAllForms(query, {
        tenantId,
        platformId,
      });

      expect(service.findAllPaginated).toHaveBeenCalledWith(
        query,
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should call FormService.findAllPaginated with default query if none provided', async () => {
      const defaultQuery: PaginationDto = {};

      const result = await controller.getAllForms(undefined, {
        tenantId,
        platformId,
      });

      expect(service.findAllPaginated).toHaveBeenCalledWith(
        defaultQuery,
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should pass includeDeleted as true when query.includeDeleted is true', async () => {
      const query: PaginationDto = { page: 1, limit: 10, includeDeleted: true };

      await controller.getAllForms(query, { tenantId, platformId });

      expect(service.findAllPaginated).toHaveBeenCalledWith(
        query,
        true,
        tenantId,
        platformId,
      );
    });

    it('should handle service failure and throw BadRequestException', async () => {
      const mockError = new Error('Database error');
      mockFormService.findAllPaginated.mockRejectedValue(mockError);

      await expect(
        controller.getAllForms(
          { page: 1, limit: 10 },
          { tenantId, platformId },
        ),
      ).rejects.toThrow(new BadRequestException('Invalid query parameters'));

      expect(mockLoggerService.error).toHaveBeenCalledWith(
        'Error fetching forms',
        mockError,
      );
    });
  });

  describe('updateForm', () => {
    it('should update and return the form', async () => {
      const id = '66f529997383a45da1867131';
      const updateDto = {
        title: 'Updated form',
        tenantId,
        platformId,
      } as UpdateFormDto;

      mockFormService.updateForm.mockResolvedValue({
        ...existingForm,
        title: 'Updated form',
      });

      const result = await controller.updateForm(id, updateDto);
      expect(result).toEqual({
        ...existingForm,
        title: 'Updated form',
      });
      expect(service.updateForm).toHaveBeenCalledWith(
        id,
        updateDto,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if form to update is not found', async () => {
      const id = nonExistentFormId;
      const updateDto = { title: 'Updated form' } as UpdateFormDto;

      mockFormService.updateForm.mockResolvedValue(null);

      await expect(controller.updateForm(id, updateDto)).rejects.toThrow(
        new NotFoundException(`Form with ID ${id} not found`),
      );
    });
  });

  describe('deleteForm', () => {
    it('should delete the form', async () => {
      const id = '66f529997383a45da1867131';
      mockFormService.deleteForm.mockResolvedValue(existingForm);

      await controller.deleteForm(id, { tenantId, platformId });
      expect(service.deleteForm).toHaveBeenCalledWith(id, tenantId, platformId);
    });

    it('should throw NotFoundException if form to delete is not found', async () => {
      const id = nonExistentFormId;

      mockFormService.deleteForm.mockResolvedValue(null);

      await expect(
        controller.deleteForm(id, { tenantId, platformId }),
      ).rejects.toThrow(new NotFoundException(`Form with ID ${id} not found`));
    });
  });

  describe('getTemplatesByFormId', () => {
    it('should return templates for a valid form ID', async () => {
      const formId = 'validFormId';
      const mockTemplates = [{ id: 'template1', name: 'Template 1' }];
      mockFormService.getFormWithTemplates.mockResolvedValue(mockTemplates);

      const result = await controller.getTemplatesByFormId(formId);
      expect(result).toEqual(mockTemplates);
      expect(service.getFormWithTemplates).toHaveBeenCalledWith(formId);
    });

    it('should throw NotFoundException if form with templates is not found', async () => {
      const formId = 'nonExistentFormId';
      mockFormService.getFormWithTemplates.mockResolvedValue(null);

      await expect(controller.getTemplatesByFormId(formId)).rejects.toThrow(
        new NotFoundException(`Form with ID ${formId} not found`),
      );

      expect(mockLoggerService.error).toHaveBeenCalledWith(
        `Error fetching templates for form with ID: ${formId}`,
        expect.any(Error),
      );
    });

    it('should handle service failure and throw BadRequestException', async () => {
      const formId = 'someFormId';
      const mockError = new Error('Database error');
      mockFormService.getFormWithTemplates.mockRejectedValue(mockError);

      await expect(controller.getTemplatesByFormId(formId)).rejects.toThrow(
        new BadRequestException('Database error'),
      );

      expect(mockLoggerService.error).toHaveBeenCalledWith(
        'Error fetching templates for form with ID: someFormId',
        mockError,
      );
    });
  });
});
