import { Test, TestingModule } from '@nestjs/testing';
import {
  BadRequestException,
  ConflictException,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { FormService } from '../../application/forms.service';
import { FormRepository } from '../../infrastructure/repositories/forms.repository';
import {
  validFormDto,
  newFormDto,
  updatedFormDto,
  nonExistentFormId,
  existingForm,
} from '../fixtures/form-fixtures';
import { PaginatedResult } from '../../../common/pagination/interfaces/paginated-result.interface';
import { IForm } from '../../domain/forms';
import { PaginationDto } from '../../../common/pagination/dto/pagination.dto';
import { LoggerService } from '../../../../logging/error-log/logger.service';
import { AuditLogService } from '../../../../logging/audit-log/audit-log.service';
import { TemplatesRepository } from '../../../templates/infrastructure/repositories/templates.repository';
import { FieldsRepository } from '../../../fields/infrastructure/repositories/fields.repository';
import { TabsRepository } from '../../../tabs/infrastructure/repositories/tabs.repository';

describe('FormService', () => {
  let service: FormService;
  let repository: FormRepository;
  let templateRepository: TemplatesRepository;
  let fieldRepository: FieldsRepository;
  let tabRepository: TabsRepository;

  const mockPaginatedResult: PaginatedResult<IForm> = {
    items: [],
    total: 0,
    page: 1,
    limit: 100,
    totalPages: 0,
  };
  const mockFormRepository = {
    createForm: jest.fn(),
    getFormById: jest.fn(),
    findAllPaginated: jest.fn().mockResolvedValue(mockPaginatedResult),
    updateForm: jest.fn(),
    deleteForm: jest.fn(),
    findFormName: jest.fn(),
    findByIdWithTemplates: jest.fn(),
    getFormWithTemplates: jest.fn(),
    deleteAssociatedEntities: jest.fn(),
  };

  const mockFieldRepository = {
    getGlobalFields: jest.fn(),
    deleteByFormId: jest.fn(),
  };

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const mockAuditLogService = {
    logAudit: jest.fn(),
  };

  const tenantId = '6708eaf5ab7b16c964098737';
  const platformId = '6708eaee1f18d52405c72f88';
  const formId = '671204aeab8c1acc0100e7eb';

  const globalFields = [{ field: 'example', type: 'text' }];

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        FormService,
        { provide: FormRepository, useValue: mockFormRepository },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
        {
          provide: AuditLogService,
          useValue: mockAuditLogService,
        },
        {
          provide: TabsRepository,
          useValue: {
            deleteByFormId: jest.fn(),
          },
        },
        {
          provide: FieldsRepository,
          useValue: mockFieldRepository,
        },
        {
          provide: TemplatesRepository,
          useValue: {
            deleteByFormId: jest.fn(),
          },
        },
      ],
    }).compile();

    service = module.get<FormService>(FormService);
    repository = module.get<FormRepository>(FormRepository);
    templateRepository = module.get<TemplatesRepository>(TemplatesRepository);
    fieldRepository = module.get<FieldsRepository>(FieldsRepository);
    tabRepository = module.get<TabsRepository>(TabsRepository);
  });

  describe('createForm', () => {
    it('should create and return a Form successfully', async () => {
      mockFormRepository.findFormName.mockResolvedValue(undefined);
      mockFormRepository.createForm.mockResolvedValue(existingForm);

      const result = await service.createForm(validFormDto);

      expect(mockFormRepository.findFormName).toHaveBeenCalledWith(
        validFormDto.name,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.createForm).toHaveBeenCalledWith(
        expect.objectContaining(validFormDto),
      );

      expect(result).toEqual(existingForm);
    });

    it('should throw BadRequestException on validation failure', async () => {
      mockFormRepository.findFormName.mockResolvedValue(undefined);
      mockFormRepository.createForm.mockRejectedValue(
        new Error('validation failed'),
      );

      await expect(service.createForm(validFormDto)).rejects.toThrow(
        InternalServerErrorException,
      );
      expect(mockLoggerService.error).toHaveBeenCalled();
    });

    it('should throw ConflictException for duplicate Form name', async () => {
      mockFormRepository.createForm.mockResolvedValue(undefined);
      mockFormRepository.findFormName.mockResolvedValue(validFormDto);

      await expect(service.createForm(validFormDto)).rejects.toThrow(
        ConflictException,
      );
      expect(mockLoggerService.warn).toHaveBeenCalledWith(
        'Form name must be unique',
        { createFormDto: validFormDto },
      );
    });

    it('should create and return a new Form with new values', async () => {
      mockFormRepository.createForm.mockResolvedValue(newFormDto);
      mockFormRepository.findFormName.mockResolvedValue(undefined);

      const result = await service.createForm(newFormDto);

      expect(result).toEqual(newFormDto);
    });

    it('should throw InternalServerErrorException on unexpected errors during form creation', async () => {
      mockFormRepository.createForm.mockRejectedValue(
        new Error('Database error'),
      );
      mockFormRepository.findFormName.mockResolvedValue(undefined);

      await expect(service.createForm(validFormDto)).rejects.toThrow(
        InternalServerErrorException,
      );
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        'Error creating form',
        expect.any(String),
      );
    });

    it('should log audit when a form is created successfully', async () => {
      mockFormRepository.findFormName.mockResolvedValue(undefined);
      mockFormRepository.createForm.mockResolvedValue(existingForm);

      await service.createForm(validFormDto);
    });
  });

  describe('getFormById', () => {
    it('should return a Form successfully with globalFields when isGlobal is true', async () => {
      const id = '66ebcb8f570e341a486525cd';

      const existingForm = {
        id: '66ebcb8f570e341a486525cd',
        name: 'Test Form',
      };
      const globalFields = [{ fieldName: 'global1' }, { fieldName: 'global2' }];

      mockFormRepository.getFormById.mockResolvedValue(existingForm);
      mockFieldRepository.getGlobalFields.mockResolvedValue(globalFields);

      const result = await service.getFormById(id, tenantId, platformId, true);
      expect(result).toEqual({
        ...existingForm,
        globalFields,
      });
      expect(mockFormRepository.getFormById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFieldRepository.getGlobalFields).toHaveBeenCalled();
    });
    it('should return a Form successfully without globalFields when isGlobal is false', async () => {
      const id = '66ebcb8f570e341a486525cd';
      mockFormRepository.getFormById.mockResolvedValue(existingForm);
      mockFieldRepository.getGlobalFields.mockResolvedValue(globalFields);

      const result = await service.getFormById(id, tenantId, platformId, false);
      expect(result).toEqual(existingForm);
      expect(mockFormRepository.getFormById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFieldRepository.getGlobalFields).toHaveBeenCalled();
    });

    it('should throw NotFoundException if Form not found', async () => {
      const id = 'non-existent-id';
      mockFormRepository.getFormById.mockResolvedValue(null);

      await expect(
        service.getFormById(id, tenantId, platformId),
      ).rejects.toThrow(new NotFoundException(`Form with ID ${id} not found`));
      expect(mockFormRepository.getFormById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });
  });

  describe('findAllPaginated', () => {
    it('should call repository findAllPaginated with default values', async () => {
      const paginationQuery: PaginationDto = {};
      await service.findAllPaginated(
        paginationQuery,
        false,
        tenantId,
        platformId,
      );

      expect(repository.findAllPaginated).toHaveBeenCalledWith(
        {},
        1,
        100,
        'createdAt',
        'asc',
        false,
        tenantId,
        platformId,
      );
    });

    it('should call repository findAllPaginated with passed values', async () => {
      const paginationQuery: PaginationDto = {
        page: 2,
        limit: 50,
        sortBy: 'title',
        sortOrder: 'desc',
        filters: { status: 'active' },
      };

      await service.findAllPaginated(
        paginationQuery,
        false,
        tenantId,
        platformId,
      );

      expect(repository.findAllPaginated).toHaveBeenCalledWith(
        { status: 'active' },
        2,
        50,
        'title',
        'desc',
        false,
        tenantId,
        platformId,
      );
    });

    it('should return the paginated result from repository', async () => {
      const result = await service.findAllPaginated(
        {},
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should handle errors from the repository', async () => {
      const error = new Error('Repository error');
      mockFormRepository.findAllPaginated.mockRejectedValueOnce(error);

      await expect(
        service.findAllPaginated({}, false, tenantId, platformId),
      ).rejects.toThrow('Repository error');
    });
  });

  describe('updateForm', () => {
    it('should update and return the Form successfully', async () => {
      const id = '66ebcb8f570e341a486525cd';
      const updateDto = updatedFormDto;
      const updatedForm = { ...existingForm, ...updateDto };

      mockFormRepository.getFormById.mockResolvedValue(existingForm);
      mockFormRepository.updateForm.mockResolvedValue(updatedForm);

      const result = await service.updateForm(
        id,
        updateDto,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.getFormById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.updateForm).toHaveBeenCalledWith(id, updateDto);
      expect(result).toEqual({ ...existingForm, ...updateDto });
    });

    it('should throw NotFoundException if Form to update is not found', async () => {
      mockFormRepository.getFormById.mockResolvedValueOnce(null);

      await expect(
        service.updateForm(
          nonExistentFormId,
          updatedFormDto,
          tenantId,
          platformId,
        ),
      ).rejects.toThrow(NotFoundException);

      expect(mockFormRepository.updateForm).toHaveBeenCalled();
    });

    it('should throw InternalServerErrorException if update returns null', async () => {
      // Arrange: Mock the repository methods
      mockFormRepository.getFormById.mockResolvedValue(existingForm);
      mockFormRepository.updateForm.mockResolvedValue(null);
      await expect(
        service.updateForm(
          existingForm.id,
          updatedFormDto,
          tenantId,
          platformId,
        ),
      ).rejects.toThrow(InternalServerErrorException);
      expect(mockFormRepository.getFormById).toHaveBeenCalledWith(
        existingForm.id,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.updateForm).toHaveBeenCalledWith(
        existingForm.id,
        updatedFormDto,
      );
    });
  });
  describe('deleteForm', () => {
    it('should delete the Form successfully', async () => {
      const id = existingForm._id;
      mockFormRepository.getFormById.mockResolvedValueOnce(existingForm);
      mockFormRepository.deleteForm.mockResolvedValueOnce(existingForm);
      const result = await service.deleteForm(id, tenantId, platformId);
      expect(result).toEqual(existingForm);
      expect(mockFormRepository.getFormById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.deleteForm).toHaveBeenCalledWith(id);
      //expect(service.deleteAssociatedEntities).toHaveBeenCalledWith(id);
    });
    it('should throw NotFoundException if Form to delete is not found', async () => {
      const id = nonExistentFormId;
      mockFormRepository.getFormById.mockResolvedValueOnce(null);

      await expect(
        service.deleteForm(id, tenantId, platformId),
      ).rejects.toThrow(new NotFoundException(`Form with ID ${id} not found`));
      expect(mockFormRepository.getFormById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.deleteForm).toHaveBeenCalled();
    });
    it('should throw NotFoundException if form with the given ID does not exist', async () => {
      mockFormRepository.getFormById.mockResolvedValue(null); // Form does not exist

      await expect(
        service.deleteForm(formId, tenantId, platformId),
      ).rejects.toThrow(
        new NotFoundException(`Form with ID ${formId} not found`),
      );
    });

    it('should throw InternalServerErrorException if deletion fails', async () => {
      const id = existingForm._id;
      mockFormRepository.getFormById.mockResolvedValueOnce(existingForm);
      mockFormRepository.deleteForm.mockResolvedValueOnce(null);

      await expect(
        service.deleteForm(id, tenantId, platformId),
      ).rejects.toThrow(
        new InternalServerErrorException(
          'Failed to delete Form - returned null',
        ),
      );

      expect(mockFormRepository.getFormById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.deleteForm).toHaveBeenCalledWith(id);
      expect(
        mockFormRepository.deleteAssociatedEntities,
      ).not.toHaveBeenCalled();
    });
  });

  describe('deleteAssociatedEntities', () => {
    it('should delete associated tabs, fields, and templates successfully', async () => {
      // Mock successful deletion
      tabRepository.deleteByFormId = jest.fn().mockResolvedValue(undefined);
      fieldRepository.deleteByFormId = jest.fn().mockResolvedValue(undefined);
      templateRepository.deleteByFormId = jest
        .fn()
        .mockResolvedValue(undefined);

      await service['deleteAssociatedEntities'](formId);

      // Assertions
      expect(tabRepository.deleteByFormId).toHaveBeenCalledWith(formId);
      expect(fieldRepository.deleteByFormId).toHaveBeenCalledWith(formId);
      expect(templateRepository.deleteByFormId).toHaveBeenCalledWith(formId);
    });

    it('should log an error and throw an error if deletion of tabs fails', async () => {
      const errorMessage = 'Failed to delete tabs';
      tabRepository.deleteByFormId = jest
        .fn()
        .mockRejectedValue(new Error(errorMessage));
      fieldRepository.deleteByFormId = jest.fn().mockResolvedValue(undefined);
      templateRepository.deleteByFormId = jest
        .fn()
        .mockResolvedValue(undefined);

      // Spy on the logger
      const loggerSpy = jest.spyOn(service['logger'], 'error');

      await expect(service['deleteAssociatedEntities'](formId)).rejects.toThrow(
        Error,
      );
      expect(loggerSpy).toHaveBeenCalledWith(
        expect.stringContaining(
          `Failed to delete associated entities for form: ${formId}, Error: ${errorMessage}`,
        ),
      );
    });

    it('should log an error and throw an error if deletion of fields fails', async () => {
      const errorMessage = 'Failed to delete fields';
      tabRepository.deleteByFormId = jest.fn().mockResolvedValue(undefined);
      fieldRepository.deleteByFormId = jest
        .fn()
        .mockRejectedValue(new Error(errorMessage));
      templateRepository.deleteByFormId = jest
        .fn()
        .mockResolvedValue(undefined);

      const loggerSpy = jest.spyOn(service['logger'], 'error');

      await expect(service['deleteAssociatedEntities'](formId)).rejects.toThrow(
        Error,
      );
      expect(loggerSpy).toHaveBeenCalledWith(
        expect.stringContaining(
          `Failed to delete associated entities for form: ${formId}, Error: ${errorMessage}`,
        ),
      );
    });

    it('should log an error and throw an error if deletion of templates fails', async () => {
      const errorMessage = 'Failed to delete templates';
      tabRepository.deleteByFormId = jest.fn().mockResolvedValue(undefined);
      fieldRepository.deleteByFormId = jest.fn().mockResolvedValue(undefined);
      templateRepository.deleteByFormId = jest
        .fn()
        .mockRejectedValue(new Error(errorMessage));

      const loggerSpy = jest.spyOn(service['logger'], 'error');

      await expect(service['deleteAssociatedEntities'](formId)).rejects.toThrow(
        Error,
      );
      expect(loggerSpy).toHaveBeenCalledWith(
        expect.stringContaining(
          `Failed to delete associated entities for form: ${formId}, Error: ${errorMessage}`,
        ),
      );
    });
  });

  describe('getFormWithTemplates', () => {
    it('should return a Form with associated templates', async () => {
      const formId = '66ebcb8f570e341a486525cd';
      const mockForm = { id: formId, templates: [] };

      mockFormRepository.findByIdWithTemplates.mockResolvedValue(mockForm);

      const result = await service.getFormWithTemplates(formId);

      expect(result).toEqual(mockForm);

      expect(mockFormRepository.findByIdWithTemplates).toHaveBeenCalledWith(
        formId,
      );
    });

    it('should throw NotFoundException if Form with templates is not found', async () => {
      const formId = 'non-existent-id';

      mockFormRepository.findByIdWithTemplates.mockResolvedValue(null);

      await expect(service.getFormWithTemplates(formId)).rejects.toThrowError(
        new NotFoundException(`Form with ID ${formId} not found`),
      );

      expect(mockFormRepository.findByIdWithTemplates).toHaveBeenCalledWith(
        formId,
      );
    });
  });

  describe('validateUniqueName', () => {
    it('should log an error and throw BadRequestException if an error occurs during validation', async () => {
      mockFormRepository.findFormName.mockRejectedValue(
        new Error('Database error'),
      );

      await expect(
        service.validateUniqueName('formName', platformId, tenantId),
      ).rejects.toThrow(BadRequestException);

      expect(mockLoggerService.error).toHaveBeenCalledWith(
        'Error during Form name validation for name formName:',
        expect.any(Error),
      );
    });

    it('should throw BadRequestException if name is empty or undefined', async () => {
      await expect(
        service.validateUniqueName('', platformId, tenantId),
      ).rejects.toThrow(new BadRequestException('Name are required.'));

      await expect(
        service.validateUniqueName('', platformId, tenantId),
      ).rejects.toThrow(new BadRequestException('Name are required.'));
    });

    it('should detect a form name conflict and return false', async () => {
      const name = 'existingFormName';
      const existingForm = { _id: 'existingFormId' };
      const currentFieldId = undefined;

      mockFormRepository.findFormName.mockResolvedValueOnce(existingForm);

      const result = await service.validateUniqueName(
        name,
        platformId,
        tenantId,
        currentFieldId,
      );

      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Form name conflict detected: ${name}`,
      );
      expect(result).toBe(false);
    });

    it('should not detect a form name conflict if currentFieldId matches existing form', async () => {
      const name = 'existingFormName';
      const existingForm = { _id: 'existingFormId' };
      const currentFieldId = 'existingFormId';

      mockFormRepository.findFormName.mockResolvedValueOnce(existingForm);

      const result = await service.validateUniqueName(
        name,
        platformId,
        tenantId,
        currentFieldId,
      );

      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Form name conflict detected: ${name}`,
      );
      expect(result).toBe(true);
    });
  });
});
