import { Test, TestingModule } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { IForm } from '../../domain/forms';
import { Model, Types } from 'mongoose';
import { FormRepository } from '../../infrastructure/repositories/forms.repository';
import { LoggerService } from '../../../../logging/error-log/logger.service';
import { RepositoryException } from '../../../../shared/exceptions/repository.exception';
import { NotFoundError } from 'rxjs';

describe('FormRepository', () => {
  let repository: FormRepository;
  let model: Model<IForm>;
  let logger: LoggerService;

  const mockFormModel = jest.fn().mockImplementation(() => ({
    save: jest.fn(),
    findById: jest.fn().mockReturnThis(),
    exec: jest.fn(),
    countDocuments: jest.fn(),
    find: jest.fn(),
    sort: jest.fn().mockReturnThis(),
    skip: jest.fn().mockReturnThis(),
    limit: jest.fn().mockReturnThis(),
    findOne: jest.fn(),
    findByIdAndUpdate: jest.fn().mockResolvedValue(null),
  }));

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const mockFormData = {
    _id: '66ea9a7bfddf3e21da0c6959',
    name: 'Sales Form',
    description: 'Sales Form',
    status: 'active',
    tenantId: '6708eaf5ab7b16c964098737',
    platformId: '6708eaee1f18d52405c72f88',
    isDeleted: false,
  } as IForm;

  const mockUpdatedForm = {
    _id: '66ea9a7bfddf3e21da0c6959',
    name: 'Sales Form',
    tabs: [],
  };

  const tenantId = '6708eaf5ab7b16c964098737';
  const platformId = '6708eaee1f18d52405c72f88';

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        FormRepository,
        {
          provide: getModelToken('Form'),
          useValue: mockFormModel,
        },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    repository = module.get<FormRepository>(FormRepository);
    model = module.get<Model<IForm>>(getModelToken('Form'));
    logger = module.get<LoggerService>(LoggerService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('createForm', () => {
    it('should create and save a new form', async () => {
      const formInstance = new mockFormModel();
      mockFormModel.mockImplementation(() => formInstance);
      formInstance.save.mockResolvedValue(mockFormData);

      const result = await repository.createForm(mockFormData);

      expect(mockFormModel).toHaveBeenCalledWith(mockFormData);
      expect(formInstance.save).toHaveBeenCalled();
      expect(result).toEqual(mockFormData);
    });

    it('should log an error and throw RepositoryException if an error occurs during form creation', async () => {
      const mockError = new Error('Database error');
      const formInstance = new mockFormModel();
      mockFormModel.mockImplementation(() => formInstance);
      formInstance.save.mockRejectedValue(mockError);

      await expect(repository.createForm(mockFormData)).rejects.toThrow(
        RepositoryException,
      );
      expect(logger.error).toHaveBeenCalledWith(
        'Error creating Form',
        mockError.message,
      );
    });
  });

  describe('getFormById', () => {
    it('should return a Form by id', async () => {
      const objectId = new Types.ObjectId(mockFormData._id);

      const execMock = jest.fn().mockResolvedValue(mockFormData);
      const selectMock = jest.fn().mockReturnValue({ exec: execMock });
      const populateMock = jest.fn().mockReturnValue({ select: selectMock });

      // Mock `findOne` to return an object that supports `populate`
      const findOneMock = jest.fn().mockReturnValue({ populate: populateMock });

      model.findOne = findOneMock;

      const result = await repository.getFormById(
        mockFormData._id,
        tenantId,
        platformId,
      );

      expect(model.findOne).toHaveBeenCalledWith({
        _id: objectId,
        tenantId,
        platformId,
        isDeleted: false,
      });
      expect(populateMock).toHaveBeenCalledWith([
        {
          path: 'fields',
          select:
            '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy',
          populate: {
            path: 'items',
            select:
              '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy -id -__v -id -formId -status -childFieldIds',
          },
        },
        {
          path: 'tabs',
          select:
            '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy',
        },
        {
          path: 'templates',
          select:
            '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy',
        },
      ]);

      expect(selectMock).toHaveBeenCalledWith(
        '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy',
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockFormData);
    });

    it('should return null and log a warning if no form is found', async () => {
      const objectId = new Types.ObjectId(mockFormData._id);

      const execMock = jest.fn().mockResolvedValue(null);
      const selectMock = jest.fn().mockReturnValue({ exec: execMock });
      const populateMock = jest.fn().mockReturnValue({ select: selectMock });

      // Mock `findOne` to return an object that supports `populate`
      const findOneMock = jest.fn().mockReturnValue({ populate: populateMock });

      model.findOne = findOneMock;

      const result = await repository.getFormById(
        mockFormData._id,
        tenantId,
        platformId,
      );

      expect(model.findOne).toHaveBeenCalledWith({
        _id: objectId,
        tenantId,
        platformId,
        isDeleted: false,
      });
      expect(logger.warn).toHaveBeenCalledWith(
        `Form with id ${mockFormData._id} not found for Tenant ID: ${tenantId} and Platform ID: ${platformId}`,
      );
      expect(result).toBeNull();
    });

    it('should throw a RepositoryException if findOne fails', async () => {
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const selectMock = jest.fn().mockReturnValue({ exec: execMock });
      const populateMock = jest.fn().mockReturnValue({ select: selectMock });
      const findOneMock = jest.fn().mockReturnValue({ populate: populateMock });

      model.findOne = findOneMock;

      await expect(
        repository.getFormById(mockFormData._id, tenantId, platformId),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error fetching Form with id ${mockFormData._id}`,
        mockError.message,
      );
    });
  });

  describe('getAllForms', () => {
    it('should be defined', () => {
      expect(repository).toBeDefined();
    });
  });

  describe('updateform', () => {
    const mockUpdateData = { name: 'Purchase Form' };

    it('should update and return the updated form', async () => {
      const mockUpdatedForm = { ...mockFormData, ...mockUpdateData };

      const execMock = jest.fn().mockResolvedValue(mockUpdatedForm);
      const findOneAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findOneAndUpdate = findOneAndUpdateMock;

      const result = await repository.updateForm(
        mockFormData._id,
        mockUpdateData,
      );

      expect(model.findOneAndUpdate).toHaveBeenCalledWith(
        new Types.ObjectId(mockFormData._id),
        mockUpdateData,
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockUpdatedForm);
    });

    it('should throw a RepositoryException if updating fails', async () => {
      const mockError = new Error('Update failed');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findOneAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findOneAndUpdate = findOneAndUpdateMock;

      await expect(
        repository.updateForm(mockFormData._id, mockUpdateData),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error updating Form with id ${mockFormData._id}`,
        mockError.message,
      );
    });
  });

  describe('deleteForm', () => {
    it('should delete and return the deleted form', async () => {
      const mockDeletedForm = { ...mockFormData, isDeleted: true };

      const execMock = jest.fn().mockResolvedValue(mockDeletedForm);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.deleteForm(mockFormData._id);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        new Types.ObjectId(mockFormData._id),
        { isDeleted: true },
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockDeletedForm);
    });

    it('should throw a RepositoryException if deletion fails', async () => {
      const mockError = new Error('Delete failed');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(repository.deleteForm(mockFormData._id)).rejects.toThrow(
        RepositoryException,
      );

      expect(logger.error).toHaveBeenCalledWith(
        `Error deleting Form with id ${mockFormData._id}`,
        mockError.message,
      );
    });
  });

  describe('updateFormTemplates', () => {
    const formId = '66ea9a7bfddf3e21da0c6959';
    const templateId = '12345';

    it('should update the form and add the template to the templates array', async () => {
      const updatedForm = {
        ...mockFormData,
        templates: [...(mockFormData.templates ?? []), templateId],
      };

      const execMock = jest.fn().mockResolvedValue(updatedForm);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.updateFormTemplates(formId, templateId);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $addToSet: { templates: templateId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(updatedForm);
      expect(logger.log).toHaveBeenCalledWith(
        `Form with ID ${formId} updated successfully, template ${templateId} added.`,
      );
    });

    it('should throw a NotFoundError if form is not found', async () => {
      const mockError = new NotFoundError(`Form with ID ${formId} not found.`);
      const execMock = jest.fn().mockResolvedValue(null);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.updateFormTemplates(formId, templateId),
      ).rejects.toThrow(RepositoryException);
      expect(logger.error).toHaveBeenCalledWith(
        `Error updating Form ${formId} with template ${templateId}`,
        mockError.message,
      );
    });

    it('should throw a RepositoryException if update fails', async () => {
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.updateFormTemplates(formId, templateId),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error updating Form ${formId} with template ${templateId}`,
        mockError.message,
      );
    });
  });

  describe('detachTemplateFromFormById', () => {
    const formId = '66ea9a7bfddf3e21da0c6959';
    const templateId = '12345';

    it('should detach the template from the form and return the updated form', async () => {
      const updatedForm = {
        ...mockFormData,
        templates: ['67890'],
      };

      const execMock = jest.fn().mockResolvedValue(updatedForm);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.detachTemplateFromFormById(
        formId,
        templateId,
      );

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $pull: { templates: templateId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(updatedForm);
      expect(logger.log).toHaveBeenCalledWith(
        `Template ${templateId} detached from form ${formId} successfully.`,
      );
    });

    it('should throw a NotFoundError if the form is not found', async () => {
      const execMock = jest.fn().mockResolvedValue(null);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.detachTemplateFromFormById(formId, templateId),
      ).rejects.toThrowError(
        new NotFoundError(`Form with ID ${formId} not found.`),
      );

      expect(logger.error).toHaveBeenCalledWith(
        `Error detaching template from form ${formId}: Form with ID ${formId} not found.`,
      );
    });

    it('should throw a RepositoryException if an error occurs during detachment', async () => {
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.detachTemplateFromFormById(formId, templateId),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error detaching template from form ${formId}: ${mockError.message}`,
      );
    });
  });

  describe('findByIdWithTemplates', () => {
    const formId = '66ea9a7bfddf3e21da0c6959';
    const mockFormData = {
      _id: formId,
      name: 'Sales Form',
      description: 'Sales Form',
      status: 'active',
      tenantId: '6708eaf5ab7b16c964098737',
      platformId: '6708eaee1f18d52405c72f88',
      isDeleted: false,
      templates: ['templateId1', 'templateId2'],
    };

    it('should return form with templates populated', async () => {
      const execMock = jest.fn().mockResolvedValue(mockFormData);
      const selectMock = jest.fn().mockReturnValue({ exec: execMock });
      const populateMock = jest.fn().mockReturnValue({ select: selectMock });

      model.findById = jest.fn().mockReturnValue({ populate: populateMock });

      const result = await repository.findByIdWithTemplates(formId);

      expect(model.findById).toHaveBeenCalledWith(formId);
      expect(populateMock).toHaveBeenCalledWith('templates');
      expect(selectMock).toHaveBeenCalledWith(
        '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy',
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockFormData);
    });

    it('should return null and log a warning if no form is found', async () => {
      const execMock = jest.fn().mockResolvedValue(null);
      const selectMock = jest.fn().mockReturnValue({ exec: execMock });
      const populateMock = jest.fn().mockReturnValue({ select: selectMock });

      model.findById = jest.fn().mockReturnValue({ populate: populateMock });

      const result = await repository.findByIdWithTemplates(formId);

      expect(model.findById).toHaveBeenCalledWith(formId);
      expect(populateMock).toHaveBeenCalledWith('templates');
      expect(selectMock).toHaveBeenCalledWith(
        '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy',
      );
      expect(execMock).toHaveBeenCalled();
      expect(logger.warn).toHaveBeenCalledWith(
        `Form with ID ${formId} not found.`,
      );
      expect(result).toBeNull();
    });

    it('should throw a RepositoryException if an error occurs', async () => {
      const mockError = new Error('Database error');
      const execMock = jest.fn().mockRejectedValue(mockError);
      const selectMock = jest.fn().mockReturnValue({ exec: execMock });
      const populateMock = jest.fn().mockReturnValue({ select: selectMock });

      model.findById = jest.fn().mockReturnValue({ populate: populateMock });

      await expect(repository.findByIdWithTemplates(formId)).rejects.toThrow(
        RepositoryException,
      );

      expect(logger.error).toHaveBeenCalledWith(
        `Error fetching Form with ID ${formId}`,
        mockError.message,
      );
    });
  });

  describe('updateFormTabs', () => {
    const formId = '66ea9a7bfddf3e21da0c6959';
    const tabId = 'newTabId';

    it('should update the form and add the tab to the tabs array', async () => {
      const updatedForm = {
        ...mockFormData,
        tabs: [...(mockFormData.tabs ?? []), tabId],
      };

      const execMock = jest.fn().mockResolvedValue(updatedForm);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.updateFormTabs(formId, tabId);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $addToSet: { tabs: tabId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(updatedForm);
      expect(logger.log).toHaveBeenCalledWith(
        `Form with ID ${formId} updated successfully, tab ${tabId} added.`,
      );
    });

    it('should throw a NotFoundError if form is not found', async () => {
      const mockError = new NotFoundError(`Form with ID ${formId} not found.`);
      const execMock = jest.fn().mockResolvedValue(null);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(repository.updateFormTabs(formId, tabId)).rejects.toThrow(
        mockError,
      );
      expect(logger.error).toHaveBeenCalledWith(
        `Error updating Form ${formId} with tab ${tabId}`,
        mockError.message,
      );
    });

    it('should throw a RepositoryException if an error occurs during the update', async () => {
      const mockError = new Error('Update failed');
      const execMock = jest.fn().mockRejectedValue(mockError);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(repository.updateFormTabs(formId, tabId)).rejects.toThrow(
        RepositoryException,
      );
      expect(logger.error).toHaveBeenCalledWith(
        `Error updating Form ${formId} with tab ${tabId}`,
        mockError.message,
      );
    });
  });
  describe('detachTabFromFormById', () => {
    it('should detach the tab from the form and return the updated form', async () => {
      const formId = '66ea9a7bfddf3e21da0c6959';
      const tabId = '12345';

      const execMock = jest.fn().mockResolvedValue(mockUpdatedForm);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.detachTabFromFormById(formId, tabId);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $pull: { tabs: tabId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Detaching tab ${tabId} from form ${formId}`,
      );
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Tab ${tabId} detached from form ${formId} successfully.`,
      );
      expect(result).toEqual(mockUpdatedForm);
    });

    it('should throw NotFoundError if the form is not found', async () => {
      const formId = '66ea9a7bfddf3e21da0c6959';
      const tabId = '12345';

      const execMock = jest.fn().mockResolvedValue(null);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.detachTabFromFormById(formId, tabId),
      ).rejects.toThrow(RepositoryException);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $pull: { tabs: tabId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        `Error detaching tab from form ${formId}: Form with ID ${formId} not found.`,
      );
    });

    it('should throw RepositoryException on database error', async () => {
      const formId = '66ea9a7bfddf3e21da0c6959';
      const tabId = '12345';
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError); // Simulate database error
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.detachTabFromFormById(formId, tabId),
      ).rejects.toThrow(RepositoryException);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $pull: { tabs: tabId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        `Error detaching tab from form ${formId}: ${mockError.message}`,
      );
    });
  });

  describe('updateFormFields', () => {
    it('should update the form to include the field and return the updated form', async () => {
      const formId = '66ea9a7bfddf3e21da0c6959';
      const fieldId = '12345';

      const execMock = jest.fn().mockResolvedValue(mockUpdatedForm);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.updateFormFields(formId, fieldId);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $addToSet: { fields: fieldId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Updating Form ${formId} to include field ${fieldId}`,
      );
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Form with ID ${formId} updated successfully, field ${fieldId} added.`,
      );
      expect(result).toEqual(mockUpdatedForm);
    });

    it('should throw NotFoundError if the form is not found', async () => {
      const formId = '66ea9a7bfddf3e21da0c6959';
      const fieldId = '12345';

      const execMock = jest.fn().mockResolvedValue(null); // Simulate no document found
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.updateFormFields(formId, fieldId),
      ).rejects.toThrow(RepositoryException);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $addToSet: { fields: fieldId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        `Error updating Form ${formId} with field ${fieldId}`,
        'Form with ID 66ea9a7bfddf3e21da0c6959 not found.',
      );
    });

    it('should throw RepositoryException on database error', async () => {
      const formId = '66ea9a7bfddf3e21da0c6959';
      const fieldId = '12345';
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError); // Simulate database error
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.updateFormFields(formId, fieldId),
      ).rejects.toThrow(RepositoryException);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $addToSet: { fields: fieldId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        `Error updating Form ${formId} with field ${fieldId}`,
        'Database error',
      );
    });
  });

  describe('detachFieldFromFormById', () => {
    it('should detach the field from the form and return the updated form', async () => {
      const formId = '66ea9a7bfddf3e21da0c6959';
      const fieldId = '12345';

      const execMock = jest.fn().mockResolvedValue(mockUpdatedForm);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.detachFieldFromFormById(formId, fieldId);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $pull: { fields: fieldId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Detaching field ${fieldId} from form ${formId}`,
      );
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Tab ${fieldId} detached from form ${formId} successfully.`,
      );
      expect(result).toEqual(mockUpdatedForm);
    });

    it('should throw NotFoundError if the form is not found', async () => {
      const formId = '66ea9a7bfddf3e21da0c6959';
      const fieldId = '12345';

      const execMock = jest.fn().mockResolvedValue(null);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.detachFieldFromFormById(formId, fieldId),
      ).rejects.toThrow(RepositoryException);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $pull: { fields: fieldId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        `Error detaching field from form ${formId}: Form with ID 66ea9a7bfddf3e21da0c6959 not found.`,
      );
    });

    it('should throw RepositoryException on database error', async () => {
      const formId = '66ea9a7bfddf3e21da0c6959';
      const fieldId = '12345';
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError); // Simulate database error
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(
        repository.detachFieldFromFormById(formId, fieldId),
      ).rejects.toThrow(RepositoryException);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        formId,
        { $pull: { fields: fieldId } },
        { new: true, runValidators: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(mockLoggerService.error).toHaveBeenCalledWith(
        `Error detaching field from form ${formId}: Database error`,
      );
    });
  });

  describe('findFormName', () => {
    it('should return the form if it exists', async () => {
      const formName = 'Test Form';
      const platformId = 'platform123';
      const tenantId = 'tenant123';
      const mockForm = { name: formName, platformId, tenantId };

      const execMock = jest.fn().mockResolvedValue(mockForm);
      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });

      model.findOne = findOneMock;

      const result = await repository.findFormName(
        formName,
        platformId,
        tenantId,
      );

      expect(model.findOne).toHaveBeenCalledWith({
        name: formName,
        platformId,
        tenantId,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockForm);
    });

    it('should throw an error if name is not provided', async () => {
      const formName = '';
      const platformId = 'platform123';
      const tenantId = 'tenant123';

      await expect(
        repository.findFormName(formName, platformId, tenantId),
      ).rejects.toThrowError('name are required to find a form');
    });

    it('should throw RepositoryException if form is not found', async () => {
      const formName = 'Nonexistent Form';
      const platformId = 'platform123';
      const tenantId = 'tenant123';

      const findOneMock = jest.fn().mockResolvedValue(null);
      model.findOne = findOneMock;

      await expect(
        repository.findFormName(formName, platformId, tenantId),
      ).rejects.toThrow(RepositoryException);

      expect(model.findOne).toHaveBeenCalledWith({
        name: formName,
        platformId,
        tenantId,
        isDeleted: false,
      });
    });
  });
});
