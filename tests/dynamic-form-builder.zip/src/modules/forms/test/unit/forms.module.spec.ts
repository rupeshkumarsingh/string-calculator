import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import { FormsModule } from '../../forms.module';
import { FormController } from '../../application/forms.controller';
import { FormService } from '../../application/forms.service';
import { FormRepository } from '../../infrastructure/repositories/forms.repository';
import { LoggerModule } from '../../../../logging/error-log/logger.module';
import databaseConfig from '../../../../database/config/database.config';
import { DatabaseModule } from '../../../../database/database.module';

describe('FormsModule', () => {
  let module: TestingModule;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          load: [databaseConfig],
          envFilePath: '.env',
          isGlobal: true,
        }),
        DatabaseModule,
        FormsModule,
        LoggerModule,
      ],
    }).compile();
  });

  it('should compile the module successfully', () => {
    expect(module).toBeDefined();
  });

  it('should have the FormController defined', () => {
    const controller = module.get<FormController>(FormController);
    expect(controller).toBeDefined();
  });

  it('should have the FormService defined', () => {
    const service = module.get<FormService>(FormService);
    expect(service).toBeDefined();
  });

  it('should have the FormRepository defined', () => {
    const repository = module.get<FormRepository>(FormRepository);
    expect(repository).toBeDefined();
  });
});
