import { IForm } from '../../domain/forms';
import { CreateFormDto } from '../../application/dto/create-form.dto';
import { UpdateFormDto } from '../../application/dto/update-form.dto';
import { Status } from '../../../../shared/utils/status.enum';

export const validFormDto: CreateFormDto = {
  name: 'createForm',
  description: 'Registration Form',
  status: Status.ACTIVE,
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
};

export const FormWithErrors: CreateFormDto = {
  name: 'createForm',
  description: 'Registration Form',
  status: Status.ACTIVE,
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
};

export const existingForm = {
  _id: '66f529997383a45da1867131',
  name: 'Login Form',
  description: 'Login Form',
  status: Status.ACTIVE,
} as IForm;

export const updatedFormDto: UpdateFormDto = {
  name: 'Login Form',
  description: 'Login Form',
  status: Status.ACTIVE,
};

export const newFormDto: CreateFormDto = {
  name: 'Login Form',
  description: 'Login Form',
  status: Status.ACTIVE,
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
};

export const nonExistentFormId = 'non-existent-id';
