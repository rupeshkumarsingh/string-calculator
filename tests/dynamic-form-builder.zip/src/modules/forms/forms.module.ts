import { forwardRef, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { FormController } from './application/forms.controller';
import { FormService } from './application/forms.service';
import { FormRepository } from './infrastructure/repositories/forms.repository';
import { FormSchema } from './infrastructure/schema/forms.schema';
import { AuditLogModule } from '../../logging/audit-log/audit-log.module';
import { TabsModule } from '../tabs/tabs.module';
import { FieldsModule } from '../fields/fields.module';
import { TemplatesModule } from '../templates/templates.module';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Form', schema: FormSchema }]),
    AuditLogModule,
    forwardRef(() => TabsModule),
    forwardRef(() => FieldsModule),
    forwardRef(() => TemplatesModule),
  ],
  controllers: [FormController],
  providers: [FormService, FormRepository],
  exports: [FormService, FormRepository],
})
export class FormsModule {}
