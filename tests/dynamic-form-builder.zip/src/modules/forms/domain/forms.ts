import { Document, Types } from 'mongoose';

export interface IForm extends Document {
  _id: string;
  name: string;
  description?: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
  isDeleted?: boolean;
  tenantId: string;
  platformId: string;
  templates?: Types.ObjectId[];
  tabs?: Types.ObjectId[];
  fields?: Types.ObjectId[];
  globalFields?: [];
}
