import { BaseRepository } from '../../common/pagination/interfaces/base.repository.interface';
import { IForm } from './forms';

export interface IFormRepository extends BaseRepository<IForm> {
  createForm(FormData: IForm): Promise<IForm>;
  getFormById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<IForm | null>;
  updateForm(id: string, updateData: Partial<IForm>): Promise<IForm | null>;
  deleteForm(id: string): Promise<IForm | null>;
  findAllPaginated(
    filters: Record<string, unknown>,
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
    includeDeleted?: boolean,
    tenantId?: string,
    platformId?: string,
  );
}
