import {
  Injectable,
  NotFoundException,
  ConflictException,
  InternalServerErrorException,
  BadRequestException,
} from '@nestjs/common';
import { FieldsRepository } from '../infrastructure/repositories/fields.repository';
import { CreateFieldDto } from './dto/create-field.dto';
import { UpdateFieldDto } from './dto/update.field.dto';
import { IField } from '../domain/fields';
import { BaseService } from '../../common/pagination/services/base.service';
import { LoggerService } from '../../../logging/error-log/logger.service';
import { AuditLogService } from '../../../logging/audit-log/audit-log.service';
import {
  AuditAction,
  AuditEntity,
} from '../../../logging/audit-log/audit-log.enums';
import { FormRepository } from '../../forms/infrastructure/repositories/forms.repository';

@Injectable()
export class FieldsService extends BaseService<IField> {
  constructor(
    private readonly fieldsRepository: FieldsRepository,
    private readonly logger: LoggerService,
    private readonly auditLog: AuditLogService,
    private readonly formRepository: FormRepository,
  ) {
    super(fieldsRepository);
  }

  /**
   * Create a new Field
   * @param CreateFieldDto The DTO containing the Field data
   * @returns The newly created Field
   */
  async createField(
    formId: string,
    createFieldDto: CreateFieldDto,
  ): Promise<IField> {
    try {
      const isUnique = await this.validateUniqueName(
        createFieldDto.formId,
        createFieldDto.name,
        createFieldDto.isGlobal,
      );
      if (!isUnique) {
        this.logger.warn('Field name must be unique', {
          createFieldDto,
        });
        throw new ConflictException('Field with this name already exists');
      }
      const fieldData: IField = { ...createFieldDto } as IField;
      const field = await this.fieldsRepository.createField(fieldData);

      if (!createFieldDto.isGlobal) {
        await this.formRepository.updateFormFields(formId, field._id);
      }

      //Audit Log
      await this.auditLog.logAudit({
        action: AuditAction.CREATE,
        entityName: AuditEntity.FIELD,
        effectedEntityId: field.id,
        newValue: field,
      });

      this.logger.log(
        `Field created successfully: ${field.id}`,
        'FieldsService',
      );
      return field;
    } catch (error) {
      if (error instanceof ConflictException) {
        this.logger.warn('Conflict occurred while creating field', error);
        throw error;
      }
      this.logger.error('Error creating field', error.stack);
      throw new InternalServerErrorException('Failed to create field');
    }
  }

  /**
   * Get Field by ID
   * @param id Field ID
   * @returns The Field if found, otherwise throws NotFoundException
   */
  async getFieldById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<IField> {
    const field = await this.fieldsRepository.getFieldById(
      id,
      tenantId,
      platformId,
    );
    if (!field) {
      this.logger.warn(`Field with ID ${id} not found`);
      throw new NotFoundException(`Field with ID ${id} not found`);
    }
    this.logger.log(`Field retrieved: ${field.id}`);
    return field;
  }

  /**
   * Update a Field
   * @param id Field ID
   * @param updateDto DTO containing update data
   * @returns The updated Field, or throws NotFoundException if not found
   */
  async updateField(
    id: string,
    updateFieldDto: UpdateFieldDto,
    tenantId: string,
    platformId: string,
  ): Promise<IField> {
    const existingField = await this.fieldsRepository.getFieldById(
      id,
      tenantId,
      platformId,
    );

    if (!existingField) {
      this.logger.warn(`Field with ID ${id} not found`);
      throw new NotFoundException(`Field with ID ${id} not found`);
    }

    if (updateFieldDto.name && updateFieldDto.formId) {
      await this.validateUniqueName(
        updateFieldDto.formId,
        updateFieldDto.name,
        updateFieldDto.isGlobal,
        id,
      );
    }

    const updatedField = await this.fieldsRepository.updateField(
      id,
      updateFieldDto,
    );

    if (!updatedField) {
      this.logger.warn(`Failed to update Field with ID ${id} - returned null`);
      throw new InternalServerErrorException(
        'Failed to update Field - returned null',
      );
    }
    // Audit Log for Update
    await this.auditLog.logAudit({
      action: AuditAction.UPDATE,
      entityName: AuditEntity.FIELD,
      effectedEntityId: updatedField.id,
      oldValue: existingField,
      newValue: updatedField,
    });

    this.logger.log(`Field updated: ${updatedField.id}`);
    return updatedField;
  }

  /**
   * Delete a Field
   * @param id Field ID
   * @returns The deleted Field, or throws NotFoundException if not found
   */
  async deleteField(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<IField | null> {
    try {
      const existingField = await this.fieldsRepository.getFieldById(
        id,
        tenantId,
        platformId,
      );

      if (!existingField) {
        this.logger.warn(`Field with ID ${id} not found`);
        throw new NotFoundException(`Field with ID ${id} not found`);
      }

      const formId = existingField.formId || '';

      try {
        if (!existingField.isGlobal) {
          await this.formRepository.detachFieldFromFormById(formId, id);
        }
      } catch (detachError) {
        this.logger.error(
          `Failed to detach field ${id} from form ${formId}: ${detachError.message}`,
        );
        throw new InternalServerErrorException(
          'Failed to detach field from form',
        );
      }

      const deletedField = await this.fieldsRepository.deleteField(id);

      if (!deletedField) {
        this.logger.warn(
          `Failed to delete Field with ID ${id} - returned null`,
        );
        throw new InternalServerErrorException(
          'Failed to delete Field - returned null',
        );
      }

      await this.auditLog.logAudit({
        action: AuditAction.DELETE,
        entityName: AuditEntity.FIELD,
        effectedEntityId: deletedField.id,
        oldValue: existingField,
      });

      this.logger.log(`Field deleted: ${deletedField.id}`);
      return deletedField;
    } catch (error) {
      this.logger.error(
        `Unexpected error while deleting field ${id}: ${error.message}`,
      );
      throw new InternalServerErrorException(
        'An error occurred while deleting the field',
      );
    }
  }

  /**
   * Validates that the provided Field name is unique.
   *
   * If `isGlobal` is true, validates the uniqueness at the system level.
   * Otherwise, validates uniqueness within the specified form and ensures it does not conflict with global fields.
   *
   * @param {string} formId - The unique identifier of the form to which the Field belongs.
   * @param {string} name - The Field name to validate for uniqueness.
   * @param {boolean} isGlobal - Whether the Field is global.
   * @param {string} [currentFieldId] - Optional. The ID of the current Field, used during update operations.
   * @returns {Promise<boolean>} - Resolves successfully if the name is unique.
   */
  async validateUniqueName(
    formId: string,
    name: string,
    isGlobal: boolean = false,
    currentFieldId?: string,
  ): Promise<boolean> {
    if (!name) {
      throw new BadRequestException('Name is required.');
    }

    try {
      if (isGlobal) {
        // Check uniqueness at the system level
        const existingField = await this.fieldsRepository.findByName(name);

        if (
          existingField &&
          (!currentFieldId || existingField._id.toString() !== currentFieldId)
        ) {
          this.logger.log(`Global Field name conflict detected: ${name}`);
          return false;
        }
      } else {
        if (!formId) {
          throw new BadRequestException('Form ID is required.');
        }
        // Check uniqueness within the form
        const existingFieldInForm =
          await this.fieldsRepository.findByFormIdAndName(formId, name);

        if (
          existingFieldInForm &&
          (!currentFieldId ||
            existingFieldInForm._id.toString() !== currentFieldId)
        ) {
          this.logger.log(
            `Field name conflict detected: ${name} for formId ${formId}`,
          );
          return false;
        }

        // Check conflict with global fields
        const existingGlobalField = await this.fieldsRepository.findByName(
          name,
          true,
        );

        if (
          existingGlobalField &&
          (!currentFieldId ||
            existingGlobalField._id.toString() !== currentFieldId)
        ) {
          this.logger.log(
            `Field name conflict with global field detected: ${name}`,
          );
          return false;
        }
      }

      return true;
    } catch (error) {
      this.logger.error(
        `Error during Field name validation for formId ${formId}, name ${name}, isGlobal ${isGlobal}:`,
        error,
      );
      throw new BadRequestException(
        'Unable to validate the Field name at this time. Please try again later.',
      );
    }
  }
}
