import {
  IsNotEmpty,
  IsString,
  IsEnum,
  IsOptional,
  Length,
  MaxLength,
  ValidateNested,
  IsObject,
  IsBoolean,
  IsArray,
  ValidateIf,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import DOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';
import { ValidationDto } from './validation.dto';
import { DataSourceDTO } from './data-source.dto';
import { Status, LayoutType } from '../../../../shared/utils/status.enum';

const dom = new JSDOM();
const purify = DOMPurify(dom.window);

export class CreateFieldDto {
  @IsNotEmpty()
  @IsString()
  @Length(3, 256)
  @ApiProperty({ example: 'fname' })
  @Transform(({ value }) => purify.sanitize(value))
  name: string;

  @IsOptional()
  @IsString()
  @ApiProperty({ example: 'First Name', description: 'General field label' })
  label?: string;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  @ApiProperty({ example: 'First name' })
  @Transform(({ value }) => purify.sanitize(value))
  description: string;

  @IsOptional()
  @IsString()
  @ApiProperty({ example: 'text', description: 'Type of the field' })
  type?: string;

  @IsEnum(Status)
  @ApiProperty({
    enum: Status,
    example: Status.ACTIVE,
  })
  status: Status;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'user123',
    description: 'The ID of the user who created the tab.',
  })
  createdBy?: string;

  @IsOptional()
  @IsString()
  updatedBy?: string;

  @IsNotEmpty()
  @IsString()
  tenantId: string;

  @IsNotEmpty()
  @IsString()
  platformId: string;

  @ValidateIf((obj) => !obj.isGlobal)
  @IsNotEmpty()
  @IsString()
  @ApiProperty({
    example: '67109aa1ddd11a771522c050',
    description: 'The ID of the form.',
  })
  formId: string;

  @IsOptional()
  @IsObject()
  @ValidateNested()
  @Type(() => ValidationDto)
  @ApiProperty({
    description: 'Validation rules for the field.',
    type: ValidationDto,
  })
  validation?: ValidationDto;

  @IsOptional()
  @IsBoolean()
  @ApiProperty({
    example: false,
    description: 'Indicates if the field is deleted.',
  })
  isDeleted?: boolean;

  @IsOptional()
  @IsBoolean()
  @ApiProperty({
    example: false,
    description: 'Indicates if the field is deleted.',
  })
  isGlobal?: boolean;

  @IsOptional()
  @ValidateNested()
  @Type(() => DataSourceDTO)
  @Transform(({ value }) => value ?? undefined)
  @ApiProperty({
    description: 'Data source for the field, either static or API-based.',
    type: DataSourceDTO,
  })
  dataSource?: DataSourceDTO;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @ApiProperty({
    description: 'Array of IDs referencing child fields.',
    type: [String],
    required: false,
    example: ['field123', 'field456'],
  })
  childFieldIds?: string[];

  @IsOptional()
  @IsEnum(LayoutType)
  @ApiProperty({
    description: 'Defines the layout for field options.',
    enum: LayoutType,
    example: LayoutType.Vertical,
    required: false,
  })
  layout?: LayoutType;
}
