import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional, IsString } from 'class-validator';

export class ValidationDto {
  @IsOptional()
  @IsString()
  @ApiProperty({ example: '^[a-zA-Z0-9]+$', description: 'Validation pattern' })
  pattern?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({ example: '3', description: 'Minimum length' })
  min_length?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({ example: '50', description: 'Maximum length' })
  max_length?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({ example: 'true', description: 'Is the field required?' })
  required?: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @ApiProperty({
    example: ['pdf', 'docx', 'jpg'],
    description: 'List of supported file types.',
    type: [String],
  })
  fileSupports?: string[];

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: '2023-01-01',
    description: 'Minimum allowable date.',
  })
  minDate?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: '2024-12-31',
    description: 'Maximum allowable date.',
  })
  maxDate?: string;
}
