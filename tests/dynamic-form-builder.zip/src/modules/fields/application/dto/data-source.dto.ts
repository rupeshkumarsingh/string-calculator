import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

export class GeneralDto {
  @IsOptional()
  @IsString()
  @ApiProperty({ example: 'fname', description: 'General field name' })
  name?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({ example: 'First Name', description: 'General field label' })
  label?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'Field description',
    description: 'Description of the field',
  })
  description?: string;

  @IsOptional()
  @IsString()
  @ApiProperty({ example: 'text', description: 'Type of the field' })
  type?: string;
}

class StaticDataItemDTO {
  @IsString()
  @ApiProperty({
    example: 'option1',
    description: 'The key of the static data item.',
  })
  key: string;

  @IsString()
  @ApiProperty({
    example: 'Option 1',
    description: 'The value of the static data item.',
  })
  value: string;
}

class HeaderItemDTO {
  @IsString()
  @ApiProperty({
    example: 'Authorization',
    description: 'The key of the header item.',
  })
  key: string;

  @IsString()
  @ApiProperty({
    example: 'Bearer token123',
    description: 'The value of the header item.',
  })
  value: string;
}

class ParamItemDTO {
  @IsString()
  @ApiProperty({
    example: 'userId',
    description: 'The key of the query parameter.',
  })
  key: string;

  @IsString()
  @ApiProperty({
    example: '12345',
    description: 'The value of the query parameter.',
  })
  value: string;
}

class ApiDataDTO {
  @IsString()
  @ApiProperty({
    example: 'https://api.example.com/data',
    description: 'The endpoint for the API data source.',
  })
  endpoint: string;

  @IsEnum(['GET', 'POST'])
  @ApiProperty({
    enum: ['GET', 'POST'],
    example: 'GET',
    description: 'The HTTP method to fetch the data.',
  })
  method: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => HeaderItemDTO)
  @ApiProperty({
    description: 'The headers to include in the API request.',
    type: [HeaderItemDTO],
    required: false,
  })
  headers?: HeaderItemDTO[];

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ParamItemDTO)
  @ApiProperty({
    description: 'Query parameters to include in the API request.',
    type: [ParamItemDTO],
    required: false,
  })
  params?: ParamItemDTO[];

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'key',
    description: 'Put key field.',
  })
  keyField: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'value',
    description: 'Put value field.',
  })
  valueField: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'defaultValue',
    description: 'Put default value.',
  })
  defaultValue: string;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'result.data.path',
    description: 'Put data pth.',
  })
  dataPath: string;
}

export class DataSourceDTO {
  @IsEnum(['static', 'api', 'template'])
  @ApiProperty({
    enum: ['static', 'api', 'template'],
    example: 'static',
    description: 'The type of data source: static or API.',
  })
  type: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => StaticDataItemDTO)
  @ApiProperty({
    description: 'Static key-value pairs for the data source.',
    type: [StaticDataItemDTO],
    required: false,
  })
  staticData?: StaticDataItemDTO[];

  @IsOptional()
  @ValidateNested()
  @Type(() => ApiDataDTO)
  @ApiProperty({
    description: 'API-based data source configuration.',
    type: ApiDataDTO,
    required: false,
  })
  apiData?: ApiDataDTO;

  @IsOptional()
  @ApiProperty({
    description: 'Grid data configuration.',
    type: Object,
    required: false,
  })
  gridData?: Record<string, unknown>;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'templateId123',
    description: 'The ID of the template associated with the data source.',
  })
  templateId?: string;
}
