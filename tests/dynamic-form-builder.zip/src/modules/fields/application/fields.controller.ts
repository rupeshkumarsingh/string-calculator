import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  HttpCode,
  HttpStatus,
  NotFoundException,
  Query,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBody,
  ApiParam,
  ApiQuery,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { CreateFieldDto } from './dto/create-field.dto';
import { UpdateFieldDto } from './dto/update.field.dto';
import { IField } from '../domain/fields';
import { PaginationDto } from '../../common/pagination/dto/pagination.dto';
import { FieldsService } from './fields.service';
import { LoggerService } from '../../../logging/error-log/logger.service';

@ApiTags('Fields')
@Controller('fields')
@ApiBearerAuth('Authorization')
@ApiBearerAuth('x-api-key')
export class FieldsController {
  constructor(
    private readonly fieldService: FieldsService,
    private readonly logger: LoggerService,
  ) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Create a new field' })
  @ApiBody({ type: CreateFieldDto })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Field successfully created.',
  })
  @ApiResponse({
    status: HttpStatus.CONFLICT,
    description: 'Duplicate field .',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid request payload.',
  })
  async createField(@Body() CreateFieldDto: CreateFieldDto): Promise<IField> {
    this.logger.log('Creating a new field');
    const formId = CreateFieldDto.formId;
    const field = await this.fieldService.createField(formId, CreateFieldDto);
    this.logger.log(`Field created successfully: ${field.id}`);
    return field;
  }

  @Get(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Get a field by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the field',
    type: String,
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Field successfully retrieved.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Field not found.',
  })
  async getFieldById(
    @Param('id') id: string,
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<IField> {
    this.logger.log(`Retrieving field with ID: ${id}`);
    const field = await this.fieldService.getFieldById(
      id,
      body.tenantId,
      body.platformId,
    );
    if (!field) {
      this.logger.warn(`Field with ID ${id} not found`);
      throw new NotFoundException(`Field with ID ${id} not found`);
    }
    this.logger.log(`Field retrieved: ${field.id}`);
    return field;
  }

  @Get()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Get all Fields with optional pagination and sorting',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    description: 'Page number for pagination.',
    example: 1,
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    description: 'Number of items per page.',
    example: 10,
  })
  @ApiQuery({
    name: 'sortBy',
    required: false,
    description: 'Field to sort by.',
    example: 'name',
  })
  @ApiQuery({
    name: 'sortOrder',
    required: false,
    description: 'Sort order: "asc" or "desc".',
    example: 'asc',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'List of Fields retrieved successfully.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid pagination or sorting parameters.',
  })
  async getAllFields(
    @Query() query: PaginationDto = {},
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<unknown> {
    this.logger.log('Retrieving all Fields with pagination and sorting');
    const includeDeleted = query.includeDeleted ?? false;
    const populate = [
      {
        path: 'form',
        select: 'name description',
      },
      {
        path: 'items',
        select:
          '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy -id -__v -id -formId -status -childFieldIds',
      },
    ];
    const Fields = await this.fieldService.findAllWithPopulatedData(
      query,
      populate,
      includeDeleted,
      body.tenantId,
      body.platformId,
    );
    this.logger.log(`Retrieved ${Fields?.items?.length} Fields`);
    return Fields;
  }

  @Put(':id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Update a field by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the field to be updated',
    type: String,
  })
  @ApiBody({ type: UpdateFieldDto })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Field successfully updated.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Field not found.',
  })
  async updateField(
    @Param('id') id: string,
    @Body() UpdateFieldDto: UpdateFieldDto,
  ): Promise<IField> {
    this.logger.log(`Updating field with ID: ${id}`);

    const tenantId = UpdateFieldDto.tenantId || 'defaultTenantId';
    const platformId = UpdateFieldDto.platformId || 'defaultPlatformId';
    const field = await this.fieldService.updateField(
      id,
      UpdateFieldDto,
      tenantId,
      platformId,
    );
    if (!field) {
      this.logger.warn(`Field with ID ${id} not found`);
      throw new NotFoundException(`Field with ID ${id} not found`);
    }
    this.logger.log(`Field updated: ${field.id}`);
    return field;
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete a field by its ID' })
  @ApiParam({
    name: 'id',
    description: 'The ID of the field to be deleted',
    type: String,
  })
  @ApiResponse({
    status: HttpStatus.NO_CONTENT,
    description: 'Field successfully deleted.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Field not found.',
  })
  async deleteField(
    @Param('id') id: string,
    @Body() body: { tenantId: string; platformId: string },
  ): Promise<void> {
    this.logger.log(`Deleting field with ID: ${id}`);
    const result = await this.fieldService.deleteField(
      id,
      body.tenantId,
      body.platformId,
    );
    if (!result) {
      this.logger.warn(`Field with ID ${id} not found`);
      throw new NotFoundException(`Field with ID ${id} not found`);
    }
    this.logger.log(`Field deleted: ${id}`);
  }
}
