import { Schema } from 'mongoose';
import { SchemaFieldUtils } from '../../../../shared/utils/schema-utils';
import { HttpMethod, DefaultValue } from '../../../../shared/utils/status.enum';

export const StaticDataSchema = new Schema(
  {
    key: SchemaFieldUtils.createStringField(true),
    value: SchemaFieldUtils.createStringField(true),
  },
  { _id: false },
);

export const ApiDataSchema = new Schema(
  {
    endpoint: SchemaFieldUtils.createStringField(true),
    method: SchemaFieldUtils.createStringField(
      true,
      DefaultValue.NA,
      Object.values(HttpMethod),
    ),
    headers: [
      {
        key: SchemaFieldUtils.createStringField(true),
        value: SchemaFieldUtils.createStringField(true),
      },
    ],
    params: [
      {
        key: SchemaFieldUtils.createStringField(true),
        value: SchemaFieldUtils.createStringField(true),
      },
    ],
    keyField: SchemaFieldUtils.createStringField(),
    valueField: SchemaFieldUtils.createStringField(),
    defaultValue: SchemaFieldUtils.createStringField(),
    dataPath: SchemaFieldUtils.createStringField(),
  },
  { _id: false },
);

export const GridDataSchema = new Schema(
  {
    headers: [
      {
        field: SchemaFieldUtils.createStringField(true),
        title: SchemaFieldUtils.createStringField(true),
        width: SchemaFieldUtils.createStringField(),
      },
    ],
    sortable: [SchemaFieldUtils.createStringField()],
    searchable: [SchemaFieldUtils.createStringField()],
    pagePerItem: SchemaFieldUtils.createField(Number, { required: false }),
    id: SchemaFieldUtils.createStringField(),
  },
  { _id: false },
);
