import { model, Schema } from 'mongoose';
import { IField } from '../../domain/fields';
import {
  StaticDataSchema,
  ApiDataSchema,
  GridDataSchema,
} from './data-schemas';
import {
  SchemaFieldUtils,
  SchemaIndexUtils,
} from '../../../../shared/utils/schema-utils';
import {
  Status,
  DataSourceType,
  LayoutType,
  DefaultValue,
} from '../../../../shared/utils/status.enum';

const DataSourceSchema = new Schema(
  {
    type: SchemaFieldUtils.createStringField(
      true,
      DefaultValue.NA,
      Object.values(DataSourceType),
    ),
    staticData: [StaticDataSchema],
    apiData: ApiDataSchema,
    templateId: SchemaFieldUtils.createStringField(),
    gridData: GridDataSchema,
  },
  { _id: false },
);

const FieldSchema = new Schema<IField>({
  name: SchemaFieldUtils.createStringField(true),
  label: SchemaFieldUtils.createStringField(true),
  description: SchemaFieldUtils.createStringField(),
  type: SchemaFieldUtils.createStringField(true),
  status: SchemaFieldUtils.createStringField(
    false,
    Status.ACTIVE,
    Object.values(Status),
  ),
  validation: {
    pattern: SchemaFieldUtils.createStringField(),
    min_length: SchemaFieldUtils.createStringField(),
    max_length: SchemaFieldUtils.createStringField(),
    required: SchemaFieldUtils.createStringField(),
    fileSupports: [SchemaFieldUtils.createStringField()],
    minDate: SchemaFieldUtils.createStringField(),
    maxDate: SchemaFieldUtils.createStringField(),
  },
  layout: SchemaFieldUtils.createStringField(
    false,
    DefaultValue.NA,
    Object.values(LayoutType),
  ),
  dataSource: SchemaFieldUtils.createField(DataSourceSchema, {
    required: false,
  }),
  isGlobal: SchemaFieldUtils.createBooleanField(false),
  formId: SchemaFieldUtils.createField(Schema.Types.ObjectId, { ref: 'Form' }),
  childFieldIds: [
    SchemaFieldUtils.createField(Schema.Types.ObjectId, { ref: 'Field' }),
  ],
});

// Add common fields and indexes
SchemaIndexUtils.addCommonFields(FieldSchema);
SchemaIndexUtils.addIndexes(FieldSchema, [
  { tenantId: 1, platformId: 1, formId: 1 },
]);

FieldSchema.virtual('form', {
  ref: 'Form',
  localField: 'formId',
  foreignField: '_id',
  justOne: true,
});

FieldSchema.virtual('items', {
  ref: 'Field',
  localField: 'childFieldIds',
  foreignField: '_id',
});

FieldSchema.set('toJSON', { virtuals: true });
FieldSchema.set('toObject', { virtuals: true });

export { FieldSchema };

export const FieldModel = model<IField>('Field', FieldSchema);
