import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { IField } from '../../domain/fields';
import { IFieldsRepository } from '../../domain/fields.repository.interface';
import { RepositoryException } from '../../../../shared/exceptions/repository.exception';
import LoggerService from '../../../../logging/error-log/logger.service';
import { BaseRepository } from '../../../common/pagination/repositories/base.repository';

@Injectable()
export class FieldsRepository
  extends BaseRepository<IField>
  implements IFieldsRepository
{
  constructor(
    @InjectModel('Field')
    private readonly fieldModel: Model<IField>,
    private readonly logger: LoggerService,
  ) {
    super(fieldModel);
  }

  /**
   * Creates a new field and saves it to the database.
   * @param fieldData - The data for the field to be created.
   * @returns The created  field.
   * @throws RepositoryException if the creation fails.
   */
  async createField(fieldData: IField): Promise<IField> {
    try {
      this.logger.log(`Data ${JSON.stringify(fieldData)}`);
      const field = new this.fieldModel(fieldData);
      this.logger.log('Creating field', fieldData);
      return await field.save();
    } catch (error) {
      this.logger.error('Error creating field', error.message);
      throw new RepositoryException('Failed to create field', error);
    }
  }

  /**
   * Retrieves a field by its MongoDB ObjectId.
   * @param id - The string representation of the field's MongoDB ObjectId.
   * @returns The field if found, or null if not found.
   * @throws RepositoryException if the retrieval fails.
   */
  async getFieldById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<IField | null> {
    try {
      // Log the fetching process
      this.logger.log(
        `Fetching field by id: ${id} for Tenant ID: ${tenantId} and Platform ID: ${platformId}`,
      );

      // Convert string id to MongoDB ObjectId
      const objectId = new Types.ObjectId(id);

      // Fetch the field by ID, tenant ID, and platform ID
      const field = await this.fieldModel
        .findOne({
          _id: objectId,
          tenantId,
          platformId,
          isDeleted: false,
        })
        .populate(
          'items',
          '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy -id -__v -id -formId -status -childFieldIds',
        )
        .exec();

      if (!field) {
        this.logger.warn(
          ` field with id ${id} not found for Tenant ID: ${tenantId} and Platform ID: ${platformId}`,
        );
        return null; // Return null if no field is found
      }

      return field;
    } catch (error) {
      this.logger.error(`Error fetching field with id ${id}`, error.message);
      throw new RepositoryException(`Failed to get field with id ${id}`, error);
    }
  }

  /**
   * Updates a field with the specified id.
   * @param id - The MongoDB ObjectId of the field to be updated.
   * @param updateData - The partial data to update the field with.
   * @returns The updated field if successful, or null if not found.
   * @throws RepositoryException if the update fails.
   */
  async updateField(
    id: string,
    updateData: Partial<IField>,
  ): Promise<IField | null> {
    try {
      this.logger.log(`Updating field with id: ${id}`, updateData);

      const objectId = new Types.ObjectId(id);

      return await this.fieldModel
        .findOneAndUpdate(objectId, updateData, {
          new: true,
        })
        .exec();
    } catch (error) {
      this.logger.error(`Error updating field with id ${id}`, error.message);
      throw new RepositoryException(
        `Failed to update field with id ${id}`,
        error,
      );
    }
  }

  /**
   * Deletes a field by its MongoDB ObjectId.
   * @param id - The MongoDB ObjectId of the field to be deleted.
   * @returns The deleted field if successful, or null if not found.
   * @throws RepositoryException if the deletion fails.
   */
  async deleteField(id: string): Promise<IField | null> {
    try {
      this.logger.log(`Deleting field with id: ${id}`);
      const objectId = new Types.ObjectId(id);
      //return await this.fieldModel.findOneAndDelete(objectId).exec();
      return await this.fieldModel
        .findByIdAndUpdate(objectId, { isDeleted: true }, { new: true })
        .exec();
    } catch (error) {
      this.logger.error(`Error deleting field with id ${id}`, error.message);
      throw new RepositoryException(
        `Failed to delete field with id ${id}`,
        error,
      );
    }
  }

  /**
   * Finds a single field document based on the provided form ID and field name,
   * @param {string} formId - The unique identifier of the form to which the field belongs.
   * @param {string} name - The name of the field to be retrieved.
   * @returns {Promise<IField | null>} - A promise that resolves to the found field document
   */
  async findByFormIdAndName(
    formId: string,
    name: string,
  ): Promise<IField | null> {
    try {
      if (!formId || !name) {
        throw new Error('formId and name are required to find a field');
      }

      const field = await this.fieldModel
        .findOne({ formId, name, isDeleted: false })
        .exec();

      return field;
    } catch (error) {
      this.logger.error(
        `Error finding field by formId ${formId} and name ${name}:`,
        error,
      );

      throw new RepositoryException(
        'Unable to retrieve the field at this time. Please try again later.',
        error,
      );
    }
  }

  /**
   * Deletes all fields associated with the given form ID.
   * @param formId The ID of the form.
   */
  async deleteByFormId(formId: string): Promise<unknown> {
    try {
      const result = await this.fieldModel
        .updateMany({ formId }, { isDeleted: true }, { new: true })
        .exec();
      this.logger.log(
        `Updated fields ${result.modifiedCount} records of form id ${formId}`,
      );
      return result;
    } catch (error) {
      this.logger.error(`Failed to delete fields for form: ${formId}`, error);
      throw error;
    }
  }

  /**
   * Finds a single field document based on the provided field name.
   *
   * This function retrieves a field based on the `isGlobal` flag.
   *
   * @param {string} name - The name of the field to be retrieved.
   * @param {boolean} [isGlobal=false] - Whether to filter fields marked as global.
   * @returns {Promise<IField | null>} - A promise that resolves to the found field document or null if not found.
   */
  async findByName(
    name: string,
    isGlobal: boolean = false,
  ): Promise<IField | null> {
    try {
      if (!name) {
        throw new Error('Field name is required to find a field');
      }

      const filter: Record<string, unknown> = { name, isDeleted: false };

      if (isGlobal) {
        filter.isGlobal = true;
      }

      const field = await this.fieldModel.findOne(filter).exec();

      return field;
    } catch (error) {
      this.logger.error(`Error finding field by name ${name}:`, error);

      throw new RepositoryException(
        'Unable to retrieve the field at this time. Please try again later.',
        error,
      );
    }
  }

  /**
   *
   * @returns
   */
  async getGlobalFields(): Promise<[]> {
    this.logger.log(`Fetching Global data ...`);
    try {
      const globalFields = await this.fieldModel.aggregate([
        {
          $match: {
            isGlobal: true,
            isDeleted: false,
            status: 'active',
          },
        },
        {
          $project: {
            isDeleted: 0,
            tenantId: 0,
            platformId: 0,
            createdAt: 0,
            updatedAt: 0,
            updatedBy: 0,
            createdBy: 0,
          },
        },
      ]);
      //this.logger.log(`${JSON.stringify(globalFields)}`);

      return globalFields as [];
    } catch (error) {
      this.logger.error('Error fetching global fields', error.message);
      throw new RepositoryException('Error fetching global fields', error);
    }
  }
}
