import { IField } from '../../domain/fields';
import { CreateFieldDto } from '../../application/dto/create-field.dto';
import { UpdateFieldDto } from '../../application/dto/update.field.dto';
import { Status } from '../../../../shared/utils/status.enum';

export const validFieldDto: CreateFieldDto = {
  name: 'Registration Form Field',
  description: 'Registration Form Field',
  status: Status.ACTIVE,
  createdBy: 'user123',
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
  formId: '6798bc302d7605b80b2ad5f4',
};

export const FieldWithErrors: CreateFieldDto = {
  name: 'Registration Form Field',
  description: 'Registration Form Field',
  status: Status.ACTIVE,
  createdBy: 'user123',
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
  formId: '6798bc302d7605b80b2ad5f4',
};

export const existingField = {
  _id: '670e0a510e63a8b44e2d3521',
  name: 'Login Form Field',
  description: 'Login Form Field',
  formId: '6798bc302d7605b80b2ad5f4',
  status: Status.ACTIVE,
} as IField;

export const updatedFieldDto: UpdateFieldDto = {
  name: 'Login Form Field',
  description: 'Login Form Field',
  status: Status.ACTIVE,
};

export const newFieldDto: CreateFieldDto = {
  name: 'Login Form Field',
  description: 'Login Form Field',
  status: Status.ACTIVE,
  tenantId: '6708eaee1f18d52405c72f88',
  platformId: '6708eaf5ab7b16c964098737',
  formId: '6798bc302d7605b80b2ad5f4',
};

export const nonExistentFieldId = 'non-existent-id';
