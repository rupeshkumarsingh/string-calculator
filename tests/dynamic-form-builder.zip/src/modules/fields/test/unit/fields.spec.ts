import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import mongoose from 'mongoose';
import { FieldModel } from '../../infrastructure/schema/fields.schema';
import databaseConfig from '../../../../database/config/database.config';
import { DatabaseModule } from '../../../../database/database.module';

describe('Field Model and Schema', () => {
  let module: TestingModule;

  beforeAll(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          load: [databaseConfig],
          envFilePath: '.env',
          isGlobal: true,
        }),
        DatabaseModule,
      ],
    }).compile();
  });

  afterAll(async () => {
    //await mongoose.connection.close();
    module.close();
  });

  beforeEach(async () => {
    //await tabModel.deleteMany({});
  });

  it('should throw an error if name is missing', async () => {
    const fieldData = {
      description: 'Field without a name',
      status: 'active',
    };

    const field = new FieldModel(fieldData);
    await expect(field.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });

  it('should throw an error if description is missing', async () => {
    const fieldData = {
      name: 'Field without description',
      status: 'active',
    };

    const form = new FieldModel(fieldData);
    await expect(form.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });

  it('should throw an error if status is invalid', async () => {
    const fieldData = {
      name: 'Invalid Status tab',
      description: 'This Field has an invalid status',
      status: 'invalid_status', // Invalid status not in enum
    };

    const field = new FieldModel(fieldData);
    await expect(field.save()).rejects.toThrowError(
      mongoose.Error.ValidationError,
    );
  });
});
