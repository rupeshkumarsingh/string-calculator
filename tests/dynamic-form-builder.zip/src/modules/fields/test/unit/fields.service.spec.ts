import { Test, TestingModule } from '@nestjs/testing';
import {
  BadRequestException,
  ConflictException,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { FieldsService } from '../../application/fields.service';
import { FieldsRepository } from '../../infrastructure/repositories/fields.repository';
import {
  validFieldDto,
  existingField,
  newFieldDto,
  updatedFieldDto,
  nonExistentFieldId,
} from '../fixtures/fields-fixtures';
import { PaginatedResult } from '../../../common/pagination/interfaces/paginated-result.interface';
import { IField } from '../../domain/fields';
import { PaginationDto } from '../../../common/pagination/dto/pagination.dto';
import { LoggerService } from '../../../../logging/error-log/logger.service';
import { AuditLogService } from '../../../../logging/audit-log/audit-log.service';
import { FormRepository } from '../../../forms/infrastructure/repositories/forms.repository';

describe('FieldsService', () => {
  let service: FieldsService;
  let repository: FieldsRepository;
  //let formRepository: FormRepository;

  const mockPaginatedResult: PaginatedResult<IField> = {
    items: [],
    total: 0,
    page: 1,
    limit: 100,
    totalPages: 0,
  };
  const mockFieldRepository = {
    createField: jest.fn(),
    getFieldById: jest.fn(),
    findAllPaginated: jest.fn().mockResolvedValue(mockPaginatedResult),
    updateField: jest.fn(),
    deleteField: jest.fn(),
    findByFormIdAndName: jest.fn(),
    findByName: jest.fn(),
  };

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const mockAuditLogService = {
    logAudit: jest.fn(),
  };

  const tenantId = '6708eaf5ab7b16c964098737';
  const platformId = '6708eaee1f18d52405c72f88';
  const formId = existingField.formId || '';

  const mockFormRepository = {
    updateFormFields: jest.fn(),
    detachFieldFromFormById: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        FieldsService,
        { provide: FieldsRepository, useValue: mockFieldRepository },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
        {
          provide: AuditLogService,
          useValue: mockAuditLogService,
        },
        { provide: FormRepository, useValue: mockFormRepository },
      ],
    }).compile();

    service = module.get<FieldsService>(FieldsService);
    repository = module.get<FieldsRepository>(FieldsRepository);
    //formRepository = module.get<FormRepository>(FormRepository);
  });

  describe('createField', () => {
    it('should create and return a Field successfully', async () => {
      mockFieldRepository.findByFormIdAndName.mockResolvedValue(undefined);
      mockFieldRepository.createField.mockResolvedValue(existingField);
      mockFormRepository.updateFormFields.mockResolvedValue(undefined);

      const result = await service.createField(formId, validFieldDto);

      expect(mockFieldRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        validFieldDto.name,
      );
      expect(mockFieldRepository.createField).toHaveBeenCalledWith(
        expect.objectContaining(validFieldDto),
      );

      expect(mockFormRepository.updateFormFields).toHaveBeenCalledWith(
        formId,
        existingField._id,
      );

      expect(result).toEqual(existingField);
    });

    it('should throw BadRequestException on validation failure', async () => {
      mockFieldRepository.findByFormIdAndName.mockResolvedValue(undefined);
      mockFieldRepository.createField.mockRejectedValue(
        new Error('validation failed'),
      );

      await expect(service.createField(formId, validFieldDto)).rejects.toThrow(
        InternalServerErrorException,
      );
    });

    it('should throw ConflictException for duplicate Field', async () => {
      mockFieldRepository.createField.mockResolvedValue(undefined);
      mockFieldRepository.findByFormIdAndName.mockResolvedValue(validFieldDto);

      await expect(service.createField(formId, validFieldDto)).rejects.toThrow(
        ConflictException,
      );
    });

    it('should create and return a new Field with new values', async () => {
      mockFieldRepository.createField.mockResolvedValue(newFieldDto);
      mockFieldRepository.findByFormIdAndName.mockResolvedValue(undefined);

      const result = await service.createField(formId, newFieldDto);

      expect(result).toEqual(newFieldDto);
    });

    it('should throw InternalServerErrorException on unexpected error', async () => {
      mockFieldRepository.createField.mockRejectedValue(
        new Error('DaFieldase error'),
      );
      mockFieldRepository.findByFormIdAndName.mockResolvedValue(undefined);

      await expect(service.createField(formId, validFieldDto)).rejects.toThrow(
        InternalServerErrorException,
      );
    });
  });

  describe('getFieldById', () => {
    it('should return a Field successfully', async () => {
      const id = '66ebcb8f570e341a486525cd';
      mockFieldRepository.getFieldById.mockResolvedValue(existingField);

      const result = await service.getFieldById(id, tenantId, platformId);
      expect(result).toBe(existingField);
      expect(mockFieldRepository.getFieldById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if Field not found', async () => {
      const id = 'non-existent-id';
      mockFieldRepository.getFieldById.mockResolvedValue(null);

      await expect(
        service.getFieldById(id, tenantId, platformId),
      ).rejects.toThrow(new NotFoundException(`Field with ID ${id} not found`));
      expect(mockFieldRepository.getFieldById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });
  });

  describe('findAllPaginated', () => {
    it('should call repository findAllPaginated with default values', async () => {
      const paginationQuery: PaginationDto = {};
      await service.findAllPaginated(
        paginationQuery,
        false,
        tenantId,
        platformId,
      );

      expect(repository.findAllPaginated).toHaveBeenCalledWith(
        {},
        1,
        100,
        'createdAt',
        'asc',
        false,
        tenantId,
        platformId,
      );
    });

    it('should call repository findAllPaginated with passed values', async () => {
      const paginationQuery: PaginationDto = {
        page: 2,
        limit: 50,
        sortBy: 'title',
        sortOrder: 'desc',
        filters: { status: 'active' },
      };

      await service.findAllPaginated(
        paginationQuery,
        false,
        tenantId,
        platformId,
      );

      expect(repository.findAllPaginated).toHaveBeenCalledWith(
        { status: 'active' },
        2,
        50,
        'title',
        'desc',
        false,
        tenantId,
        platformId,
      );
    });

    it('should return the paginated result from repository', async () => {
      const result = await service.findAllPaginated(
        {},
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should handle errors from the repository', async () => {
      const error = new Error('Repository error');
      mockFieldRepository.findAllPaginated.mockRejectedValueOnce(error);

      await expect(
        service.findAllPaginated({}, false, tenantId, platformId),
      ).rejects.toThrow('Repository error');
    });
  });

  describe('updateField', () => {
    it('should update and return the Field successfully', async () => {
      const id = '66ebcb8f570e341a486525cd';
      const updateDto = updatedFieldDto;
      const updatedField = { ...existingField, ...updateDto };

      mockFieldRepository.getFieldById.mockResolvedValue(existingField);

      mockFieldRepository.updateField.mockResolvedValue(updatedField);

      const result = await service.updateField(
        id,
        updateDto,
        tenantId,
        platformId,
      );

      expect(mockFieldRepository.getFieldById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFieldRepository.updateField).toHaveBeenCalledWith(
        id,
        updateDto,
      );
      expect(result).toEqual({ ...existingField, ...updateDto });
    });

    it('should throw NotFoundException if Field to update is not found', async () => {
      mockFieldRepository.getFieldById.mockResolvedValueOnce(null);

      await expect(
        service.updateField(
          nonExistentFieldId,
          updatedFieldDto,
          tenantId,
          platformId,
        ),
      ).rejects.toThrow(NotFoundException);

      expect(mockFieldRepository.updateField).toHaveBeenCalled();
    });

    it('should throw InternalServerErrorException if update returns null', async () => {
      // Arrange: Mock the repository methods
      mockFieldRepository.getFieldById.mockResolvedValue(existingField);
      mockFieldRepository.updateField.mockResolvedValue(null);
      await expect(
        service.updateField(
          existingField.id,
          updatedFieldDto,
          tenantId,
          platformId,
        ),
      ).rejects.toThrow(InternalServerErrorException);
      expect(mockFieldRepository.getFieldById).toHaveBeenCalledWith(
        existingField.id,
        tenantId,
        platformId,
      );
      expect(mockFieldRepository.updateField).toHaveBeenCalledWith(
        existingField.id,
        updatedFieldDto,
      );
    });

    it('should call validateUniqueName if both name and formId are provided', async () => {
      const updateDto = {
        ...updatedFieldDto,
        name: 'Updated Name',
        formId: existingField.formId,
        isGlobal: true,
      };

      mockFieldRepository.getFieldById.mockResolvedValue(existingField);
      mockFieldRepository.updateField.mockResolvedValue({
        ...existingField,
        ...updateDto,
      });

      const validateUniqueNameSpy = jest.spyOn(service, 'validateUniqueName');

      await service.updateField(
        existingField.id,
        updateDto,
        tenantId,
        platformId,
      );

      expect(validateUniqueNameSpy).toHaveBeenCalledWith(
        existingField.formId,
        updateDto.name,
        updateDto.isGlobal,
        existingField.id,
      );
      validateUniqueNameSpy.mockRestore();
    });

    it('should not call validateUniqueName if name or formId is missing', async () => {
      const updateDto = {
        ...updatedFieldDto,
        name: undefined,
        formId: undefined,
      };

      mockFieldRepository.getFieldById.mockResolvedValue(existingField);
      mockFieldRepository.updateField.mockResolvedValue({
        ...existingField,
        ...updateDto,
      });

      const validateUniqueNameSpy = jest.spyOn(service, 'validateUniqueName');

      await service.updateField(
        existingField.id,
        updateDto,
        tenantId,
        platformId,
      );

      expect(validateUniqueNameSpy).not.toHaveBeenCalled();
      validateUniqueNameSpy.mockRestore();
    });
  });
  describe('deleteField', () => {
    it('should delete the Field successfully', async () => {
      const id = existingField._id;
      mockFieldRepository.getFieldById.mockResolvedValueOnce(existingField);
      mockFieldRepository.deleteField.mockResolvedValueOnce(existingField);
      const result = await service.deleteField(id, tenantId, platformId);
      expect(result).toEqual(existingField);
      expect(mockFieldRepository.getFieldById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFieldRepository.deleteField).toHaveBeenCalledWith(id);
    });

    it('should throw NotFoundException if Field to delete is not found', async () => {
      const id = nonExistentFieldId;
      mockFieldRepository.getFieldById.mockResolvedValueOnce(null);

      await expect(
        service.deleteField(id, tenantId, platformId),
      ).rejects.toThrow(
        new NotFoundException(`An error occurred while deleting the field`),
      );
      expect(mockFieldRepository.getFieldById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFieldRepository.deleteField).toHaveBeenCalled();
    });

    it('should throw InternalServerErrorException if failed to detach field from form', async () => {
      const id = existingField._id;
      mockFieldRepository.getFieldById.mockResolvedValue(existingField);
      mockFormRepository.detachFieldFromFormById.mockRejectedValue(
        new Error('Failed to detach field'),
      );

      await expect(
        service.deleteField(id, tenantId, platformId),
      ).rejects.toThrow(
        new InternalServerErrorException(
          'An error occurred while deleting the field',
        ),
      );

      expect(mockFieldRepository.getFieldById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.detachFieldFromFormById).toHaveBeenCalledWith(
        existingField.formId,
        id,
      );
    });

    it('should throw InternalServerErrorException on unexpected error', async () => {
      const id = existingField._id;

      mockFieldRepository.getFieldById.mockRejectedValue(
        new Error('Unexpected error'),
      );

      await expect(
        service.deleteField(id, tenantId, platformId),
      ).rejects.toThrow(
        new InternalServerErrorException(
          'An error occurred while deleting the field',
        ),
      );

      expect(mockFieldRepository.getFieldById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });

    it('should throw InternalServerErrorException if delete returns null', async () => {
      const id = existingField._id;

      mockFieldRepository.getFieldById.mockResolvedValue(existingField);
      mockFormRepository.detachFieldFromFormById.mockResolvedValue(undefined);
      mockFieldRepository.deleteField.mockResolvedValue(null);

      await expect(
        service.deleteField(id, tenantId, platformId),
      ).rejects.toThrow(
        new InternalServerErrorException(
          'An error occurred while deleting the field',
        ),
      );

      expect(mockFieldRepository.getFieldById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
      expect(mockFormRepository.detachFieldFromFormById).toHaveBeenCalledWith(
        existingField.formId,
        id,
      );
      expect(mockFieldRepository.deleteField).toHaveBeenCalledWith(id);
    });
  });

  describe('FieldsService - validateUniqueName', () => {
    it('should return true if the global field name is unique', async () => {
      const formId = 'form123';
      const name = 'uniqueName';
      const isGlobal = true;
      const currentFieldId = undefined;

      mockFieldRepository.findByName.mockResolvedValue(null);

      const result = await service.validateUniqueName(
        formId,
        name,
        isGlobal,
        currentFieldId,
      );

      expect(result).toBe(true);
      expect(mockFieldRepository.findByName).toHaveBeenCalledWith(name);
    });

    it('should return false if the global field name is already in use', async () => {
      const formId = 'form123';
      const name = 'duplicateName';
      const isGlobal = true;
      const currentFieldId = undefined;

      mockFieldRepository.findByName.mockResolvedValue(existingField);

      const result = await service.validateUniqueName(
        formId,
        name,
        isGlobal,
        currentFieldId,
      );

      expect(result).toBe(false);
      expect(mockFieldRepository.findByName).toHaveBeenCalledWith(name);
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Global Field name conflict detected: ${name}`,
      );
    });

    it('should return true if updating the same global field (no conflict)', async () => {
      const formId = 'form123';
      const name = 'duplicateName';
      const isGlobal = true;
      const currentFieldId = existingField._id.toString();

      mockFieldRepository.findByName.mockResolvedValue(existingField);

      const result = await service.validateUniqueName(
        formId,
        name,
        isGlobal,
        currentFieldId,
      );

      expect(result).toBe(true);
      expect(mockFieldRepository.findByName).toHaveBeenCalledWith(name);
    });

    it('should return true if the field name is unique within the form and globally', async () => {
      const formId = 'form123';
      const name = 'uniqueName';
      const isGlobal = false;
      const currentFieldId = undefined;

      mockFieldRepository.findByFormIdAndName.mockResolvedValue(null);
      mockFieldRepository.findByName.mockResolvedValue(null);

      const result = await service.validateUniqueName(
        formId,
        name,
        isGlobal,
        currentFieldId,
      );

      expect(result).toBe(true);
      expect(mockFieldRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        name,
      );
      expect(mockFieldRepository.findByName).toHaveBeenCalledWith(name, true);
    });

    it('should return false if the field name is already in use within the form', async () => {
      const formId = 'form123';
      const name = 'duplicateName';
      const isGlobal = false;
      const currentFieldId = undefined;

      mockFieldRepository.findByFormIdAndName.mockResolvedValue(existingField);
      mockFieldRepository.findByName.mockResolvedValue(null);

      const result = await service.validateUniqueName(
        formId,
        name,
        isGlobal,
        currentFieldId,
      );

      expect(result).toBe(false);
      expect(mockFieldRepository.findByFormIdAndName).toHaveBeenCalledWith(
        formId,
        name,
      );
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Field name conflict detected: ${name} for formId ${formId}`,
      );
    });

    it('should return false if the field name conflicts with a global field while validating within a form', async () => {
      const formId = 'form123';
      const name = 'duplicateName';
      const isGlobal = false;
      const currentFieldId = undefined;

      mockFieldRepository.findByFormIdAndName.mockResolvedValue(null);
      mockFieldRepository.findByName.mockResolvedValue(existingField);

      const result = await service.validateUniqueName(
        formId,
        name,
        isGlobal,
        currentFieldId,
      );

      expect(result).toBe(false);
      expect(mockFieldRepository.findByName).toHaveBeenCalledWith(name, true);
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Field name conflict with global field detected: ${name}`,
      );
    });

    it('should throw BadRequestException if formId or name is not provided', async () => {
      const formId = '';
      const name = 'name';
      const isGlobal = false;
      const currentFieldId = undefined;

      await expect(
        service.validateUniqueName(formId, name, isGlobal, currentFieldId),
      ).rejects.toThrowError(
        new BadRequestException(
          'Unable to validate the Field name at this time. Please try again later.',
        ),
      );
    });

    it('should throw BadRequestException if an error occurs during the database call', async () => {
      const formId = 'form123';
      const name = 'errorName';
      const isGlobal = false;
      const currentFieldId = undefined;

      mockFieldRepository.findByFormIdAndName.mockRejectedValue(
        new Error('Database error'),
      );

      await expect(
        service.validateUniqueName(formId, name, isGlobal, currentFieldId),
      ).rejects.toThrowError(
        new BadRequestException(
          'Unable to validate the Field name at this time. Please try again later.',
        ),
      );
    });
  });
});
