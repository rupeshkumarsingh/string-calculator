import { Test, TestingModule } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { IField } from '../../domain/fields';
import { Model, Types } from 'mongoose';
import { FieldsRepository } from '../../infrastructure/repositories/fields.repository';
import { LoggerService } from '../../../../logging/error-log/logger.service';
import { RepositoryException } from '../../../../shared/exceptions/repository.exception';

describe('FieldsRepository', () => {
  let repository: FieldsRepository;
  let model: Model<IField>;
  let logger: LoggerService;

  const mockFieldModel = jest.fn().mockImplementation(() => ({
    save: jest.fn(),
    findById: jest.fn().mockReturnThis(),
    exec: jest.fn(),
    countDocuments: jest.fn(),
    find: jest.fn(),
    sort: jest.fn().mockReturnThis(),
    skip: jest.fn().mockReturnThis(),
    limit: jest.fn().mockReturnThis(),
    updateMay: jest.fn(),
  }));

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const mockFieldData = {
    _id: '670e0e640cd41b6881c65c48',
    name: 'Sales Form Field',
    description: 'Sales Form Field',
    status: 'active',
    isDeleted: false,
    tenantId: '6708eaf5ab7b16c964098737',
    platformId: '6708eaee1f18d52405c72f88',
  } as IField;

  const tenantId = '6708eaf5ab7b16c964098737';
  const platformId = '6708eaee1f18d52405c72f88';

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        FieldsRepository,
        {
          provide: getModelToken('Field'),
          useValue: mockFieldModel,
        },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    repository = module.get<FieldsRepository>(FieldsRepository);
    model = module.get<Model<IField>>(getModelToken('Field'));
    logger = module.get<LoggerService>(LoggerService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('createField', () => {
    it('should create and save a new form', async () => {
      const formInstance = new mockFieldModel();
      mockFieldModel.mockImplementation(() => formInstance);
      formInstance.save.mockResolvedValue(mockFieldData);

      const result = await repository.createField(mockFieldData);

      expect(mockFieldModel).toHaveBeenCalledWith(mockFieldData);
      expect(formInstance.save).toHaveBeenCalled();
      expect(result).toEqual(mockFieldData);

      expect(logger.log).toHaveBeenCalledWith('Creating field', mockFieldData);
    });

    it('should throw a RepositoryException if save fails', async () => {
      const mockError = new Error('Database error');

      const formInstance = new mockFieldModel();
      mockFieldModel.mockImplementation(() => formInstance);
      formInstance.save.mockRejectedValue(mockError);

      await expect(repository.createField(mockFieldData)).rejects.toThrow(
        RepositoryException,
      );

      expect(logger.error).toHaveBeenCalledWith(
        'Error creating field',
        mockError.message,
      );
    });
  });

  describe('getFieldById', () => {
    it('should return a Field by id', async () => {
      const objectId = new Types.ObjectId(mockFieldData._id);

      const execMock = jest.fn().mockResolvedValue(mockFieldData);

      const populateMock = jest.fn().mockReturnValue({ exec: execMock });

      const findByIdMock = jest
        .fn()
        .mockReturnValue({ populate: populateMock });

      model.findOne = findByIdMock;

      const result = await repository.getFieldById(
        mockFieldData._id,
        tenantId,
        platformId,
      );

      expect(model.findOne).toHaveBeenCalledWith({
        _id: objectId,
        tenantId,
        platformId,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockFieldData);
    });

    it('should return null if field is not found', async () => {
      const objectId = new Types.ObjectId(mockFieldData._id);

      const execMock = jest.fn().mockResolvedValue(null);
      const populateMock = jest.fn().mockReturnValue({ exec: execMock });
      const findByIdMock = jest
        .fn()
        .mockReturnValue({ populate: populateMock });

      model.findOne = findByIdMock;

      const result = await repository.getFieldById(
        mockFieldData._id,
        tenantId,
        platformId,
      );

      expect(model.findOne).toHaveBeenCalledWith({
        _id: objectId,
        tenantId,
        platformId,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toBeNull();
      expect(logger.warn).toHaveBeenCalledWith(
        ` field with id ${mockFieldData._id} not found for Tenant ID: ${tenantId} and Platform ID: ${platformId}`,
      );
    });
    it('should throw a RepositoryException if findOne fails', async () => {
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError);

      const populateMock = jest.fn().mockReturnValue({ exec: execMock });

      const findByIdMock = jest
        .fn()
        .mockReturnValue({ populate: populateMock });

      model.findOne = findByIdMock;

      await expect(
        repository.getFieldById(mockFieldData._id, tenantId, platformId),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error fetching field with id ${mockFieldData._id}`,
        mockError.message,
      );
    });
  });

  describe('updateField', () => {
    const mockUpdateData = { name: 'Purchase Form Fields' };

    it('should update and return the updated Field', async () => {
      const mockUpdatedTemplate = { ...mockFieldData, ...mockUpdateData };

      const execMock = jest.fn().mockResolvedValue(mockUpdatedTemplate);
      const findOneAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findOneAndUpdate = findOneAndUpdateMock;

      const result = await repository.updateField(
        mockFieldData._id,
        mockUpdateData,
      );

      expect(model.findOneAndUpdate).toHaveBeenCalledWith(
        new Types.ObjectId(mockFieldData._id),
        mockUpdateData,
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockUpdatedTemplate);
    });

    it('should throw a RepositoryException if updating fails', async () => {
      const mockError = new Error('Update failed');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findOneAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findOneAndUpdate = findOneAndUpdateMock;

      await expect(
        repository.updateField(mockFieldData._id, mockUpdateData),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error updating field with id ${mockFieldData._id}`,
        mockError.message,
      );
    });
  });

  describe('deleteField', () => {
    it('should soft delete and return the updated Field', async () => {
      const mockSoftDeletedTemplate = { ...mockFieldData, isDeleted: true };

      // Create a mock return value that includes the exec method
      const execMock = jest.fn().mockResolvedValue(mockSoftDeletedTemplate);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      const result = await repository.deleteField(mockFieldData._id);

      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        new Types.ObjectId(mockFieldData._id),
        { isDeleted: true },
        { new: true },
      );
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockSoftDeletedTemplate);
    });

    it('should throw a RepositoryException if soft deletion fails', async () => {
      const mockError = new Error('Soft delete failed');

      const execMock = jest.fn().mockRejectedValue(mockError);
      const findByIdAndUpdateMock = jest
        .fn()
        .mockReturnValue({ exec: execMock });

      model.findByIdAndUpdate = findByIdAndUpdateMock;

      await expect(repository.deleteField(mockFieldData._id)).rejects.toThrow(
        RepositoryException,
      );

      expect(logger.error).toHaveBeenCalledWith(
        `Error deleting field with id ${mockFieldData._id}`,
        mockError.message,
      );
    });
  });
  describe('findByFormIdAndName', () => {
    const formId = '6708eaf5ab7b16c964098737';
    const name = 'Sales Form Field';

    it('should return a field when found by formId and name', async () => {
      const mockField = { ...mockFieldData, formId, name };
      const execMock = jest.fn().mockResolvedValue(mockField);

      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });
      model.findOne = findOneMock;

      const result = await repository.findByFormIdAndName(formId, name);

      expect(model.findOne).toHaveBeenCalledWith({
        formId,
        name,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toEqual(mockField);
    });

    it('should return null if field is not found', async () => {
      const execMock = jest.fn().mockResolvedValue(null);

      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });
      model.findOne = findOneMock;

      const result = await repository.findByFormIdAndName(formId, name);

      expect(model.findOne).toHaveBeenCalledWith({
        formId,
        name,
        isDeleted: false,
      });
      expect(execMock).toHaveBeenCalled();
      expect(result).toBeNull();
    });

    it('should throw a RepositoryException if an error occurs during the query', async () => {
      const mockError = new Error('Database error');

      const execMock = jest.fn().mockRejectedValue(mockError);

      const findOneMock = jest.fn().mockReturnValue({ exec: execMock });
      model.findOne = findOneMock;

      await expect(
        repository.findByFormIdAndName(formId, name),
      ).rejects.toThrow(RepositoryException);

      expect(logger.error).toHaveBeenCalledWith(
        `Error finding field by formId ${formId} and name ${name}:`,
        mockError,
      );
    });

    it('should throw an error if formId or name are missing', async () => {
      await expect(repository.findByFormIdAndName('', name)).rejects.toThrow(
        'formId and name are required to find a field',
      );

      await expect(repository.findByFormIdAndName(formId, '')).rejects.toThrow(
        'formId and name are required to find a field',
      );
    });
  });

  describe('deleteByFormId', () => {
    const formId = '6708eaf5ab7b16c964098737';

    it('should update multiple fields as deleted and log the result', async () => {
      const mockResult = { modifiedCount: 3 }; // Simulated result from updateMany
      const updateManyMock = jest
        .fn()
        .mockReturnValue({ exec: jest.fn().mockResolvedValue(mockResult) });

      model.updateMany = updateManyMock;

      const result = await repository.deleteByFormId(formId);

      expect(model.updateMany).toHaveBeenCalledWith(
        { formId },
        { isDeleted: true },
        { new: true },
      );
      expect(updateManyMock().exec).toHaveBeenCalled();
      expect(result).toEqual(mockResult);
      expect(logger.log).toHaveBeenCalledWith(
        `Updated fields ${mockResult.modifiedCount} records of form id ${formId}`,
      );
    });

    it('should log an error and throw if updateMany fails', async () => {
      const mockError = new Error('Database error');
      const updateManyMock = jest
        .fn()
        .mockReturnValue({ exec: jest.fn().mockRejectedValue(mockError) });

      model.updateMany = updateManyMock;

      await expect(repository.deleteByFormId(formId)).rejects.toThrow(
        mockError,
      );

      expect(model.updateMany).toHaveBeenCalledWith(
        { formId },
        { isDeleted: true },
        { new: true },
      );
      expect(logger.error).toHaveBeenCalledWith(
        `Failed to delete fields for form: ${formId}`,
        mockError,
      );
    });
  });

  describe('findByName', () => {
    it('should return a field when name and filter match', async () => {
      const mockField = { ...mockFieldData, isGlobal: true };

      model.findOne = jest
        .fn()
        .mockReturnValue({ exec: jest.fn().mockResolvedValue(mockField) });

      const result = await repository.findByName(mockField.name, true);

      expect(model.findOne).toHaveBeenCalledWith({
        name: mockField.name,
        isDeleted: false,
        isGlobal: true,
      });

      expect(result).toEqual(mockField);
    });

    it('should return null if no field is found', async () => {
      model.findOne = jest
        .fn()
        .mockReturnValue({ exec: jest.fn().mockResolvedValue(null) });

      const result = await repository.findByName('NonExistentField', false);

      expect(model.findOne).toHaveBeenCalledWith({
        name: 'NonExistentField',
        isDeleted: false,
      });

      expect(result).toBeNull();
    });

    it('should throw an error if name is not provided', async () => {
      await expect(repository.findByName('', false)).rejects.toThrow(
        'Field name is required to find a field',
      );

      expect(logger.error).toHaveBeenCalledWith(
        'Error finding field by name :',
        expect.any(Error),
      );
    });

    it('should throw a RepositoryException if database query fails', async () => {
      const mockError = new Error('Database error');

      model.findOne = jest
        .fn()
        .mockReturnValue({ exec: jest.fn().mockRejectedValue(mockError) });

      await expect(repository.findByName('SomeField', false)).rejects.toThrow(
        RepositoryException,
      );

      expect(logger.error).toHaveBeenCalledWith(
        'Error finding field by name SomeField:',
        mockError,
      );
    });
  });

  describe('getGlobalFields', () => {
    it('should fetch and return global fields', async () => {
      const mockGlobalFields = [
        {
          _id: '670e0e640cd41b6881c65c48',
          name: 'Global Field 1',
          description: 'Description for Global Field 1',
          status: 'active',
          isGlobal: true,
        },
        {
          _id: '670e0e640cd41b6881c65c49',
          name: 'Global Field 2',
          description: 'Description for Global Field 2',
          status: 'active',
          isGlobal: true,
        },
      ];

      // Mocking the aggregate function
      const aggregateMock = jest.fn().mockResolvedValue(mockGlobalFields);
      model.aggregate = aggregateMock;

      const result = await repository.getGlobalFields();

      expect(model.aggregate).toHaveBeenCalledWith([
        {
          $match: {
            isGlobal: true,
            isDeleted: false,
            status: 'active',
          },
        },
        {
          $project: {
            isDeleted: 0,
            tenantId: 0,
            platformId: 0,
            createdAt: 0,
            updatedAt: 0,
            updatedBy: 0,
            createdBy: 0,
          },
        },
      ]);
      expect(result).toEqual(mockGlobalFields);
      expect(logger.log).toHaveBeenCalledWith('Fetching Global data ...');
      //expect(logger.log).toHaveBeenCalledWith(JSON.stringify(mockGlobalFields));
    });

    it('should return an empty array if no global fields are found', async () => {
      const mockGlobalFields: [] = [];

      const aggregateMock = jest.fn().mockResolvedValue(mockGlobalFields);
      model.aggregate = aggregateMock;

      const result = await repository.getGlobalFields();

      expect(model.aggregate).toHaveBeenCalledWith([
        {
          $match: {
            isGlobal: true,
            isDeleted: false,
            status: 'active',
          },
        },
        {
          $project: {
            isDeleted: 0,
            tenantId: 0,
            platformId: 0,
            createdAt: 0,
            updatedAt: 0,
            updatedBy: 0,
            createdBy: 0,
          },
        },
      ]);
      expect(result).toEqual([]);
      expect(logger.log).toHaveBeenCalledWith('Fetching Global data ...');
      //expect(logger.log).toHaveBeenCalledWith(JSON.stringify([]));
    });

    it('should throw a RepositoryException if aggregate fails', async () => {
      const mockError = new Error('Database error');
      const aggregateMock = jest.fn().mockRejectedValue(mockError);
      model.aggregate = aggregateMock;

      await expect(repository.getGlobalFields()).rejects.toThrow(
        RepositoryException,
      );

      expect(logger.error).toHaveBeenCalledWith(
        'Error fetching global fields',
        mockError.message,
      );
    });
  });
});
