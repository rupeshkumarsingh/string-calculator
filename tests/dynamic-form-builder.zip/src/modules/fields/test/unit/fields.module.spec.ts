import { Test, TestingModule } from '@nestjs/testing';
import { ConfigModule } from '@nestjs/config';
import { FieldsModule } from '../../fields.module';
import { FieldsController } from '../../application/fields.controller';
import { FieldsService } from '../../application/fields.service';
import { FieldsRepository } from '../../infrastructure/repositories/fields.repository';
import { LoggerModule } from '../../../../logging/error-log/logger.module';
import databaseConfig from '../../../../database/config/database.config';
import { DatabaseModule } from '../../../../database/database.module';

describe('TabsModule', () => {
  let module: TestingModule;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          load: [databaseConfig],
          envFilePath: '.env',
          isGlobal: true,
        }),
        DatabaseModule,
        FieldsModule,
        LoggerModule,
      ],
    }).compile();
  });

  it('should compile the module successfully', () => {
    expect(module).toBeDefined();
  });

  it('should have the FieldsController defined', () => {
    const controller = module.get<FieldsController>(FieldsController);
    expect(controller).toBeDefined();
  });

  it('should have the FieldsService defined', () => {
    const service = module.get<FieldsService>(FieldsService);
    expect(service).toBeDefined();
  });

  it('should have the FieldsRepository defined', () => {
    const repository = module.get<FieldsRepository>(FieldsRepository);
    expect(repository).toBeDefined();
  });
});
