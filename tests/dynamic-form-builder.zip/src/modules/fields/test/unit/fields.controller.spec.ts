import { Test, TestingModule } from '@nestjs/testing';
import {
  existingField,
  validFieldDto,
  nonExistentFieldId,
} from '../fixtures/fields-fixtures';
import { NotFoundException } from '@nestjs/common';
import { FieldsController } from '../../application/fields.controller';
import { FieldsService } from '../../application/fields.service';
import { CreateFieldDto } from '../../application/dto/create-field.dto';
import { UpdateFieldDto } from '../../application/dto/update.field.dto';
import { PaginatedResult } from '../../../common/pagination/interfaces/paginated-result.interface';
import { PaginationDto } from '../../../common/pagination/dto/pagination.dto';
import { LoggerService } from '../../../../logging/error-log/logger.service';

describe('FieldsController', () => {
  let controller: FieldsController;
  let service: FieldsService;
  const mockPaginatedResult: PaginatedResult<unknown> = {
    items: [], // Simulate empty results for the test
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  };
  const mockFieldsService = {
    createField: jest.fn(),
    getFieldById: jest.fn(),
    getAllFields: jest.fn(),
    updateField: jest.fn(),
    deleteField: jest.fn(),
    findAllWithPopulatedData: jest.fn().mockResolvedValue(mockPaginatedResult),
  };

  const mockLoggerService = {
    log: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
  };

  const tenantId = '6708eaf5ab7b16c964098737';
  const platformId = '6708eaee1f18d52405c72f88';

  const populate = [
    { path: 'form', select: 'name description' },
    {
      path: 'items',
      select:
        '-isDeleted -tenantId -platformId -createdAt -updatedAt -updatedBy -createdBy -id -__v -id -formId -status -childFieldIds',
    },
  ];

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [FieldsController],
      providers: [
        { provide: FieldsService, useValue: mockFieldsService },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    controller = module.get<FieldsController>(FieldsController);
    service = module.get<FieldsService>(FieldsService);
  });

  describe('createField', () => {
    it('should create and return a form successfully', async () => {
      mockFieldsService.createField.mockResolvedValue(existingField);

      const result = await controller.createField(
        validFieldDto as CreateFieldDto,
      );
      const formId = existingField.formId;
      expect(result).toEqual(existingField);
      expect(service.createField).toHaveBeenCalledWith(formId, validFieldDto);
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        'Creating a new field',
      );
      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Field created successfully: ${existingField.id}`,
      );
    });

    it('should throw an error if field creation fails', async () => {
      mockFieldsService.createField.mockRejectedValue(
        new Error('Creation failed'),
      );

      await expect(
        controller.createField(validFieldDto as CreateFieldDto),
      ).rejects.toThrowError('Creation failed');
    });

    it('should handle invalid DTO and throw validation errors', async () => {
      const invalidDto = {
        ...validFieldDto,
        formId: undefined,
      } as unknown as CreateFieldDto;

      await expect(
        controller.createField(invalidDto as CreateFieldDto),
      ).rejects.toThrowError();
    });

    it('should handle large or complex DTO values', async () => {
      const largeDto = {
        ...validFieldDto,
        extraData: new Array(1000).fill('test'),
      } as CreateFieldDto;

      mockFieldsService.createField.mockResolvedValue(existingField);

      const result = await controller.createField(largeDto);
      expect(result).toEqual(existingField);
      expect(service.createField).toHaveBeenCalledWith(
        validFieldDto.formId,
        largeDto,
      );
    });

    it('should validate and call service with valid CreateFieldDto', async () => {
      const validDto = {
        name: 'fname',
        status: 'active',
        tenantId: 'tenant123',
        platformId: 'platform123',
        formId: 'form123',
      } as CreateFieldDto;
      const result = await controller.createField(validDto);
      expect(result).toBeDefined();
    });
  });

  describe('getFieldById', () => {
    it('should return a form by id', async () => {
      const id = '66f529997383a45da1867131';
      mockFieldsService.getFieldById.mockResolvedValue(existingField);

      const result = await controller.getFieldById(id, {
        tenantId,
        platformId,
      });
      expect(result).toEqual(existingField);
      expect(service.getFieldById).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if form not found', async () => {
      const id = nonExistentFieldId;
      mockFieldsService.getFieldById.mockResolvedValue(null);

      await expect(
        controller.getFieldById(id, { tenantId, platformId }),
      ).rejects.toThrow(new NotFoundException(`Field with ID ${id} not found`));
    });
  });

  describe('getAllFields', () => {
    it('should be defined', () => {
      expect(controller).toBeDefined();
    });
    it('should call FieldsService.findAllWithPopulatedData and return result', async () => {
      const query: PaginationDto = { page: 1, limit: 10 };
      const result = await controller.getAllFields(query, {
        tenantId,
        platformId,
      });

      expect(service.findAllWithPopulatedData).toHaveBeenCalledWith(
        query,
        populate,
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should handle an empty query by using default values', async () => {
      const query: PaginationDto = {};
      const body = { tenantId, platformId };
      const result = await controller.getAllFields(query, body);

      expect(service.findAllWithPopulatedData).toHaveBeenCalledWith(
        query,
        populate,
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should handle includeDeleted flag correctly', async () => {
      const query: PaginationDto = { includeDeleted: true };
      const body = { tenantId, platformId };
      const result = await controller.getAllFields(query, body);

      expect(service.findAllWithPopulatedData).toHaveBeenCalledWith(
        query,
        populate,
        true,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should call FieldsService.findAllWithPopulatedData with default query if none provided', async () => {
      const defaultQuery: PaginationDto = {};

      const result = await controller.getAllFields(undefined, {
        tenantId,
        platformId,
      });

      expect(service.findAllWithPopulatedData).toHaveBeenCalledWith(
        defaultQuery,
        populate,
        false,
        tenantId,
        platformId,
      );
      expect(result).toEqual(mockPaginatedResult);
    });

    it('should handle errors thrown by the service', async () => {
      const query: PaginationDto = {};
      const body = { tenantId, platformId };
      mockFieldsService.findAllWithPopulatedData.mockRejectedValue(
        new Error('Service Error'),
      );

      await expect(controller.getAllFields(query, body)).rejects.toThrowError(
        'Service Error',
      );
    });
  });

  describe('updateField', () => {
    const id = '670e0a510e63a8b44e2d3521';
    const updateDto = {
      name: 'Updated Field',
      tenantId,
      platformId,
    } as UpdateFieldDto;
    it('should update and return the Field successfully', async () => {
      mockFieldsService.updateField.mockResolvedValue({
        ...existingField,
      });

      const result = await controller.updateField(id, updateDto);
      expect(result).toEqual({
        ...existingField,
      });
      expect(service.updateField).toHaveBeenCalledWith(
        id,
        updateDto,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if Field to update is not found', async () => {
      const id = nonExistentFieldId;
      const updateDto = { name: 'Updated Field' } as UpdateFieldDto;

      mockFieldsService.updateField.mockResolvedValue(null);

      await expect(controller.updateField(id, updateDto)).rejects.toThrow(
        new NotFoundException(`Field with ID ${id} not found`),
      );
    });

    it('should handle missing tenantId or platformId in DTO by using default values', async () => {
      const dtoWithoutIds = {
        name: 'Updated Field',
      } as Partial<UpdateFieldDto>;

      mockFieldsService.updateField.mockResolvedValue(existingField);

      const result = await controller.updateField(
        id,
        dtoWithoutIds as UpdateFieldDto,
      );

      expect(result).toEqual(existingField);
      expect(service.updateField).toHaveBeenCalledWith(
        id,
        dtoWithoutIds,
        'defaultTenantId',
        'defaultPlatformId',
      );
    });

    it('should throw an error if the service call fails unexpectedly', async () => {
      mockFieldsService.updateField.mockRejectedValue(
        new Error('Service Error'),
      );

      await expect(controller.updateField(id, updateDto)).rejects.toThrow(
        new Error('Service Error'),
      );

      expect(mockLoggerService.log).toHaveBeenCalledWith(
        `Updating field with ID: ${id}`,
      );
    });
  });

  describe('deleteField', () => {
    const id = '670e0a510e63a8b44e2d3521';

    it('should delete the Field successfully', async () => {
      mockFieldsService.deleteField.mockResolvedValue(existingField);

      await controller.deleteField(id, { tenantId, platformId });
      expect(service.deleteField).toHaveBeenCalledWith(
        id,
        tenantId,
        platformId,
      );
    });

    it('should throw NotFoundException if Field to delete is not found', async () => {
      const id = nonExistentFieldId;

      mockFieldsService.deleteField.mockResolvedValue(null);

      await expect(
        controller.deleteField(id, { tenantId, platformId }),
      ).rejects.toThrow(new NotFoundException(`Field with ID ${id} not found`));
    });
  });
});
