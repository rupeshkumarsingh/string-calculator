import { Document } from 'mongoose';

export interface IField extends Document {
  _id: string;
  name: string;
  label?: string;
  description?: string;
  type?: string;
  status: string;
  validation?: {
    pattern?: string;
    min_length?: string;
    max_length?: string;
    required?: string;
    fileSupports?: string[];
    minDate?: string;
    maxDate?: string;
  };
  layout?: 'horizontal' | 'vertical';
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
  isDeleted?: boolean;
  isGlobal?: boolean;
  tenantId: string;
  platformId: string;
  formId?: string;
  dataSource?: Partial<{
    type: string;
    staticData?: Array<{ key: string; value: string }>;
    apiData?: {
      endpoint: string;
      method: string;
      headers?: Array<{ key: string; value: string }>;
      params?: Array<{ key: string; value: string }>;
      keyField?: string;
      valueField?: string;
      defaultValue?: string;
      dataPath?: string;
    };
    templateId?: string;
    gridData?: Record<string, unknown>;
  }>;
  childFieldIds?: string[] | undefined;
}
