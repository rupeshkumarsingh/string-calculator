import { BaseRepository } from '../../common/pagination/interfaces/base.repository.interface';
import { IField } from './fields';

export interface IFieldsRepository extends BaseRepository<IField> {
  createField(FieldData: IField): Promise<IField>;
  getFieldById(
    id: string,
    tenantId: string,
    platformId: string,
  ): Promise<IField | null>;
  updateField(id: string, updateData: Partial<IField>): Promise<IField | null>;
  deleteField(id: string): Promise<IField | null>;
  findAllPaginated(
    filters: Record<string, unknown>,
    page: number,
    limit: number,
    sortBy: string,
    sortOrder: 'asc' | 'desc',
    includeDeleted?: boolean,
    tenantId?: string,
    platformId?: string,
  );
}
