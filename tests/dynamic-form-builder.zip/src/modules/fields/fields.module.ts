import { forwardRef, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { FieldsController } from './application/fields.controller';
import { FieldsService } from './application/fields.service';
import { FieldsRepository } from './infrastructure/repositories/fields.repository';
import { FieldSchema } from './infrastructure/schema/fields.schema';
import { AuditLogModule } from '../../logging/audit-log/audit-log.module';
import { FormsModule } from '../forms/forms.module';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Field', schema: FieldSchema }]),
    AuditLogModule,
    forwardRef(() => FormsModule),
  ],
  controllers: [FieldsController],
  providers: [FieldsService, FieldsRepository],
  exports: [FieldsService, FieldsRepository],
})
export class FieldsModule {}
