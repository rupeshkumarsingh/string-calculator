import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { TenantPlatformService } from '../../config/tenants/tenant-platform.service';

@Module({
  controllers: [AuthController],
  providers: [AuthService, TenantPlatformService],
})
export class AuthModule {}
