import { Injectable, NotFoundException } from '@nestjs/common';
import { TenantPlatformService } from '../../config/tenants/tenant-platform.service';
import * as jwt from 'jsonwebtoken';

@Injectable()
export class AuthService {
  constructor(private readonly tenantPlatformService: TenantPlatformService) {}

  /**
   * Authenticates a user across all tenants.
   * @param email - The email of the user.
   * @param password - The password of the user.
   * @returns {User} - Returns the authenticated user.
   * @throws {NotFoundException} - Throws if the user or tenant is not found, or the password is incorrect.
   */
  authenticateUser(email: string, password: string): object {
    // Retrieve all tenants
    const tenants = this.tenantPlatformService.getTenants();

    // Find the user across all tenants
    const tenant = tenants.find((tenant) =>
      tenant.users.some((user) => user.email === email),
    );

    if (!tenant) {
      throw new NotFoundException(`User with email ${email} not found.`);
    }

    if (!tenant.isActive) {
      throw new NotFoundException(
        `The tenant associated with email ${email} is inactive.`,
      );
    }

    const user = tenant.users.find((user) => user.email === email);

    if (!user || user.password !== password) {
      throw new NotFoundException('Invalid email or password.');
    }

    const payload = {
      publicKey: tenant.apiKeys.publicKey,
      tenantId: tenant.tenantId,
      platformId: tenant.platformId,
      userId: user.id,
      email: user.email,
    };

    const secretKey = tenant.apiKeys.privateKey;
    const token = jwt.sign(payload, secretKey, { expiresIn: '1h' });

    return { token };
  }
}
