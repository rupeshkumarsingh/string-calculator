import { Controller, Post, Body, HttpCode, HttpStatus } from '@nestjs/common';
import { AuthService } from './auth.service';
import {
  ApiBearerAuth,
  ApiBody,
  ApiOperation,
  ApiProperty,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';

class AuthDto {
  @ApiProperty({
    description: 'The email of the user.',
    example: 'tenant@demo.com',
  })
  email: string;

  @ApiProperty({
    description: 'The password of the user.',
    example: 'Test@123',
  })
  password: string;
}

@Controller('auth')
@ApiTags('Auth')
@ApiBearerAuth('x-api-key')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  /**
   * Endpoint for user authentication.
   * @param email - The email of the user.
   * @param password - The password of the user.
   * @returns {User} - Returns the authenticated user.
   */
  @Post('login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Authenticate user',
    description: 'Logs in a user and returns a JWT.',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Successfully authenticated',
    schema: {
      example: {
        accessToken: 'jwt.token.here',
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.UNAUTHORIZED,
    description: 'Invalid email or password.',
  })
  @ApiBody({
    type: AuthDto,
    description: 'User login credentials',
  })
  authenticateUser(
    @Body('email') email: string,
    @Body('password') password: string,
  ): object {
    return this.authService.authenticateUser(email, password);
  }
}
