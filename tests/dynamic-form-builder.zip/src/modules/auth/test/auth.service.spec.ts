import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from '../auth.service';
import { TenantPlatformService } from '../../../config/tenants/tenant-platform.service';
import { NotFoundException } from '@nestjs/common';

describe('AuthService', () => {
  let authService: AuthService;

  const mockTenantPlatformService = {
    getTenants: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        {
          provide: TenantPlatformService,
          useValue: mockTenantPlatformService,
        },
      ],
    }).compile();

    authService = module.get<AuthService>(AuthService);
  });

  it('should authenticate a valid user and return a token', () => {
    const mockTenants = [
      {
        tenantId: 'tenant1',
        platformId: 'platform1',
        isActive: true,
        apiKeys: {
          publicKey: 'testPublicKey',
          privateKey: 'testPrivateKey',
        },
        users: [
          {
            id: 'user1',
            email: 'test@example.com',
            password: 'password123',
          },
        ],
      },
    ];

    mockTenantPlatformService.getTenants.mockReturnValue(mockTenants);

    const result = authService.authenticateUser(
      'test@example.com',
      'password123',
    );

    expect(result).toHaveProperty('token');
  });

  it('should throw NotFoundException if the user is not found', () => {
    const mockTenants = [
      {
        tenantId: 'tenant1',
        platformId: 'platform1',
        isActive: true,
        apiKeys: {
          publicKey: 'testPublicKey',
          privateKey: 'testPrivateKey',
        },
        users: [],
      },
    ];

    mockTenantPlatformService.getTenants.mockReturnValue(mockTenants);

    expect(() =>
      authService.authenticateUser('nonexistent@example.com', 'password123'),
    ).toThrowError(NotFoundException);
  });

  it('should throw NotFoundException if the password is incorrect', () => {
    const mockTenants = [
      {
        tenantId: 'tenant1',
        platformId: 'platform1',
        isActive: true,
        apiKeys: {
          publicKey: 'testPublicKey',
          privateKey: 'testPrivateKey',
        },
        users: [
          {
            id: 'user1',
            email: 'test@example.com',
            password: 'password123',
          },
        ],
      },
    ];

    mockTenantPlatformService.getTenants.mockReturnValue(mockTenants);

    expect(() =>
      authService.authenticateUser('test@example.com', 'wrongPassword'),
    ).toThrowError(NotFoundException);
  });

  it('should throw NotFoundException if the tenant is inactive', () => {
    const mockTenants = [
      {
        tenantId: 'tenant1',
        platformId: 'platform1',
        isActive: false,
        apiKeys: {
          publicKey: 'testPublicKey',
          privateKey: 'testPrivateKey',
        },
        users: [
          {
            id: 'user1',
            email: 'test@example.com',
            password: 'password123',
          },
        ],
      },
    ];

    mockTenantPlatformService.getTenants.mockReturnValue(mockTenants);

    expect(() =>
      authService.authenticateUser('test@example.com', 'password123'),
    ).toThrowError(NotFoundException);
  });
});
