import { Test, TestingModule } from '@nestjs/testing';
import { AuthController } from '../auth.controller';
import { AuthService } from '../auth.service';
import { NotFoundException } from '@nestjs/common';

describe('AuthController', () => {
  let authController: AuthController;
  let authService: AuthService;

  const mockAuthService = {
    authenticateUser: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AuthController],
      providers: [
        {
          provide: AuthService,
          useValue: mockAuthService,
        },
      ],
    }).compile();

    authController = module.get<AuthController>(AuthController);
    authService = module.get<AuthService>(AuthService);
  });

  it('should authenticate user and return access token', () => {
    const mockEmail = 'test@example.com';
    const mockPassword = 'password123';
    const mockToken = { token: 'mockToken' };

    mockAuthService.authenticateUser.mockReturnValue(mockToken);

    const result = authController.authenticateUser(mockEmail, mockPassword);

    expect(result).toEqual(mockToken);
    expect(authService.authenticateUser).toHaveBeenCalledWith(
      mockEmail,
      mockPassword,
    );
  });

  it('should throw NotFoundException for invalid credentials', () => {
    const mockEmail = 'invalid@example.com';
    const mockPassword = 'wrongPassword';

    mockAuthService.authenticateUser.mockImplementation(() => {
      throw new NotFoundException('Invalid email or password.');
    });

    expect(() =>
      authController.authenticateUser(mockEmail, mockPassword),
    ).toThrow(NotFoundException);

    expect(authService.authenticateUser).toHaveBeenCalledWith(
      mockEmail,
      mockPassword,
    );
  });
});
