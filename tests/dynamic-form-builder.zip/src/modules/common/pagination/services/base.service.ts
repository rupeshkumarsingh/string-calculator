import { Document } from 'mongoose';
import { PaginationDto } from '../dto/pagination.dto';
import { PaginatedResult } from '../interfaces/paginated-result.interface';
import { BaseRepository } from '../repositories/base.repository';

export abstract class BaseService<T extends Document> {
  constructor(protected readonly repository: BaseRepository<T>) {}

  /**
   * Retrieves all items with pagination data.
   *
   * This method fetches documents based on provided filters
   * related documents from the specified path, and returns a paginated result.
   *
   * @param query - The pagination and filter parameters.
   * @param includeDeleted - Whether to include deleted records.
   * @param tenantId - The tenant ID for multi-tenancy.
   * @param platformId - The platform ID.
   * @returns A promise that resolves to a PaginatedResult containing the populated items.
   */
  async findAllPaginated(
    query: PaginationDto = {},
    includeDeleted = false,
    tenantId: string,
    platformId: string,
  ): Promise<PaginatedResult<T>> {
    const {
      page = 1,
      limit = 100,
      sortBy = 'createdAt',
      sortOrder = 'asc',
      filters = {},
    } = query;

    return this.repository.findAllPaginated(
      filters,
      page,
      limit,
      sortBy,
      sortOrder,
      includeDeleted,
      tenantId,
      platformId,
    );
  }

  /**
   * Retrieves all items with pagination and populated related data.
   *
   * This method fetches documents based on provided filters, populates
   * related documents from the specified path, and returns a paginated result.
   *
   * @param query - The pagination and filter parameters.
   * @param populateOptions - The path to populate related data.
   * @param includeDeleted - Whether to include deleted records.
   * @param tenantId - The tenant ID for multi-tenancy.
   * @param platformId - The platform ID.
   * @returns A promise that resolves to a PaginatedResult containing the populated items.
   */
  async findAllWithPopulatedData(
    query: PaginationDto,
    populateOptions:
      | { path: string; select: string }
      | { path: string; select: string }[],
    includeDeleted = false,
    tenantId: string,
    platformId: string,
  ): Promise<PaginatedResult<T>> {
    const {
      page = 1,
      limit = 100,
      sortBy = 'createdAt',
      sortOrder = 'asc',
      filters = {},
    } = query;

    return this.repository.findAllWithPopulatedData(
      filters,
      populateOptions,
      page,
      limit,
      sortBy,
      sortOrder,
      includeDeleted,
      tenantId,
      platformId,
    );
  }
}
