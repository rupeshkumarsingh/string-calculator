import {
  Module,
  MiddlewareConsumer,
  NestModule,
  RequestMethod,
} from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { LoggerModule } from './logging/error-log/logger.module';
import { ConfigModule } from '@nestjs/config';
import appConfig from './config/app.config';
import databaseConfig from './database/config/database.config';
import { DatabaseModule } from './database/database.module';
import { FormsModule } from './modules/forms/forms.module';
import { HealthModule } from './health/health.module';
import { AuditLogModule } from './logging/audit-log/audit-log.module';
import { TemplatesModule } from './modules/templates/templates.module';
import { RequestSanitizationMiddleware } from './shared/middleware/request-sanitization.middleware';
//import { ValidateMiddleware } from './shared/middleware/validate.middleware';
import { TokenVerificationMiddleware } from './shared/middleware/token-verification.middleware';
import { TabsModule } from './modules/tabs/tabs.module';
import { FieldsModule } from './modules/fields/fields.module';
import { TenantsModule } from './config/tenants/tenants.module';
import { AuthModule } from './modules/auth/auth.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: `.env`,
      load: [appConfig, databaseConfig],
    }),
    DatabaseModule,
    LoggerModule,
    FormsModule,
    HealthModule,
    TemplatesModule,
    AuditLogModule,
    TabsModule,
    FieldsModule,
    TenantsModule,
    AuthModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer
      .apply(RequestSanitizationMiddleware, TokenVerificationMiddleware)
      .exclude(
        { path: 'auth/(.*)', method: RequestMethod.ALL },
        { path: 'health', method: RequestMethod.ALL },
      )
      .forRoutes('*');
  }
}
