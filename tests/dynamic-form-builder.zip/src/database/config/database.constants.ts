export const DEFAULT_DATABASE_VALUES = {
  TEST_DATABASE_URL: 'mongodb://localhost:27017/test-db',
  TEST_DATABASE_NAME: 'test-db',
  DATABASE_URL: 'mongodb://localhost:27017/form-builder-db',
  DATABASE_NAME: 'form-builder-db',
};
