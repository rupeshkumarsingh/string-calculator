import { Injectable } from '@nestjs/common';
import {
  HealthIndicator,
  HealthIndicatorResult,
  HealthCheckError,
} from '@nestjs/terminus';
import { HttpService } from '@nestjs/axios';
import { timeout, catchError, firstValueFrom } from 'rxjs';
import { AxiosError } from 'axios';

interface ExternalApiHealthOptions {
  url: string;
  timeout?: number;
  validateStatus?: (status: number) => boolean;
}

@Injectable()
export class ExternalApiHealthIndicator extends HealthIndicator {
  constructor(private readonly http: HttpService) {
    super();
  }

  async isHealthy(
    key: string,
    options: ExternalApiHealthOptions,
  ): Promise<HealthIndicatorResult> {
    const {
      url,
      timeout: timeoutMs = 5000,
      validateStatus = (status: number): boolean => status === 200,
    }: ExternalApiHealthOptions = options;

    try {
      const response = await firstValueFrom(
        this.http.get(url, { validateStatus: () => true }).pipe(
          timeout(timeoutMs),
          catchError((error: AxiosError) => {
            throw new HealthCheckError(
              'External API request failed',
              this.getStatus(key, false, this.getErrorDetails(error)),
            );
          }),
        ),
      );

      const isHealthy = validateStatus(response.status);

      return this.getStatus(key, isHealthy, {
        statusCode: response.status,
        message: isHealthy
          ? 'External API is healthy'
          : 'External API returned an invalid status',
      });
    } catch (error) {
      if (error instanceof HealthCheckError) {
        throw error;
      }
      throw new HealthCheckError(
        'External API check failed',
        this.getStatus(key, false, {
          message: error instanceof Error ? error.message : 'Unknown error',
        }),
      );
    }
  }

  private getErrorDetails(error: AxiosError): Record<string, unknown> {
    if (error.response) {
      return {
        statusCode: error.response.status,
        message: 'API responded with an error',
        data: error.response.data,
      };
    } else if (error.request) {
      return {
        message: 'No response received from API',
        error: error.message,
      };
    } else {
      return {
        message: 'Error setting up the API request',
        error: error.message,
      };
    }
  }
}
