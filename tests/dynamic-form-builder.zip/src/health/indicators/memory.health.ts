import { Injectable } from '@nestjs/common';
import { HealthIndicator, HealthIndicatorResult } from '@nestjs/terminus';
import * as os from 'os';

@Injectable()
export class MemoryHealthIndicator extends HealthIndicator {
  private readonly DEFAULT_THRESHOLD_PERCENT = 90;

  async isHealthy(
    key: string,
    options: { thresholdPercent?: number } = {},
  ): Promise<HealthIndicatorResult> {
    const thresholdPercent =
      options.thresholdPercent || this.DEFAULT_THRESHOLD_PERCENT;

    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    const usedMemory = totalMemory - freeMemory;
    const usagePercentage = (usedMemory / totalMemory) * 100;

    const isHealthy = usagePercentage < thresholdPercent;

    return this.getStatus(key, isHealthy, {
      usagePercentage: `${usagePercentage.toFixed(2)}%`,
      freeMemory: this.formatBytes(freeMemory),
      usedMemory: this.formatBytes(usedMemory),
      totalMemory: this.formatBytes(totalMemory),
      threshold: `${thresholdPercent}%`,
    });
  }

  private formatBytes(bytes: number): string {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let value = bytes;
    let unitIndex = 0;

    while (value >= 1024 && unitIndex < units.length - 1) {
      value /= 1024;
      unitIndex++;
    }

    return `${value.toFixed(2)} ${units[unitIndex]}`;
  }
}
