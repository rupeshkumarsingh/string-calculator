import { Injectable } from '@nestjs/common';
import {
  HealthIndicator,
  HealthIndicatorResult,
  HealthCheckError,
} from '@nestjs/terminus';
import { promises as fs } from 'fs';
import * as path from 'path';

@Injectable()
export class DiskHealthIndicator extends HealthIndicator {
  private readonly DEFAULT_THRESHOLD_PERCENT = 80;

  async isHealthy(key: string): Promise<HealthIndicatorResult> {
    try {
      const thresholdPercent = this.DEFAULT_THRESHOLD_PERCENT;
      const rootPath = path.parse(process.cwd()).root;
      const stats = await fs.statfs(rootPath);

      const totalSpace = stats.blocks * stats.bsize;
      const freeSpace = stats.bfree * stats.bsize;
      const usedSpace = totalSpace - freeSpace;
      const usagePercentage = (usedSpace / totalSpace) * 100;

      const isHealthy = usagePercentage < thresholdPercent;

      return this.getStatus(key, isHealthy, {
        usagePercentage: `${usagePercentage.toFixed(2)}%`,
        freeSpace: `${(freeSpace / 1024 / 1024 / 1024).toFixed(2)} GB`,
        totalSpace: `${(totalSpace / 1024 / 1024 / 1024).toFixed(2)} GB`,
        usedSpace: `${(usedSpace / 1024 / 1024 / 1024).toFixed(2)} GB`,
        threshold: `${thresholdPercent}%`,
      });
    } catch (error) {
      throw new HealthCheckError(
        'Disk storage check failed',
        this.getStatus(key, false, { message: error.message }),
      );
    }
  }
}
