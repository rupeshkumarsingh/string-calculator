import { Injectable } from '@nestjs/common';
import {
  HealthIndicator,
  HealthIndicatorResult,
  HealthCheckError,
} from '@nestjs/terminus';
import { InjectConnection } from '@nestjs/mongoose';
import { Connection } from 'mongoose';

@Injectable()
export class DatabaseHealthIndicator extends HealthIndicator {
  constructor(@InjectConnection() private readonly connection: Connection) {
    super();
  }

  async isHealthy(key: string): Promise<HealthIndicatorResult> {
    try {
      const status = await this.checkConnection();
      return this.getStatus(key, status.isHealthy, status.details);
    } catch (error) {
      throw new HealthCheckError(
        'Database health check failed',
        this.getStatus(key, false, this.getErrorDetails(error)),
      );
    }
  }

  private async checkConnection(): Promise<{
    isHealthy: boolean;
    details: Record<string, unknown>;
  }> {
    const startTime = Date.now();
    const readyState = this.connection.readyState;
    const isHealthy = this.isConnectionHealthy(readyState);
    const details: Record<string, unknown> = {
      status: this.getReadyStateString(readyState),
    };

    if (isHealthy && this.connection.db) {
      try {
        const adminDb = this.connection.db.admin();
        const serverStatus = await adminDb.serverStatus();
        details.version = serverStatus.version;
        details.uptime = this.formatUptime(serverStatus.uptime);
        details.connections = serverStatus.connections;
      } catch (error) {
        details.adminCheckError =
          error instanceof Error ? error.message : 'Unknown error occurred';
      }
    } else if (isHealthy) {
      details.warning =
        'Database connection is healthy, but db object is undefined';
    }

    const latency = Date.now() - startTime;
    details.latency = `${latency} ms`;

    return { isHealthy, details };
  }

  private isConnectionHealthy(readyState: number): boolean {
    return readyState === 1; // 1 indicates 'connected'
  }

  private getReadyStateString(state: number): string {
    const states = ['down', 'up', 'connecting', 'disconnecting'];
    return states[state] || 'unknown';
  }

  private formatUptime(seconds: number): string {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor(((seconds % 86400) % 3600) / 60);
    return `${days}d ${hours}h ${minutes}m`;
  }

  private getErrorDetails(error: unknown): Record<string, unknown> {
    if (error instanceof Error) {
      return {
        message: error.message,
        stack: process.env.NODE_ENV !== 'production' ? error.stack : undefined,
      };
    }
    return { message: 'An unknown error occurred' };
  }
}
