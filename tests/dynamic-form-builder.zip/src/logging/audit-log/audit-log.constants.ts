export const AUDIT_LOG_DEFAULTS = {
  BASE_URL: 'http://localhost:3001/',
  SERVICE_NAME: 'FORM_BUILDER',
  VERSION: '1.0',
};
