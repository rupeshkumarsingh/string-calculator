import { Injectable } from '@nestjs/common';
import axios, { AxiosRequestConfig } from 'axios';
import { LoggerService } from '../error-log/logger.service';
import { ConfigService } from '@nestjs/config';
import { AUDIT_LOG_DEFAULTS } from './audit-log.constants';

@Injectable()
export class AuditLogService {
  private readonly auditLogBaseUrl: string;

  constructor(
    private readonly logger: LoggerService,
    private readonly configService: ConfigService,
  ) {
    this.auditLogBaseUrl =
      this.configService.get<string>('app.auditLogBaseUrl') ||
      AUDIT_LOG_DEFAULTS.BASE_URL;
  }

  /**
   * Logs an audit event to the Audit Log microservice.
   * @param dto - Audit log details
   */
  async logAudit(dto: Record<string, unknown>): Promise<void> {
    try {
      const payload = this.createPayload(dto);
      const config = this.createRequestConfig(payload);
      const postUrl = `${this.auditLogBaseUrl}/api/v1/audit-logs`;

      const response = await axios.post(postUrl, payload, config);

      if (response.status === 200 || response.status === 201) {
        this.logger.log('Audit log sent successfully');
      } else {
        this.logger.warn(
          `Unexpected response status for audit log: ${response.status}`,
        );
      }
    } catch (error) {
      this.logger.error('Error sending audit log:', error.message || error);
    }
  }

  /**
   * Creates a configuration object for the audit log request.
   * @param dto - Audit log details
   * @returns AxiosRequestConfig
   */
  private createRequestConfig(
    dto: Record<string, unknown>,
  ): AxiosRequestConfig {
    return {
      headers: {
        platformid: dto.platformId
          ? String(dto.platformId)
          : this.getPlatformId(),
        tenantid: dto.tenantId ? String(dto.tenantId) : this.getTenantId(),
        'Content-Type': 'application/json',
        'x-api-key': this.getXApiKey(),
      },
    };
  }

  /**
   * Fetches the platform ID from the configuration.
   * @returns string - platformId
   */
  private getPlatformId(): string {
    return (
      this.configService.get<string>('app.platformId') || 'defaultPlatform'
    );
  }

  /**
   * Fetches the tenant ID from the configuration.
   * @returns string - tenantId
   */
  private getTenantId(): string {
    return this.configService.get<string>('app.tenantId') || 'defaultTenant';
  }

  /**
   * Fetches the user ID from the configuration.
   * @returns string - userId
   */
  private getUserId(): string {
    return this.configService.get<string>('app.userId') || 'defaultUser';
  }

  /**
   * Fetches the X-API key from the configuration.
   * @returns string - xApiKey
   */
  private getXApiKey(): string {
    return this.configService.get<string>('app.xApiKey') || 'defaultXApiKey';
  }

  /**
   * Creates the payload for the audit log request.
   * @param details - Audit log details
   * @returns Record<string, unknown> - Payload for the audit log
   */
  private createPayload(
    details: Record<string, unknown>,
  ): Record<string, unknown> {
    return {
      action: details.action,
      additionalInfo: details.additionalInfo || 'No additional info',
      effectedEntityId: details.effectedEntityId || '',
      entityName: details.entityName || '',
      ipAddress: details.ipAddress || '',
      newValue: details.newValue || {},
      oldValue: details.oldValue || {},
      platformId: details.platformId || this.getPlatformId(),
      relatedEntities: details.relatedEntities || '',
      serviceName: details.serviceName || AUDIT_LOG_DEFAULTS.SERVICE_NAME,
      tenantId: details.tenantId || this.getTenantId(),
      timestamp: new Date().toISOString(),
      userId: details.userId || this.getUserId(),
      version: details.version || AUDIT_LOG_DEFAULTS.VERSION,
    };
  }
}
