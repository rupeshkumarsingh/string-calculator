// Enum for Audit Actions
export enum AuditAction {
  CREATE = 'Create',
  UPDATE = 'Update',
  DELETE = 'Delete',
  VIEW = 'View',
  LOGIN = 'Login',
  LOGOUT = 'Logout',

  CREATE_FORM = 'Create Form',
  UPDATE_FORM = 'Update Form',
  DELETE_FORM = 'Delete Form',
  CREATE_TEMPLATE = 'Create Template',
  UPDATE_TEMPLATE = 'Update Template',
  DELETE_TEMPLATE = 'Delete Template',

  CREATE_TAB = 'Create Tab',
  UPDATE_TAB = 'Update Tab',
  DELETE_TAB = 'Delete Tab',

  CREATE_FIELD = 'Create Field',
  UPDATE_FIELD = 'Update Field',
  DELETE_FIELD = 'Delete Field',

  CREATE_COMPONENT = 'Create Component',
  UPDATE_COMPONENT = 'Update Component',
  DELETE_COMPONENT = 'Delete Component',

  CREATE_FORM_DATA = 'Create Form Data',
  UPDATE_FORM_DATA = 'Update Form Data',
  DELETE_FORM_DATA = 'Delete Form Data',
}

// Enum for Entity Names
export enum AuditEntity {
  FORM = 'Form',
  TEMPLATE = 'Template',
  TAB = 'Tab',
  FIELD = 'FIELD',
  COMPONENT = 'COMPONENT',
  FORM_DATA = 'FormData',
}

// Enum for Service Names
export enum AuditService {
  FORM_BUILDER = 'Form Builder Service',
}
