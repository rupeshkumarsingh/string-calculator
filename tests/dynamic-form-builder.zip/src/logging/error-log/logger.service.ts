import * as winston from 'winston';
import { IErrorLogService } from './interfaces/error-log.interface';

export class LoggerService implements IErrorLogService {
  private logger: winston.Logger;

  constructor() {
    this.logger = winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.printf(({ level, message, timestamp }) => {
          return `${timestamp} [${level}]: ${message}`;
        }),
      ),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.printf(({ level, message, timestamp }) => {
              return `${timestamp} [${level}]: ${message}`;
            }),
          ),
        }),
        new winston.transports.File({
          filename: 'log/all.log',
          level: 'info',
          format: winston.format.combine(
            winston.format.timestamp(),
            winston.format.json(),
          ),
        }),
        new winston.transports.File({
          filename: 'log/error.log',
          level: 'error',
          format: winston.format.combine(
            winston.format.timestamp(),
            winston.format.json(),
          ),
        }),
      ],
    });
  }

  log(message: string, metadata?: unknown): void {
    this.logger.info(message, metadata || {});
  }

  error(message: string, trace?: string): void {
    this.logger.error(`${message}${trace ? ' - ' + trace : ''}`);
  }

  warn(message: string, additionalInfo?: unknown, context?: unknown): void {
    this.logger.warn(
      `${message} - ${JSON.stringify(additionalInfo)} - ${JSON.stringify(context)}`,
    );
  }

  debug(message: string): void {
    this.logger.debug(message);
  }
}

export default LoggerService;
