import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { Request, Response } from 'express';
import LoggerService from '../logger.service';
import { ResponseBuilder } from '../../../shared/utils/response.builder';

@Catch(HttpException)
export class HttpExceptionFilter implements ExceptionFilter {
  constructor(private readonly logger: LoggerService) {}

  catch(exception: unknown, host: ArgumentsHost): void {
    const { response, request } = this.getContextData(host);

    const { status, errorResponse } = this.prepareErrorResponse(
      exception,
      request,
    );

    this.logError(errorResponse, status, request);

    response.status(status).json(errorResponse);
  }

  /**
   * Extracts the context from the ArgumentsHost
   * @param host - ArgumentsHost
   * @returns { { response: Response, request: Request } }
   */
  private getContextData(host: ArgumentsHost): {
    response: Response;
    request: Request;
  } {
    const ctx = host.switchToHttp();
    return {
      response: ctx.getResponse<Response>(),
      request: ctx.getRequest<Request>(),
    };
  }

  /**
   * Prepares the error response based on the exception type
   * @param exception - The thrown exception
   * @param request - The incoming request object
   * @returns { { status: number, errorResponse: object } }
   */
  private prepareErrorResponse(
    exception: unknown,
    request: Request,
  ): { status: number; errorResponse: object } {
    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let errorResponse;

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      errorResponse = ResponseBuilder.buildErrorResponse(exception, request);
    } else {
      errorResponse = this.buildUnknownErrorResponse(status, request);
    }

    return { status, errorResponse };
  }

  /**
   * Builds a standard error response for non-HttpException errors
   * @param status - HTTP status code
   * @param request - The incoming request object
   * @returns { object }
   */
  private buildUnknownErrorResponse(status: number, request: Request): object {
    return {
      statusCode: status,
      message: 'Internal server error',
      timestamp: new Date().toISOString(),
      path: request.url,
    };
  }

  /**
   * Logs the error with detailed information
   * @param errorResponse - The error response to be logged
   * @param status - HTTP status code
   * @param request - The incoming request object
   */
  private logError(
    errorResponse: { message?: string; timestamp?: string },
    status: number,
    request: Request,
  ): void {
    const clientIp =
      request.headers['x-forwarded-for'] ||
      request.connection.remoteAddress ||
      'unknown';

    const message = errorResponse.message || 'Unknown error occurred';
    const timestamp = errorResponse.timestamp || new Date().toISOString();

    this.logger.error(
      `Error: ${message}`,
      `Status: ${status}, URL: ${request.url}, Method: ${request.method}, IP: ${clientIp}, Timestamp: ${timestamp}, Environment: ${
        process.env.NODE_ENV || 'development'
      }`,
    );
  }
}
