import { Module, Global } from '@nestjs/common';
import { HttpExceptionFilter } from './filters/http-exception.filter';
import LoggerService from './logger.service';

@Global()
@Module({
  providers: [
    {
      provide: 'APP_FILTER',
      useClass: HttpExceptionFilter,
    },
    LoggerService,
  ],
  exports: [LoggerService],
})
export class LoggerModule {}
