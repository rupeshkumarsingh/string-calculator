import { IField } from '../../../src/modules/fields/domain/fields';

// Function to create mock field data
export const createMockField = (): Partial<IField> => {
  return {
    name: 'First Name',
    label: 'First Name',
    description: 'The user’s first name.',
    type: 'text',
    status: 'active',
    validation: {
      pattern: '^[A-Za-z]+$',
      min_length: '1',
      max_length: '50',
      required: 'true',
    },
    createdBy: 'admin',
    updatedBy: 'admin',
    tenantId: '6708eaf5ab7b16c964098737',
    platformId: '6708eaee1f18d52405c72f88',
    formId: '6798bc302d7605b80b2ad5f4',
  };
};

// Example of creating multiple fields
export const createMockFields = (count: number): Partial<IField>[] => {
  return Array.from({ length: count }, (_, index) =>
    createMockFieldWithIndex(index),
  );
};

// Helper function to create mock field data with unique names/labels
const createMockFieldWithIndex = (index: number): Partial<IField> => {
  return {
    name: `FieldName${index + 1}`,
    label: `Field Label ${index + 1}`,
    description: `Description for field ${index + 1}.`,
    type: index % 2 === 0 ? 'text' : 'number',
    status: index % 3 === 0 ? 'inactive' : 'active',
    validation: {
      pattern: index % 2 === 0 ? '^[A-Za-z]+$' : '^[0-9]+$',
      min_length: '1',
      max_length: '100',
      required: 'true',
    },
    createdBy: 'admin',
    updatedBy: 'admin',
    tenantId: '6708eaf5ab7b16c964098737',
    platformId: '6708eaee1f18d52405c72f88',
    formId: '6798bc302d7605b80b2ad5f4',
  };
};
