import { ITemplate } from '../../../src/modules/templates/domain/templates';

export const createMockTemplate = (): Partial<ITemplate> => {
  return {
    name: 'Test Template',
    description: 'A template for testing',
    status: 'active',
    tenantId: '6708eaf5ab7b16c964098737',
    platformId: '6708eaee1f18d52405c72f88',
    formId: '6798bc302d7605b80b2ad5f4',
    createdBy: 'test-user',
    updatedBy: 'test-user',
    isDeleted: false,
  };
};
