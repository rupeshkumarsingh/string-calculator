import { ITab, ITabItem } from '../../../src/modules/tabs/domain/tabs';

export const createMockTab = (): Partial<ITab> => {
  return {
    name: 'User2 Information',
    description: 'This tab contains user details and preferences.',
    status: 'active',
    createdBy: 'admin',
    updatedBy: 'admin',
    tenantId: '6708eaf5ab7b16c964098737',
    platformId: '6708eaee1f18d52405c72f88',
    formId: '6798bc302d7605b80b2ad5f4',
    items: [
      createMockTabItem('First Name', 'firstName'),
      createMockTabItem('Last Name', 'lastName'),
      createMockTabItem('Email', 'email'),
    ],
  };
};

const createMockTabItem = (label: string, name: string): ITabItem => {
  return {
    label,
    name,
  } as ITabItem;
};
