import { IForm } from '../../../src/modules/forms/domain/forms';
export const createMockForm = (): Partial<IForm> => {
  return {
    name: 'Test Form',
    description: 'A form for testing purposes',
    status: 'active',
    tenantId: '6708eaf5ab7b16c964098737',
    platformId: '6708eaee1f18d52405c72f88',
    createdBy: 'test-user',
    updatedBy: 'test-user',
    isDeleted: false,
  };
};
