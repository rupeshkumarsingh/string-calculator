import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../../src/app.module';
import { ObjectId } from 'mongodb';
import { createMockTab } from './mocks/mock-tab';

describe('Tabs (e2e)', () => {
  let app: INestApplication;
  let createdTabId: string;
  let authToken: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    const loginResponse = await request(app.getHttpServer())
      .post('/auth/login')
      .send({
        email: 'tenant@demo.com',
        password: 'Test@123',
      })
      .expect(200);
    const responseBody = JSON.parse(loginResponse.text);
    authToken = responseBody.token;
  });

  afterAll(async () => {
    await app.close();
  });

  describe('POST /tabs', () => {
    it('should create a new tab', async () => {
      const createTabDto = createMockTab();

      const response = await request(app.getHttpServer())
        .post('/tabs')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createTabDto)
        .expect(201);
      expect(response.body).toHaveProperty('id');
      expect(response.body.name).toBe(createTabDto.name);
      createdTabId = response.body.id;
    });

    it('should return a conflict error for duplicate tabs', async () => {
      const createTabDto = createMockTab();
      await request(app.getHttpServer())
        .post('/tabs')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createTabDto);

      const response = await request(app.getHttpServer())
        .post('/tabs')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createTabDto)
        .expect(409);

      expect(response.body.message).toBe('Tab with this name already exists');
    });
  });

  describe('GET /tabs/:id', () => {
    it('should retrieve a tab by ID', async () => {
      const response = await request(app.getHttpServer())
        .get(`/tabs/${createdTabId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body).toHaveProperty('id', createdTabId);
    });

    it('should return a not found error for invalid ID', async () => {
      const invalidId = new ObjectId().toString();

      const response = await request(app.getHttpServer())
        .get(`/tabs/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);

      expect(response.body.message).toBe(`Tab with ID ${invalidId} not found`);
    });
  });

  describe('PUT /tabs/:id', () => {
    it('should update a tab by ID', async () => {
      const updateTabDto = {
        name: 'Updated Test Tab',
        description: 'An updated tab for testing',
      };

      const response = await request(app.getHttpServer())
        .put(`/tabs/${createdTabId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updateTabDto)
        .expect(200);

      expect(response.body.name).toBe(updateTabDto.name);
    });

    it('should return a not found error for invalid ID during update', async () => {
      const invalidId = new ObjectId().toString();
      const updateTabDto = {
        name: 'Updated Test Tab',
        description: 'An updated tab for testing',
      };

      const response = await request(app.getHttpServer())
        .put(`/tabs/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updateTabDto)
        .expect(404);

      expect(response.body.message).toBe(`Tab with ID ${invalidId} not found`);
    });
  });

  describe('DELETE /tabs/:id', () => {
    it('should delete a tab by ID', async () => {
      await request(app.getHttpServer())
        .delete(`/tabs/${createdTabId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(204);
    });

    it('should return a not found error for invalid ID during delete', async () => {
      const invalidId = new ObjectId().toString();

      const response = await request(app.getHttpServer())
        .delete(`/tabs/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);

      expect(response.body.message).toBe(`Tab with ID ${invalidId} not found`);
    });
  });
});
