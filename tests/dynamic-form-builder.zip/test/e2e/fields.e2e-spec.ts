import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../../src/app.module';
import { ObjectId } from 'mongodb';
import { createMockField } from './mocks/mock-field';
describe('Fields (e2e)', () => {
  let app: INestApplication;
  let createdFieldId: string;
  let authToken: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    const loginResponse = await request(app.getHttpServer())
      .post('/auth/login')
      .send({
        email: 'tenant@demo.com',
        password: 'Test@123',
      })
      .expect(200);
    const responseBody = JSON.parse(loginResponse.text);
    authToken = responseBody.token;
  });

  afterAll(async () => {
    await app.close();
  });

  describe('POST /fields', () => {
    it('should create a new field', async () => {
      const createFieldDto = createMockField();

      const response = await request(app.getHttpServer())
        .post('/fields')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createFieldDto)
        .expect(201);

      expect(response.body).toHaveProperty('id');
      expect(response.body.name).toBe(createFieldDto.name);
      createdFieldId = response.body.id;
    });

    it('should return a conflict error for duplicate fields', async () => {
      const createFieldDto = createMockField();
      await request(app.getHttpServer())
        .post('/fields')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createFieldDto);

      const response = await request(app.getHttpServer())
        .post('/fields')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createFieldDto)
        .expect(409);

      expect(response.body.message).toBe('Field with this name already exists');
    });
  });

  describe('GET /fields/:id', () => {
    it('should retrieve a field by ID', async () => {
      const response = await request(app.getHttpServer())
        .get(`/fields/${createdFieldId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body).toHaveProperty('id', createdFieldId);
    });

    it('should return a not found error for invalid ID', async () => {
      const invalidId = new ObjectId().toString();

      const response = await request(app.getHttpServer())
        .get(`/fields/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);

      expect(response.body.message).toBe(
        `Field with ID ${invalidId} not found`,
      );
    });
  });

  describe('PUT /fields/:id', () => {
    it('should update a field by ID', async () => {
      const updateFieldDto = {
        name: 'Updated Test Field',
        description: 'An updated field for testing',
        // Add other necessary properties based on your DTO
      };

      const response = await request(app.getHttpServer())
        .put(`/fields/${createdFieldId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updateFieldDto)
        .expect(200);

      expect(response.body.name).toBe(updateFieldDto.name);
    });

    it('should return a not found error for invalid ID during update', async () => {
      const invalidId = new ObjectId().toString();
      const updateFieldDto = {
        name: 'Updated Test Field',
        description: 'An updated field for testing',
      };

      const response = await request(app.getHttpServer())
        .put(`/fields/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updateFieldDto)
        .expect(404);

      expect(response.body.message).toBe(
        `Field with ID ${invalidId} not found`,
      );
    });
  });

  describe('DELETE /fields/:id', () => {
    it('should delete a field by ID', async () => {
      await request(app.getHttpServer())
        .delete(`/fields/${createdFieldId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(204);
    });
  });
});
