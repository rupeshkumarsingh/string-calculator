import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../../src/app.module';
import { ObjectId } from 'mongodb';
import { createMockTemplate } from './mocks/mock-template';

describe('Templates (e2e)', () => {
  let app: INestApplication;
  let createdTemplateId: string;
  let authToken: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();

    const loginResponse = await request(app.getHttpServer())
      .post('/auth/login')
      .send({
        email: 'tenant@demo.com',
        password: 'Test@123',
      })
      .expect(200);
    const responseBody = JSON.parse(loginResponse.text);
    authToken = responseBody.token;
  });

  afterAll(async () => {
    await app.close();
  });

  describe('POST /templates', () => {
    it('should create a new template', async () => {
      const createTemplateDto = createMockTemplate();

      const response = await request(app.getHttpServer())
        .post('/templates')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createTemplateDto)
        .expect(201);
      expect(response.body).toHaveProperty('_id');
      expect(response.body.name).toBe(createTemplateDto.name);
      createdTemplateId = response.body._id;
    });

    it('should return a conflict error for duplicate templates', async () => {
      const createTemplateDto = createMockTemplate();
      await request(app.getHttpServer())
        .post('/templates')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createTemplateDto);

      const response = await request(app.getHttpServer())
        .post('/templates')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createTemplateDto)
        .expect(409);

      expect(response.body.message).toBe(
        'Template with this name already exists',
      );
    });
  });

  describe('GET /templates/:id', () => {
    it('should retrieve a template by ID', async () => {
      const response = await request(app.getHttpServer())
        .get(`/templates/${createdTemplateId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body).toHaveProperty('id', createdTemplateId);
    });

    it('should return a not found error for invalid ID', async () => {
      const invalidId = new ObjectId().toString();

      const response = await request(app.getHttpServer())
        .get(`/templates/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);

      expect(response.body.message).toBe(
        `Template with ID ${invalidId} not found`,
      );
    });
  });

  describe('PUT /templates/:id', () => {
    it('should update a template by ID', async () => {
      const updateTemplateDto = {
        name: 'Updated Test Template',
        description: 'An updated template for testing',
      };

      const response = await request(app.getHttpServer())
        .put(`/templates/${createdTemplateId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updateTemplateDto)
        .expect(200);

      expect(response.body.name).toBe(updateTemplateDto.name);
    });

    it('should return a not found error for invalid ID during update', async () => {
      const invalidId = new ObjectId().toString();
      const updateTemplateDto = {
        name: 'Updated Test Template',
        description: 'An updated template for testing',
      };

      const response = await request(app.getHttpServer())
        .put(`/templates/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updateTemplateDto)
        .expect(404);

      expect(response.body.message).toBe(
        `Template with ID ${invalidId} not found`,
      );
    });
  });

  describe('DELETE /templates/:id', () => {
    it('should delete a template by ID', async () => {
      await request(app.getHttpServer())
        .delete(`/templates/${createdTemplateId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(204);
    });

    it('should return a not found error for invalid ID during delete', async () => {
      const invalidId = new ObjectId().toString();

      const response = await request(app.getHttpServer())
        .delete(`/templates/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);

      expect(response.body.message).toBe(
        `Template with ID ${invalidId} not found`,
      );
    });
  });
});
