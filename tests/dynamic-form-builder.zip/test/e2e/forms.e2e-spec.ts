import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../../src/app.module';
import { ObjectId } from 'mongodb';
import { createMockForm } from './mocks/mock-form';

describe('Forms (e2e)', () => {
  let app: INestApplication;
  let createdFormId: string;
  let authToken: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    const xApiKey = process.env.X_API_KEY;
    if (!xApiKey) {
      throw new Error('X_API_KEY is not defined in the environment variables');
    }
    const loginResponse = await request(app.getHttpServer())
      .post('/auth/login')
      .set('x-api-key', xApiKey)
      .send({
        email: 'tenant@demo.com',
        password: 'Test@123',
      })
      .expect(200);
    const responseBody = JSON.parse(loginResponse.text);
    authToken = responseBody.token;
  });

  afterAll(async () => {
    await app.close();
  });

  describe('POST /forms', () => {
    it('should create a new form', async () => {
      const createFormDto = createMockForm();

      const response = await request(app.getHttpServer())
        .post('/forms')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createFormDto)
        .expect(201);

      expect(response.body).toHaveProperty('_id');
      expect(response.body.name).toBe(createFormDto.name);
      createdFormId = response.body._id;
    });

    it('should return a conflict error for duplicate forms', async () => {
      const createFormDto = createMockForm();
      await request(app.getHttpServer())
        .post('/forms')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createFormDto);

      const response = await request(app.getHttpServer())
        .post('/forms')
        .set('Authorization', `Bearer ${authToken}`)
        .send(createFormDto)
        .expect(409);

      expect(response.body.message).toBe('Form with this name already exists');
    });
  });

  describe('GET /forms/:id', () => {
    it('should retrieve a form by ID', async () => {
      const response = await request(app.getHttpServer())
        .get(`/forms/${createdFormId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body).toHaveProperty('_id', createdFormId);
    });

    it('should return a not found error for invalid ID', async () => {
      const invalidId = new ObjectId().toString();

      const response = await request(app.getHttpServer())
        .get(`/forms/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);

      expect(response.body.message).toBe(`Form with ID ${invalidId} not found`);
    });
  });

  describe('PUT /forms/:id', () => {
    it('should update a form by ID', async () => {
      const updateFormDto = {
        name: 'Updated Test Form',
        description: 'An updated form for testing',
      };

      const response = await request(app.getHttpServer())
        .put(`/forms/${createdFormId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updateFormDto)
        .expect(200);

      expect(response.body.name).toBe(updateFormDto.name);
    });

    it('should return a not found error for invalid ID during update', async () => {
      const invalidId = new ObjectId().toString();
      const updateFormDto = {
        name: 'Updated Test Form',
        description: 'An updated form for testing',
      };

      const response = await request(app.getHttpServer())
        .put(`/forms/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updateFormDto)
        .expect(404);

      expect(response.body.message).toBe(`Form with ID ${invalidId} not found`);
    });
  });

  describe('DELETE /forms/:id', () => {
    it('should delete a form by ID', async () => {
      await request(app.getHttpServer())
        .delete(`/forms/${createdFormId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(204);
    });

    it('should return a not found error for invalid ID during delete', async () => {
      const invalidId = new ObjectId().toString();

      const response = await request(app.getHttpServer())
        .delete(`/forms/${invalidId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);

      expect(response.body.message).toBe(`Form with ID ${invalidId} not found`);
    });
  });

  describe('GET /forms', () => {
    it('should retrieve all forms with pagination', async () => {
      const response = await request(app.getHttpServer())
        .get('/forms?page=1&limit=10')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);
      expect(Array.isArray(response.body.items)).toBe(true);
    });
  });
});
