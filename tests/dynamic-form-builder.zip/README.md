# Dynamic Form Builder

The `dynamic-form-builder` is a backend application built with **NestJS**. It provides a flexible platform for creating and managing dynamic forms via APIs, utilizing MongoDB as the database through **Mongoose**. The application also supports **microservices** architecture and generates interactive API documentation using **Swagger**. Built-in request validation, sanitization, and security measures ensure the platform is suitable for enterprise-level applications.

## Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Dependencies](dependencies)
- [Architecture](#architecture)
- [Project Structure](#project-structure)
- [Setup Instruction](#setup-instruction)
- [Authentication](#authentication)
- [Api Documentation](#api-documentation)
- [Running Tests](#running-tests)
- [Deployment](#deployment)
- [Contributing](#contributing)
- [License](#license)

## Features

- **Dynamic Form Generation**: APIs for creating and managing dynamic forms with flexible configurations.
- **Authentication**: Modular and scalable microservices architecture.
- **Database**: MongoDB for NoSQL data.
- **Request Sanitization**: Use of **DOMPurify** and **sanitize-html** to prevent injection attacks.
- **Input Validation**: **class-validator** ensures that incoming data is properly validated before processing.
- **MongoDB Integration**: Persistent storage of forms and user data via **MongoDB** and **Mongoose**.
- **Microservices Support**: Scalable backend architecture for distributed services.
- **API Documentation**: Swagger/OpenAPI for API documentation.
- **Logging**: Integrated logging using **Winston** for detailed error reporting and system monitoring.
- **Validation**: Request validation using DTOs and class-validator.
- **Health Checks**: Automated health check endpoints to monitor the application's status and performance.
- **Error Handling**: AutoGlobal exception filters for consistent error responses.

## Tech Stack

- **Backend**: NestJS (Node.js)
- **Database**: MongoDB (with Mongoose)
- **Authentication**: JWT
- **API Documentation**: Swagger/OpenAPI
- **Logging**: Winston
- **Testing**: Jest, Supertest
- **Containerization**: Docker
- **CI/CD**: Jenkins ci cd pipeline
- **Code Formatting & Linting** : Prettier, ESLint

## Dependencies

### Core Dependencies

| Dependency            | Description                                |
| --------------------- | ------------------------------------------ |
| @nestjs/common        | NestJS common utilities and decorators     |
| @nestjs/core          | Core NestJS framework                      |
| @nestjs/microservices | NestJS microservices support               |
| @nestjs/mongoose      | NestJS integration with Mongoose (MongoDB) |
| @nestjs/swagger       | Swagger/OpenAPI documentation for NestJS   |
| @nestjs/terminus      | Health checks for NestJS                   |
| mongoose              | MongoDB object modeling for Node.js        |
| jsonwebtoken          | JSON Web Token implementation              |
| winston               | Logging library                            |
| rxjs                  | Reactive programming library               |
| class-validator       | Validation decorators for DTOs             |
| class-transformer     | Transformation decorators for DTOs         |
| ioredis               | Redis client                               |
| sanitize-html         | HTML sanitizer                             |
| dompurify             | DOM sanitizer                              |
| jsdom                 | JavaScript implementation of the DOM       |

### Development Dependencies

| Dependency      | Description                                     |
| --------------- | ----------------------------------------------- |
| @nestjs/cli     | NestJS command-line interface                   |
| @nestjs/testing | Testing utilities for NestJS                    |
| @types/jest     | TypeScript definitions for Jest                 |
| @types/node     | TypeScript definitions for Node.js              |
| eslint          | JavaScript/TypeScript linter                    |
| jest            | JavaScript testing framework                    |
| prettier        | Code formatting tool                            |
| ts-jest         | TypeScript preprocessor for Jest                |
| typescript      | TypeScript compiler                             |
| husky           | Git hooks for pre-commit linting and formatting |

## Architecture

The project follows a **microservices architecture** with the following components:

1. **API Gateway**: Handles incoming requests and routes them to the appropriate microservice.
2. **Auth Service**: Manages user authentication and authorization.
3. **User Service**: Manages User and Tenant information
4. **Form Service**: Manages Form/module information
5. **Tab Service**: Manages Tabs information
6. **Fields Service**: Manages Fields information
7. **Tempalte Service**: Manages Templates information
8. **Logging**: Winston
9. **Database**: MongoDB for NoSQL data
10. **Containerization**: Docker
11. **CI/CD**: Jenkins ci cd pipeline

## Project Structure

```bash
src/
├── shared/              # Shared modules (e.g., logging, validation)
│   ├── decorators/      # Custom decorators
│   ├── filters/         # Custom exception filters
│   ├── interceptors/    # Custom interceptors
│   ├── pipes/           # Custom validation pipes
├── modules/             # Core business logic
│   ├── auth/            # Authentication (JWT, login)
│   ├── form-builder/    # Form management (create, update, delete forms)
│   ├── fields/          # Form fields (inputs, checkboxes)
│   ├── tabs/            # Form tab management
│   ├── template/        # Template management
    ├── common/          # Pagignation and all base class
├── config/              # Configuration files (e.g., app.config.ts, redis)
├── logging/             # Error Log and calling Audit log service
├── main.ts              # Entry point for bootstrapping the app
├── app.module.ts        # Root module that imports and configures services
└── app.controller.ts    # Root-level API routes (e.g., health check)
```

## Setup Instruction

### Prerequisites

Before running the application, ensure you have the following installed:

- **Node.js** (v16 or later)
- **npm** or **yarn** (package managers)
- **Docker** (optional, for containerization)
- **MongoDB** (running locally or via a cloud provider like MongoDB Atlas)

### Installation

#### Clone the Repository

```bash
git clone git@bitbucket.org:impexdocs/dynamic-form-builder.git
cd dynamic-form-builder
```

#### Install dependencies

```bash
npm install
```

#### Set up environment variables

Create a .env file in the root directory.

```env
MONGO_URI=mongodb://localhost:27017/dynamic-form-db
PORT=3000
X_API_KEY=your_api_key_here
```

### Running the Application

Start the microservices:

```bash
npm run start:dev
```

### Running with Docker

Build the Docker images:

```bash
docker-compose build
```

Start the containers:

```bash
docker-compose up
```

## Authentication

The project uses **JWT-based authentication**. Here's how it works:

### JWT Authentication Flow

1. **Login**: Send a `POST` request to `/auth/login` with valid credentials (email and password).
2. **Receive JWT**: Upon successful authentication, the server returns a JWT token.
3. **Include Token**: For protected routes, include the token in the `Authorization` header:

```bash
curl -X POST http://localhost:3000/auth/login -d '{"email": "user@example.com", "password": "password"}'
```

## API Documentation

API documentation is available using Swagger. After starting the application, navigate to:

```bash
http://localhost:3000/api-docs
```

## Running Tests

To run unit and integration tests:

```bash
npm run test
```

For e2e tests:

```bash
npm run test:e2e
```
